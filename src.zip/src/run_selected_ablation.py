from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, load_csv, save_csv


VARIANTS = [
    {
        "name": "Full_EGO_CLGNN",
        "flags": ["--use_evidence_gate", "--use_ontology", "--use_path_attention", "--use_direction", "--use_contrastive"],
    },
    {
        "name": "w_o_Evidence_Gate",
        "flags": ["--use_ontology", "--use_path_attention", "--use_direction", "--use_contrastive"],
    },
    {
        "name": "w_o_Ontology",
        "flags": ["--use_evidence_gate", "--use_contrastive"],
    },
    {
        "name": "w_o_Direction",
        "flags": ["--use_evidence_gate", "--use_ontology", "--use_path_attention", "--use_contrastive"],
    },
    {
        "name": "w_o_Path_Attention",
        "flags": ["--use_evidence_gate", "--use_ontology", "--use_direction", "--use_contrastive"],
    },
    {
        "name": "w_o_Contrastive_Loss",
        "flags": ["--use_evidence_gate", "--use_ontology", "--use_path_attention", "--use_direction"],
    },
]


SUMMARY_FIELDS = [
    "variant",
    "auc_mean",
    "auc_std",
    "aupr_mean",
    "aupr_std",
    "selected_f1_mean",
    "selected_f1_std",
    "precision_mean",
    "precision_std",
    "recall_mean",
    "recall_std",
    "best_val_aupr_mean",
    "best_val_aupr_std",
]


DELTA_FIELDS = [
    "variant",
    "delta_auc",
    "delta_aupr",
    "delta_selected_f1",
    "delta_precision",
    "delta_recall",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run selected final EGO-CLGNN ablation study.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", default="results/selected_ablation")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--quick_test", action="store_true")
    return parser.parse_args()


def metric_lookup(cv_mean_std_path: Path) -> dict[str, dict[str, float]]:
    rows = load_csv(cv_mean_std_path)
    return {row["metric"]: {"mean": float(row["mean"]), "std": float(row["std"])} for row in rows}


def build_command(args: argparse.Namespace, variant_dir: Path, flags: list[str]) -> list[str]:
    command = [
        sys.executable,
        str(ROOT / "src" / "run_cv_clgnn.py"),
        "--data_dir",
        args.data_dir,
        "--output_dir",
        str(variant_dir),
        "--num_folds",
        str(args.num_folds),
        "--epochs",
        str(args.epochs),
        "--lr",
        str(args.lr),
        "--weight_decay",
        str(args.weight_decay),
        "--hidden_dim",
        str(args.hidden_dim),
        "--num_layers",
        str(args.num_layers),
        "--dropout",
        str(args.dropout),
        "--batch_size",
        str(args.batch_size),
        "--seed",
        str(args.seed),
        "--patience",
        str(args.patience),
        "--device",
        args.device,
        "--svd_dim",
        "64",
        "--svd_topk",
        "20",
        "--contrastive_weight",
        "0.1",
        "--temperature",
        "0.2",
        "--bpr_weight",
        "0.1",
        "--negative_sampling",
        "three_level",
        "--easy_negative_ratio",
        "0.5",
        "--ontology_negative_ratio",
        "0.3",
        "--svd_negative_ratio",
        "0.2",
        "--decoder_type",
        "hybrid",
        "--threshold_search",
        "all",
        "--focal_alpha",
        "0.85",
        "--focal_gamma",
        "1.5",
        "--soft_f1_weight",
        "0.1",
        "--use_svd_features",
        "--use_bpr",
        "--use_focal_loss",
        "--use_soft_f1_loss",
    ]
    command.extend(flags)
    return command


def summarize(output_dir: Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    summary_rows = []
    for variant in VARIANTS:
        name = str(variant["name"])
        stats = metric_lookup(output_dir / name / "cv_mean_std.csv")
        summary_rows.append(
            {
                "variant": name,
                "auc_mean": stats["test_auc"]["mean"],
                "auc_std": stats["test_auc"]["std"],
                "aupr_mean": stats["test_aupr"]["mean"],
                "aupr_std": stats["test_aupr"]["std"],
                "selected_f1_mean": stats["test_selected_threshold_f1"]["mean"],
                "selected_f1_std": stats["test_selected_threshold_f1"]["std"],
                "precision_mean": stats["test_selected_threshold_precision"]["mean"],
                "precision_std": stats["test_selected_threshold_precision"]["std"],
                "recall_mean": stats["test_selected_threshold_recall"]["mean"],
                "recall_std": stats["test_selected_threshold_recall"]["std"],
                "best_val_aupr_mean": stats["best_val_aupr"]["mean"],
                "best_val_aupr_std": stats["best_val_aupr"]["std"],
            }
        )

    full = next(row for row in summary_rows if row["variant"] == "Full_EGO_CLGNN")
    delta_rows = []
    for row in summary_rows:
        delta_rows.append(
            {
                "variant": row["variant"],
                "delta_auc": float(full["auc_mean"]) - float(row["auc_mean"]),
                "delta_aupr": float(full["aupr_mean"]) - float(row["aupr_mean"]),
                "delta_selected_f1": float(full["selected_f1_mean"]) - float(row["selected_f1_mean"]),
                "delta_precision": float(full["precision_mean"]) - float(row["precision_mean"]),
                "delta_recall": float(full["recall_mean"]) - float(row["recall_mean"]),
            }
        )

    save_csv(summary_rows, output_dir / "selected_ablation_summary.csv", SUMMARY_FIELDS)
    save_csv(delta_rows, output_dir / "selected_ablation_delta.csv", DELTA_FIELDS)
    return summary_rows, delta_rows


def main() -> None:
    args = parse_args()
    if args.quick_test and args.output_dir == "results/selected_ablation":
        args.output_dir = "results/selected_ablation_quick_test"

    output_dir = ensure_dir(args.output_dir)
    for variant in VARIANTS:
        name = str(variant["name"])
        variant_dir = ensure_dir(output_dir / name)
        command = build_command(args, variant_dir, list(variant["flags"]))
        print(f"[run_selected_ablation] starting variant: {name}", flush=True)
        subprocess.run(command, cwd=ROOT, check=True)
        print(f"[run_selected_ablation] completed variant: {name}", flush=True)

    summary_rows, _ = summarize(output_dir)
    full = next(row for row in summary_rows if row["variant"] == "Full_EGO_CLGNN")
    print(
        "[run_selected_ablation] Full_EGO_CLGNN "
        f"AUC={float(full['auc_mean']):.4f} "
        f"AUPR={float(full['aupr_mean']):.4f} "
        f"F1={float(full['selected_f1_mean']):.4f} "
        f"recall={float(full['recall_mean']):.4f}",
        flush=True,
    )
    print(f"[run_selected_ablation] outputs written to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
