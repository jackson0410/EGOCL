from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.calibration import calibrated_scores_from_logits, search_temperature_on_validation
from src.data_utils import build_exclusion_set, build_positive_pairs, load_graph_tensors, load_tsrna_attribute_tensors, sample_negatives
from src.losses import bpr_loss, classification_loss_with_options, soft_f1_loss
from src.metrics import evaluate_binary_classification
from src.models.ego_clgnn import EgoCLGNN
from src.preprocess.build_svd_features import compute_svd_features, save_svd_outputs
from src.train import (
    build_train_graph_data,
    evaluate_split,
    make_labeled_pairs,
    make_splits,
    move_graph_data_to_device,
    resolve_device,
    save_predictions,
    save_split_files,
    selected_threshold_metrics,
)
from src.utils import ensure_dir, save_csv, set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Single-fold EGOCL training.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", default="results/clgnn_single_run")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--fold_id", type=int, default=None)
    parser.add_argument("--num_folds", type=int, default=None)
    parser.add_argument("--split_mode", choices=["random", "random_kfold"], default="random")
    parser.add_argument("--use_evidence_gate", action="store_true")
    parser.add_argument("--use_ontology", action="store_true")
    parser.add_argument("--use_path_attention", action="store_true")
    parser.add_argument("--use_direction", action="store_true")
    parser.add_argument("--use_weak_edges_in_graph", action="store_true")
    parser.add_argument("--use_svd_features", action="store_true")
    parser.add_argument("--svd_dim", type=int, default=64)
    parser.add_argument("--svd_topk", type=int, default=20)
    parser.add_argument("--use_contrastive", action="store_true")
    parser.add_argument("--contrastive_weight", type=float, default=0.1)
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--use_bpr", action="store_true")
    parser.add_argument("--bpr_weight", type=float, default=0.1)
    parser.add_argument("--negative_sampling", choices=["random", "mixed", "ontology_hard", "three_level"], default="mixed")
    parser.add_argument("--hard_negative_ratio", type=float, default=0.3)
    parser.add_argument("--easy_negative_ratio", type=float, default=0.5)
    parser.add_argument("--ontology_negative_ratio", type=float, default=0.3)
    parser.add_argument("--svd_negative_ratio", type=float, default=0.2)
    parser.add_argument("--decoder_type", choices=["mlp", "hybrid"], default="hybrid")
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--label_smoothing", type=float, default=0.0)
    parser.add_argument("--pos_weight", type=float, default=1.0)
    parser.add_argument("--use_focal_loss", action="store_true")
    parser.add_argument("--focal_alpha", type=float, default=0.75)
    parser.add_argument("--focal_gamma", type=float, default=2.0)
    parser.add_argument("--use_soft_f1_loss", action="store_true")
    parser.add_argument("--soft_f1_weight", type=float, default=0.1)
    parser.add_argument("--logit_l2_weight", type=float, default=0.0)
    parser.add_argument("--use_temperature_scaling", action="store_true")
    parser.add_argument("--use_tsrna_attr", action="store_true")
    parser.add_argument("--use_tsrna_seq", action="store_true")
    parser.add_argument("--tsrna_kmer", type=int, default=3)
    parser.add_argument("--tsrna_attr_fusion", choices=["gated", "concat", "add"], default="gated")
    parser.add_argument("--use_attr_contrastive", action="store_true")
    parser.add_argument("--attr_cl_weight", type=float, default=0.05)
    parser.add_argument("--device", default="cpu")
    return parser.parse_args()


def tensor_pair_set_to_tensor(pairs: set[tuple[int, int]]) -> torch.Tensor:
    if not pairs:
        return torch.empty((0, 2), dtype=torch.long)
    return torch.tensor(sorted(pairs), dtype=torch.long)


def weak_pairs_tensor(graph_data: dict[str, torch.Tensor | int | list[str]]) -> torch.Tensor:
    return torch.stack([graph_data["weak_tsrna_ids"].long(), graph_data["weak_disease_ids"].long()], dim=1)


def train_one_epoch_clgnn(
    model: EgoCLGNN,
    train_pairs: torch.Tensor,
    train_labels: torch.Tensor,
    train_pos_pairs: torch.Tensor,
    train_neg_pairs: torch.Tensor,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    use_contrastive: bool,
    contrastive_weight: float,
    temperature: float,
    use_bpr: bool,
    bpr_weight: float,
    label_smoothing: float,
    pos_weight: float,
    use_focal_loss: bool,
    focal_alpha: float,
    focal_gamma: float,
    use_soft_f1_loss: bool,
    soft_f1_weight: float,
    logit_l2_weight: float,
    use_attr_contrastive: bool,
    attr_cl_weight: float,
) -> dict[str, float]:
    model.train()
    train_pairs = train_pairs.to(device)
    train_labels = train_labels.to(device)
    train_pos_pairs = train_pos_pairs.to(device)
    train_neg_pairs = train_neg_pairs.to(device)

    optimizer.zero_grad()
    logits, aux = model(train_pairs[:, 0], train_pairs[:, 1], graph_data, return_aux=True, temperature=temperature)
    cls = classification_loss_with_options(
        logits,
        train_labels,
        label_smoothing=label_smoothing,
        pos_weight=pos_weight,
        use_focal_loss=use_focal_loss,
        focal_alpha=focal_alpha,
        focal_gamma=focal_gamma,
    )
    cl = aux["contrastive_loss"] if use_contrastive else logits.new_tensor(0.0)
    attr_cl = aux["attribute_contrastive_loss"] if use_attr_contrastive else logits.new_tensor(0.0)
    bpr = logits.new_tensor(0.0)
    if use_bpr:
        pos_count = train_pos_pairs.shape[0]
        neg_count = train_neg_pairs.shape[0]
        bpr = bpr_loss(logits[:pos_count], logits[pos_count : pos_count + neg_count])
    soft_f1 = soft_f1_loss(logits, train_labels) if use_soft_f1_loss else logits.new_tensor(0.0)
    logit_l2 = logits.pow(2).mean() if logit_l2_weight > 0.0 else logits.new_tensor(0.0)
    loss = cls + contrastive_weight * cl + attr_cl_weight * attr_cl + bpr_weight * bpr + soft_f1_weight * soft_f1 + logit_l2_weight * logit_l2
    loss.backward()
    optimizer.step()

    return {
        "train_loss": float(loss.item()),
        "train_cls": float(cls.item()),
        "train_contrastive": float(cl.item()),
        "train_attr_contrastive": float(attr_cl.item()),
        "train_bpr": float(bpr.item()),
        "train_soft_f1": float(soft_f1.item()),
        "train_logit_l2": float(logit_l2.item()),
    }


def split_score_means(labels: torch.Tensor, scores: np.ndarray) -> tuple[float, float]:
    labels_np = labels.cpu().numpy().astype(int)
    pos_scores = scores[labels_np == 1]
    neg_scores = scores[labels_np == 0]
    pos_mean = float(pos_scores.mean()) if pos_scores.size else 0.0
    neg_mean = float(neg_scores.mean()) if neg_scores.size else 0.0
    return pos_mean, neg_mean


def save_negative_sampling_stats(output_dir: Path, stats_by_split: dict[str, dict[str, int]]) -> None:
    rows = []
    for split, stats in stats_by_split.items():
        row = {"split": split}
        row.update(stats)
        rows.append(row)
    save_csv(
        rows,
        output_dir / "negative_sampling_stats.csv",
        ["split", "num_easy_negative", "num_ontology_negative", "num_svd_negative", "fallback_count"],
    )


def add_sampling_svd_features(
    graph_data: dict[str, torch.Tensor | int | list[str]],
    train_pairs: torch.Tensor,
    svd_dim: int,
) -> dict[str, torch.Tensor | int | list[str]]:
    graph_data = graph_data.copy()
    _, disease_features = compute_svd_features(
        int(graph_data["num_tsrna"]),
        int(graph_data["num_disease"]),
        train_pairs,
        svd_dim,
    )
    graph_data["sampling_disease_svd_features"] = disease_features
    return graph_data


def add_fold_local_svd(
    output_dir: Path,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    train_graph_data: dict[str, torch.Tensor | int | list[str]],
    splits: dict[str, torch.Tensor],
    svd_dim: int,
    svd_topk: int,
    edge_feat_dim: int,
) -> dict[str, torch.Tensor | int | list[str]]:
    held_out = torch.cat([splits["val_pairs"], splits["test_pairs"], weak_pairs_tensor(graph_data)], dim=0)
    torch.save(splits["train_pairs"], output_dir / "train_pos_pairs.pt")
    svd_data = save_svd_outputs(
        output_dir=output_dir,
        num_tsrna=int(graph_data["num_tsrna"]),
        num_disease=int(graph_data["num_disease"]),
        train_pos_pairs=splits["train_pairs"],
        svd_dim=svd_dim,
        svd_topk=svd_topk,
        edge_feat_dim=edge_feat_dim,
        blocked_pairs=held_out,
    )
    train_graph_data = train_graph_data.copy()
    train_graph_data.update(svd_data)
    return train_graph_data


def attribute_meta_counts(graph_data: dict[str, torch.Tensor | int | list[str]]) -> dict[str, int]:
    meta = graph_data.get("tsrna_attr_meta", {})
    if not isinstance(meta, dict):
        return {
            "kmer_dim": 64,
            "num_tsrna_types": 1,
            "num_source_tRNAs": 1,
            "num_anticodons": 1,
            "num_amino_acid_families": 1,
            "num_species": 1,
        }
    return {
        "kmer_dim": int(meta.get("kmer_dim", 64)),
        "num_tsrna_types": int(meta.get("num_tsrna_types", 1)),
        "num_source_tRNAs": int(meta.get("num_source_tRNAs", 1)),
        "num_anticodons": int(meta.get("num_anticodons", 1)),
        "num_amino_acid_families": int(meta.get("num_amino_acid_families", 1)),
        "num_species": int(meta.get("num_species", 1)),
    }


def mean_or_na(values: torch.Tensor) -> float | str:
    if values.numel() == 0:
        return "NA"
    return float(values.float().mean().item())


def save_attr_gate_statistics(
    output_dir: Path,
    fold_id: int | None,
    model: EgoCLGNN,
    train_graph_data: dict[str, torch.Tensor | int | list[str]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    train_pairs: torch.Tensor,
    device: torch.device,
) -> None:
    if not model.use_tsrna_attr or model.tsrna_attr_fusion != "gated":
        return
    model.eval()
    with torch.no_grad():
        enc = model.encode(train_graph_data)
        h_graph = 0.5 * (enc["t1"] + enc["t2"])
        h_attr = enc["t_attr"]
        attr_mask = enc["attr_mask"]
        if h_attr is None or attr_mask is None:
            return
        _, gate = model.fuse_tsrna_attributes(h_graph, h_attr, attr_mask)
        if gate is None:
            return
        gate_node = gate.detach().mean(dim=1).cpu()
        attr_mask_cpu = attr_mask.detach().cpu()

    complete = attr_mask_cpu.sum(dim=1) == attr_mask_cpu.shape[1]
    missing = ~complete
    rows: list[dict[str, object]] = []
    fold_value = int(fold_id) if fold_id is not None else 0

    rows.append(
        {
            "fold": fold_value,
            "group_kind": "overall",
            "group": "all",
            "mean_gate": float(gate_node.mean().item()),
            "std_gate": float(gate_node.std(unbiased=True).item()) if gate_node.numel() > 1 else 0.0,
            "median_gate": float(gate_node.median().item()),
            "mean_gate_complete_attr": mean_or_na(gate_node[complete]),
            "mean_gate_missing_attr": mean_or_na(gate_node[missing]),
            "mean_gate_by_tsrna_type": "NA",
            "mean_gate_by_degree_group": "NA",
            "num_tsrna": int(gate_node.numel()),
        }
    )

    type_ids = graph_data.get("tsrna_type_ids")
    if isinstance(type_ids, torch.Tensor):
        type_ids = type_ids.cpu()
        meta = graph_data.get("tsrna_attr_meta", {})
        reverse_type = {}
        if isinstance(meta, dict):
            mapping = meta.get("categorical_mappings", {}).get("tsrna_type", {})
            reverse_type = {int(v): k for k, v in mapping.items()}
        for type_id in sorted(set(type_ids.tolist())):
            mask = type_ids == type_id
            rows.append(
                {
                    "fold": fold_value,
                    "group_kind": "tsrna_type",
                    "group": reverse_type.get(int(type_id), str(type_id)),
                    "mean_gate": "NA",
                    "std_gate": "NA",
                    "median_gate": "NA",
                    "mean_gate_complete_attr": "NA",
                    "mean_gate_missing_attr": "NA",
                    "mean_gate_by_tsrna_type": mean_or_na(gate_node[mask]),
                    "mean_gate_by_degree_group": "NA",
                    "num_tsrna": int(mask.sum().item()),
                }
            )

    degree = torch.zeros(int(graph_data["num_tsrna"]), dtype=torch.long)
    for tsrna_id in train_pairs[:, 0].long().tolist():
        degree[int(tsrna_id)] += 1
    degree_groups = {
        "degree=1": degree == 1,
        "degree=2-5": (degree >= 2) & (degree <= 5),
        "degree>5": degree > 5,
    }
    for group, mask in degree_groups.items():
        rows.append(
            {
                "fold": fold_value,
                "group_kind": "degree_group",
                "group": group,
                "mean_gate": "NA",
                "std_gate": "NA",
                "median_gate": "NA",
                "mean_gate_complete_attr": "NA",
                "mean_gate_missing_attr": "NA",
                "mean_gate_by_tsrna_type": "NA",
                "mean_gate_by_degree_group": mean_or_na(gate_node[mask]),
                "num_tsrna": int(mask.sum().item()),
            }
        )

    save_csv(
        rows,
        output_dir / "tsrna_attr_gate_statistics.csv",
        [
            "fold",
            "group_kind",
            "group",
            "mean_gate",
            "std_gate",
            "median_gate",
            "mean_gate_complete_attr",
            "mean_gate_missing_attr",
            "mean_gate_by_tsrna_type",
            "mean_gate_by_degree_group",
            "num_tsrna",
        ],
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = ensure_dir(args.output_dir)
    device = resolve_device(args.device)

    if not args.use_ontology:
        args.use_path_attention = False
        args.use_direction = False

    graph_data = load_graph_tensors(args.data_dir)
    if args.use_tsrna_attr:
        graph_data.update(load_tsrna_attribute_tensors(args.data_dir))
    pos_pairs = build_positive_pairs(graph_data)
    exclusion_set = build_exclusion_set(graph_data)
    splits = make_splits(pos_pairs, args)
    fold_offset = 0 if args.fold_id is None else (args.fold_id + 1) * 10_000
    sampling_graph_data = graph_data
    if args.negative_sampling == "three_level":
        sampling_graph_data = add_sampling_svd_features(graph_data, splits["train_pairs"], args.svd_dim)

    train_neg, train_neg_stats = sample_negatives(
        splits["train_pairs"],
        int(graph_data["num_tsrna"]),
        int(graph_data["num_disease"]),
        splits["train_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        seed=args.seed + fold_offset + 101,
        mode=args.negative_sampling,
        hard_negative_ratio=args.hard_negative_ratio,
        easy_negative_ratio=args.easy_negative_ratio,
        ontology_negative_ratio=args.ontology_negative_ratio,
        svd_negative_ratio=args.svd_negative_ratio,
        return_stats=True,
    )
    val_neg, val_neg_stats = sample_negatives(
        splits["val_pairs"],
        int(graph_data["num_tsrna"]),
        int(graph_data["num_disease"]),
        splits["val_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        seed=args.seed + fold_offset + 202,
        mode=args.negative_sampling,
        hard_negative_ratio=args.hard_negative_ratio,
        easy_negative_ratio=args.easy_negative_ratio,
        ontology_negative_ratio=args.ontology_negative_ratio,
        svd_negative_ratio=args.svd_negative_ratio,
        return_stats=True,
    )
    test_neg, test_neg_stats = sample_negatives(
        splits["test_pairs"],
        int(graph_data["num_tsrna"]),
        int(graph_data["num_disease"]),
        splits["test_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        seed=args.seed + fold_offset + 303,
        mode=args.negative_sampling,
        hard_negative_ratio=args.hard_negative_ratio,
        easy_negative_ratio=args.easy_negative_ratio,
        ontology_negative_ratio=args.ontology_negative_ratio,
        svd_negative_ratio=args.svd_negative_ratio,
        return_stats=True,
    )
    save_negative_sampling_stats(output_dir, {"train": train_neg_stats, "valid": val_neg_stats, "test": test_neg_stats})

    train_pairs, train_labels = make_labeled_pairs(splits["train_pairs"], train_neg)
    val_pairs, val_labels = make_labeled_pairs(splits["val_pairs"], val_neg)
    test_pairs, test_labels = make_labeled_pairs(splits["test_pairs"], test_neg)

    edge_feat_dim = graph_data["pos_edge_features"].shape[1]
    train_graph_data_cpu = build_train_graph_data(graph_data, splits["train_idx"], args.use_weak_edges_in_graph)
    if args.use_svd_features:
        train_graph_data_cpu = add_fold_local_svd(output_dir, graph_data, train_graph_data_cpu, splits, args.svd_dim, args.svd_topk, edge_feat_dim)
    save_split_files(output_dir, splits, train_neg, val_neg, test_neg, train_graph_data_cpu)
    train_graph_data = move_graph_data_to_device(train_graph_data_cpu, device)
    attr_counts = attribute_meta_counts(graph_data)

    model = EgoCLGNN(
        num_tsrna=int(graph_data["num_tsrna"]),
        num_disease=int(graph_data["num_disease"]),
        num_doid=int(graph_data["num_doid"]),
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        edge_feat_dim=edge_feat_dim,
        svd_dim=args.svd_dim,
        dropout=args.dropout,
        use_evidence_gate=args.use_evidence_gate,
        use_ontology=args.use_ontology,
        use_path_attention=args.use_path_attention,
        use_direction=args.use_direction,
        use_svd_features=args.use_svd_features,
        decoder_type=args.decoder_type,
        use_tsrna_attr=args.use_tsrna_attr,
        use_tsrna_seq=args.use_tsrna_seq,
        use_attr_contrastive=args.use_attr_contrastive,
        tsrna_attr_fusion=args.tsrna_attr_fusion,
        attr_kmer_dim=attr_counts["kmer_dim"],
        attr_num_types=attr_counts["num_tsrna_types"],
        attr_num_sources=attr_counts["num_source_tRNAs"],
        attr_num_anticodons=attr_counts["num_anticodons"],
        attr_num_aminos=attr_counts["num_amino_acid_families"],
        attr_num_species=attr_counts["num_species"],
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.BCEWithLogitsLoss()

    best_val_aupr = -1.0
    best_epoch = -1
    best_val_threshold = 0.5
    epochs_without_improvement = 0
    train_log = []
    best_model_path = output_dir / "best_model.pt"

    print(f"[train_clgnn] device: {device}", flush=True)
    print(f"[train_clgnn] train positives / negatives: {splits['train_pairs'].shape[0]} / {train_neg.shape[0]}", flush=True)
    print(f"[train_clgnn] valid positives / negatives: {splits['val_pairs'].shape[0]} / {val_neg.shape[0]}", flush=True)
    print(f"[train_clgnn] test positives / negatives: {splits['test_pairs'].shape[0]} / {test_neg.shape[0]}", flush=True)
    print(f"[train_clgnn] weak edges in message graph: {bool(args.use_weak_edges_in_graph)}", flush=True)
    print(f"[train_clgnn] SVD features / reconstructed topk: {bool(args.use_svd_features)} / {args.svd_topk}", flush=True)
    print(f"[train_clgnn] contrastive / BPR: {bool(args.use_contrastive)} / {bool(args.use_bpr)}", flush=True)
    print(
        f"[train_clgnn] tsRNA attributes / attr CL / fusion: "
        f"{bool(args.use_tsrna_attr)} / {bool(args.use_attr_contrastive)} / {args.tsrna_attr_fusion}",
        flush=True,
    )
    print(
        f"[train_clgnn] threshold search / soft-F1 / focal / label smoothing / logit L2: "
        f"{args.threshold_search} / {bool(args.use_soft_f1_loss)} / {bool(args.use_focal_loss)} / "
        f"{args.label_smoothing} / {args.logit_l2_weight}",
        flush=True,
    )
    print(f"[train_clgnn] negative sampling: {args.negative_sampling}", flush=True)
    if args.negative_sampling == "three_level":
        ratio_sum = args.easy_negative_ratio + args.ontology_negative_ratio + args.svd_negative_ratio
        if abs(ratio_sum - 1.0) > 1e-6:
            raise ValueError(f"three-level negative ratios must sum to 1.0, got {ratio_sum}")
        print(
            "[train_clgnn] three-level negative ratios "
            f"easy/ontology/svd: {args.easy_negative_ratio}/{args.ontology_negative_ratio}/{args.svd_negative_ratio}",
            flush=True,
        )
    print(f"[train_clgnn] temperature scaling: {bool(args.use_temperature_scaling)}", flush=True)
    if args.fold_id is not None:
        print(f"[train_clgnn] fold_id / num_folds: {args.fold_id} / {args.num_folds}", flush=True)

    for epoch in range(1, args.epochs + 1):
        train_losses = train_one_epoch_clgnn(
            model,
            train_pairs,
            train_labels,
            splits["train_pairs"],
            train_neg,
            train_graph_data,
            optimizer,
            device,
            args.use_contrastive,
            args.contrastive_weight,
            args.temperature,
            args.use_bpr,
            args.bpr_weight,
            args.label_smoothing,
            args.pos_weight,
            args.use_focal_loss,
            args.focal_alpha,
            args.focal_gamma,
            args.use_soft_f1_loss,
            args.soft_f1_weight,
            args.logit_l2_weight,
            args.use_attr_contrastive,
            args.attr_cl_weight,
        )
        val_metrics, val_scores, _, val_loss = evaluate_split(
            model,
            val_pairs,
            val_labels,
            train_graph_data,
            args.batch_size,
            device,
            criterion,
            threshold_search=args.threshold_search,
        )
        val_positive_score_mean, val_negative_score_mean = split_score_means(val_labels, val_scores)

        row = {
            "epoch": epoch,
            **train_losses,
            "val_loss": val_loss,
            "val_auc": val_metrics["AUC"],
            "val_aupr": val_metrics["AUPR"],
            "val_fixed_f1": val_metrics["fixed_f1"],
            "val_best_precision": val_metrics["best_precision"],
            "val_best_recall": val_metrics["best_recall"],
            "val_best_f1": val_metrics["best_f1"],
            "val_best_threshold": val_metrics["best_threshold"],
            "val_best_threshold_method": val_metrics["best_threshold_method"],
            "val_positive_score_mean": val_positive_score_mean,
            "val_negative_score_mean": val_negative_score_mean,
            "best_epoch": best_epoch,
        }

        if val_metrics["AUPR"] > best_val_aupr:
            best_val_aupr = val_metrics["AUPR"]
            best_epoch = epoch
            best_val_threshold = val_metrics["best_threshold"]
            epochs_without_improvement = 0
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "epoch": epoch,
                    "val_aupr": best_val_aupr,
                    "val_best_threshold": best_val_threshold,
                    "val_best_threshold_method": val_metrics["best_threshold_method"],
                    "config": vars(args),
                },
                best_model_path,
            )
        else:
            epochs_without_improvement += 1

        row["best_epoch"] = best_epoch
        train_log.append(row)

        print(
            f"[train_clgnn] epoch {epoch:03d} "
            f"loss={train_losses['train_loss']:.4f} cls={train_losses['train_cls']:.4f} "
            f"cl={train_losses['train_contrastive']:.4f} bpr={train_losses['train_bpr']:.4f} "
            f"val_loss={val_loss:.4f} val_auc={val_metrics['AUC']:.4f} "
            f"val_aupr={val_metrics['AUPR']:.4f} val_best_f1={val_metrics['best_f1']:.4f} "
            f"val_best_precision={val_metrics['best_precision']:.4f} "
            f"val_best_recall={val_metrics['best_recall']:.4f} "
            f"val_best_threshold={val_metrics['best_threshold']:.6f}"
            f"({val_metrics['best_threshold_method']})",
            flush=True,
        )

        if epochs_without_improvement >= args.patience:
            print(f"[train_clgnn] early stopping at epoch {epoch}; best epoch: {best_epoch}", flush=True)
            break

    checkpoint = torch.load(best_model_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    best_val_threshold = float(checkpoint.get("val_best_threshold", best_val_threshold))
    best_val_threshold_method = str(checkpoint.get("val_best_threshold_method", "unknown"))

    train_metrics, train_scores, train_logits, train_loss_eval = evaluate_split(
        model, train_pairs, train_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    val_metrics, val_scores, val_logits, val_loss_eval = evaluate_split(
        model, val_pairs, val_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    test_metrics, test_scores, test_logits, test_loss_eval = evaluate_split(
        model, test_pairs, test_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    test_selected = selected_threshold_metrics(test_labels, test_scores, best_val_threshold)
    test_positive_score_mean, test_negative_score_mean = split_score_means(test_labels, test_scores)
    best_temperature = 1.0
    calibrated_test_scores = None
    calibrated_test_metrics: dict[str, float] = {}
    calibrated_test_selected: dict[str, float] = {}
    if args.use_temperature_scaling:
        best_temperature, _ = search_temperature_on_validation(val_logits, val_labels.cpu().numpy(), threshold_search=args.threshold_search)
        calibrated_val_scores = calibrated_scores_from_logits(val_logits, best_temperature)
        calibrated_val_metrics = evaluate_binary_classification(val_labels.cpu().numpy(), calibrated_val_scores, threshold_search=args.threshold_search)
        calibrated_threshold = float(calibrated_val_metrics["best_threshold"])
        calibrated_test_scores = calibrated_scores_from_logits(test_logits, best_temperature)
        calibrated_test_metrics = evaluate_binary_classification(test_labels.cpu().numpy(), calibrated_test_scores, threshold_search=args.threshold_search)
        calibrated_test_selected = selected_threshold_metrics(test_labels, calibrated_test_scores, calibrated_threshold)
    else:
        calibrated_threshold = best_val_threshold

    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_fixed_accuracy": test_metrics["fixed_accuracy"],
        "test_fixed_precision": test_metrics["fixed_precision"],
        "test_fixed_recall": test_metrics["fixed_recall"],
        "test_fixed_f1": test_metrics["fixed_f1"],
        "val_selected_threshold": best_val_threshold,
        "test_selected_threshold_accuracy": test_selected["selected_threshold_accuracy"],
        "test_selected_threshold_precision": test_selected["selected_threshold_precision"],
        "test_selected_threshold_recall": test_selected["selected_threshold_recall"],
        "test_selected_threshold_f1": test_selected["selected_threshold_f1"],
        "test_oracle_best_threshold": test_metrics["best_threshold"],
        "test_oracle_best_accuracy": test_metrics["best_accuracy"],
        "test_oracle_best_precision": test_metrics["best_precision"],
        "test_oracle_best_recall": test_metrics["best_recall"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "test_best_threshold": test_metrics["best_threshold"],
        "test_best_threshold_method": test_metrics["best_threshold_method"],
        "test_positive_score_mean": test_positive_score_mean,
        "test_negative_score_mean": test_negative_score_mean,
        "best_temperature": best_temperature,
        "test_calibrated_auc": calibrated_test_metrics.get("AUC", test_metrics["AUC"]),
        "test_calibrated_aupr": calibrated_test_metrics.get("AUPR", test_metrics["AUPR"]),
        "test_calibrated_selected_f1": calibrated_test_selected.get("selected_threshold_f1", test_selected["selected_threshold_f1"]),
        "test_calibrated_precision": calibrated_test_selected.get("selected_threshold_precision", test_selected["selected_threshold_precision"]),
        "test_calibrated_recall": calibrated_test_selected.get("selected_threshold_recall", test_selected["selected_threshold_recall"]),
        "test_calibrated_threshold": calibrated_threshold,
        "best_epoch": best_epoch,
        "best_val_aupr": best_val_aupr,
        "train_loss": train_loss_eval,
        "val_loss": val_loss_eval,
        "test_loss": test_loss_eval,
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(
        train_log,
        output_dir / "train_log.csv",
        [
            "epoch",
            "train_loss",
            "train_cls",
            "train_contrastive",
            "train_attr_contrastive",
            "train_bpr",
            "train_soft_f1",
            "train_logit_l2",
            "val_loss",
            "val_auc",
            "val_aupr",
            "val_fixed_f1",
            "val_best_precision",
            "val_best_recall",
            "val_best_f1",
            "val_best_threshold",
            "val_best_threshold_method",
            "val_positive_score_mean",
            "val_negative_score_mean",
            "best_epoch",
        ],
    )
    prediction_splits = [
        ("train", train_pairs, train_labels, train_scores, train_logits),
        ("valid", val_pairs, val_labels, val_scores, val_logits),
        ("test", test_pairs, test_labels, test_scores, test_logits),
    ]
    if calibrated_test_scores is not None:
        prediction_splits[-1] = ("test", test_pairs, test_labels, test_scores, test_logits, calibrated_test_scores)
    save_predictions(output_dir, prediction_splits)
    save_attr_gate_statistics(output_dir, args.fold_id, model, train_graph_data, graph_data, splits["train_pairs"], device)

    config = vars(args).copy()
    config.update(
        {
            "model_name": "EGOCL",
            "device_resolved": str(device),
            "edge_feat_dim": edge_feat_dim,
            "best_epoch": best_epoch,
            "best_val_aupr": best_val_aupr,
            "best_val_threshold": best_val_threshold,
            "best_val_threshold_method": best_val_threshold_method,
            "best_temperature": best_temperature,
            "train_positive_count": int(splits["train_pairs"].shape[0]),
            "val_positive_count": int(splits["val_pairs"].shape[0]),
            "test_positive_count": int(splits["test_pairs"].shape[0]),
            "stopped_epoch": int(train_log[-1]["epoch"]) if train_log else 0,
            "split_mode_resolved": "random_kfold" if args.fold_id is not None else args.split_mode,
        }
    )
    with (output_dir / "config.json").open("w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    print(f"[train_clgnn] best validation AUPR: {best_val_aupr:.4f} at epoch {best_epoch}", flush=True)
    print(f"[train_clgnn] validation-selected threshold: {best_val_threshold:.6f} ({best_val_threshold_method})", flush=True)
    print(f"[train_clgnn] test AUC: {test_metrics['AUC']:.4f}", flush=True)
    print(f"[train_clgnn] test AUPR: {test_metrics['AUPR']:.4f}", flush=True)
    print(f"[train_clgnn] test selected-threshold F1: {test_selected['selected_threshold_f1']:.4f}", flush=True)
    if args.use_temperature_scaling:
        print(
            f"[train_clgnn] best temperature: {best_temperature:.2f}; "
            f"test calibrated F1: {metrics_row['test_calibrated_selected_f1']:.4f} "
            f"precision={metrics_row['test_calibrated_precision']:.4f} "
            f"recall={metrics_row['test_calibrated_recall']:.4f}",
            flush=True,
        )
    print(f"[train_clgnn] test oracle best threshold: {test_metrics['best_threshold']:.6f} ({test_metrics['best_threshold_method']})", flush=True)
    print(f"[train_clgnn] test oracle best F1: {test_metrics['best_f1']:.4f}", flush=True)
    print(f"[train_clgnn] outputs written to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
