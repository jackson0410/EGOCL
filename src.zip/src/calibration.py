from __future__ import annotations

import numpy as np

from src.metrics import evaluate_binary_classification, sigmoid_np


def calibrated_scores_from_logits(logits: np.ndarray | list[float], temperature: float) -> np.ndarray:
    if temperature <= 0.0:
        raise ValueError(f"temperature must be positive, got {temperature}")
    return sigmoid_np(np.asarray(logits, dtype=float) / float(temperature))


def search_temperature_on_validation(
    logits: np.ndarray | list[float],
    labels: np.ndarray | list[int],
    threshold_search: str = "all",
) -> tuple[float, dict[str, float]]:
    labels_arr = np.asarray(labels).astype(int)
    logits_arr = np.asarray(logits, dtype=float)
    best_temperature = 1.0
    best_metrics: dict[str, float] | None = None

    for temperature in np.round(np.arange(0.5, 2.5 + 1e-9, 0.1), 8):
        scores = calibrated_scores_from_logits(logits_arr, float(temperature))
        metrics = evaluate_binary_classification(labels_arr, scores, threshold_search=threshold_search)
        if best_metrics is None:
            best_temperature = float(temperature)
            best_metrics = metrics
            continue
        current_key = (
            float(metrics["best_f1"]),
            -abs(float(temperature) - 1.0),
        )
        best_key = (
            float(best_metrics["best_f1"]),
            -abs(best_temperature - 1.0),
        )
        if current_key > best_key:
            best_temperature = float(temperature)
            best_metrics = metrics

    if best_metrics is None:
        raise RuntimeError("temperature search produced no candidates")
    return best_temperature, best_metrics
