from __future__ import annotations

import numpy as np


def _load_sklearn_metrics():
    try:
        from sklearn.metrics import (
            accuracy_score,
            average_precision_score,
            f1_score,
            precision_score,
            recall_score,
            roc_auc_score,
        )
    except ImportError as exc:
        raise ImportError("scikit-learn is required for metrics. Install sklearn/scikit-learn in this environment.") from exc

    return {
        "accuracy_score": accuracy_score,
        "average_precision_score": average_precision_score,
        "f1_score": f1_score,
        "precision_score": precision_score,
        "recall_score": recall_score,
        "roc_auc_score": roc_auc_score,
    }


def threshold_metrics(y_true: np.ndarray, y_score: np.ndarray, threshold: float, prefix: str) -> dict[str, float]:
    metrics = _load_sklearn_metrics()
    y_pred = (y_score >= threshold).astype(int)
    return {
        f"{prefix}_accuracy": float(metrics["accuracy_score"](y_true, y_pred)),
        f"{prefix}_precision": float(metrics["precision_score"](y_true, y_pred, zero_division=0)),
        f"{prefix}_recall": float(metrics["recall_score"](y_true, y_pred, zero_division=0)),
        f"{prefix}_f1": float(metrics["f1_score"](y_true, y_pred, zero_division=0)),
    }


def sigmoid_np(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    return 1.0 / (1.0 + np.exp(-values))


def linear_thresholds(
    start: float = 0.01,
    stop: float = 0.99,
    step: float = 0.01,
) -> np.ndarray:
    num_steps = int(round((stop - start) / step)) + 1
    return np.asarray([round(start + idx * step, 8) for idx in range(num_steps)], dtype=float)


def log_thresholds() -> np.ndarray:
    return np.concatenate([np.logspace(-6, -2, 100), np.linspace(0.01, 0.99, 99)])


def quantile_thresholds(y_score: np.ndarray, max_candidates: int = 200) -> np.ndarray:
    unique_scores = np.unique(np.asarray(y_score, dtype=float))
    unique_scores = unique_scores[(unique_scores >= 0.0) & (unique_scores <= 1.0)]
    if unique_scores.size <= max_candidates:
        return unique_scores
    quantiles = np.linspace(0.0, 1.0, max_candidates)
    return np.unique(np.quantile(unique_scores, quantiles))


def threshold_candidates(y_score: np.ndarray, threshold_search: str) -> dict[str, np.ndarray]:
    if threshold_search == "linear":
        return {"linear": linear_thresholds()}
    if threshold_search == "log":
        return {"log": log_thresholds()}
    if threshold_search == "quantile":
        return {"quantile": quantile_thresholds(y_score)}
    if threshold_search == "all":
        return {
            "linear": linear_thresholds(),
            "log": log_thresholds(),
            "quantile": quantile_thresholds(y_score),
        }
    raise ValueError(f"Unknown threshold_search: {threshold_search}")


def _is_better_threshold(current: dict[str, float], best: dict[str, float], threshold: float, best_threshold: float) -> bool:
    if current["best_f1"] > best["best_f1"] + 1e-12:
        return True
    if abs(current["best_f1"] - best["best_f1"]) <= 1e-12:
        if current["best_recall"] > best["best_recall"] + 1e-12:
            return True
        if abs(current["best_recall"] - best["best_recall"]) <= 1e-12 and threshold > best_threshold:
            return True
    return False


def find_best_threshold(
    y_true: np.ndarray,
    y_score: np.ndarray,
    threshold_search: str = "all",
) -> tuple[float, str, dict[str, float]]:
    candidate_groups = threshold_candidates(y_score, threshold_search)
    best_threshold = 0.5
    best_method = threshold_search
    best_metrics = threshold_metrics(y_true, y_score, best_threshold, "best")

    for method, candidates in candidate_groups.items():
        for threshold in candidates:
            threshold = float(threshold)
            if not 0.0 <= threshold <= 1.0:
                continue
            current = threshold_metrics(y_true, y_score, threshold, "best")
            if _is_better_threshold(current, best_metrics, threshold, best_threshold):
                best_threshold = threshold
                best_method = method
                best_metrics = current

    return best_threshold, best_method, best_metrics


def evaluate_at_threshold(
    y_true: np.ndarray | list[int],
    y_score: np.ndarray | list[float],
    threshold: float,
    prefix: str,
    input_is_logits: bool = False,
) -> dict[str, float]:
    y_true_arr = np.asarray(y_true).astype(int)
    y_score_arr = np.asarray(y_score).astype(float)
    if input_is_logits:
        y_score_arr = sigmoid_np(y_score_arr)
    return threshold_metrics(y_true_arr, y_score_arr, threshold, prefix)


def evaluate_binary_classification(
    y_true: np.ndarray | list[int],
    y_score: np.ndarray | list[float],
    threshold: float = 0.5,
    input_is_logits: bool = False,
    threshold_search: str = "all",
) -> dict[str, float]:
    metrics = _load_sklearn_metrics()
    y_true_arr = np.asarray(y_true).astype(int)
    y_score_arr = np.asarray(y_score).astype(float)
    if input_is_logits:
        y_score_arr = sigmoid_np(y_score_arr)

    best_threshold, best_method, best_metrics = find_best_threshold(y_true_arr, y_score_arr, threshold_search)
    result = {
        "AUC": float(metrics["roc_auc_score"](y_true_arr, y_score_arr)),
        "AUPR": float(metrics["average_precision_score"](y_true_arr, y_score_arr)),
        "fixed_threshold": float(threshold),
    }
    result.update(threshold_metrics(y_true_arr, y_score_arr, threshold, "fixed"))
    result["best_threshold"] = float(best_threshold)
    result["best_threshold_method"] = best_method
    result.update(best_metrics)
    return result
