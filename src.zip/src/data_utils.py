from __future__ import annotations

import json
import math
import random
from pathlib import Path
from typing import Iterable

import torch
import torch.nn.functional as F


TENSOR_NAMES = [
    "pos_tsrna_ids",
    "pos_disease_ids",
    "pos_edge_features",
    "weak_tsrna_ids",
    "weak_disease_ids",
    "weak_edge_features",
    "doid_up_edges",
    "doid_down_edges",
    "disease_to_doid_idx",
    "disease_path_indices",
    "disease_path_mask",
]

TSRNA_ATTRIBUTE_TENSOR_NAMES = [
    "tsrna_kmer_features",
    "tsrna_length",
    "tsrna_type_ids",
    "tsrna_source_ids",
    "tsrna_anticodon_ids",
    "tsrna_amino_ids",
    "tsrna_species_ids",
    "tsrna_attr_mask",
]


def load_graph_tensors(data_dir: str | Path) -> dict[str, torch.Tensor | int | list[str]]:
    data_dir = Path(data_dir)
    graph_data: dict[str, torch.Tensor | int | list[str]] = {}

    for name in TENSOR_NAMES:
        graph_data[name] = torch.load(data_dir / f"{name}.pt", map_location="cpu")

    with (data_dir / "node_counts.json").open("r", encoding="utf-8") as f:
        node_counts = json.load(f)
    graph_data.update({key: int(value) for key, value in node_counts.items()})

    edge_feature_path = data_dir / "edge_feature_names.json"
    if edge_feature_path.exists():
        with edge_feature_path.open("r", encoding="utf-8") as f:
            graph_data["edge_feature_names"] = json.load(f)

    return graph_data


def load_tsrna_attribute_tensors(data_dir: str | Path) -> dict[str, torch.Tensor | int | list[str]]:
    data_dir = Path(data_dir)
    missing = [name for name in TSRNA_ATTRIBUTE_TENSOR_NAMES if not (data_dir / f"{name}.pt").exists()]
    meta_path = data_dir / "tsrna_attr_meta.json"
    if not meta_path.exists():
        missing.append("tsrna_attr_meta.json")
    if missing:
        raise FileNotFoundError(
            "Missing tsRNA attribute tensor(s): "
            + ", ".join(missing)
            + ". Run: G:\\conda_envs\\trna\\python.exe src\\preprocess\\build_tsrna_features.py --data_dir data\\processed --kmer 3"
        )

    tensors: dict[str, torch.Tensor | int | list[str]] = {}
    for name in TSRNA_ATTRIBUTE_TENSOR_NAMES:
        tensors[name] = torch.load(data_dir / f"{name}.pt", map_location="cpu")
    with meta_path.open("r", encoding="utf-8") as f:
        meta = json.load(f)
    tensors["tsrna_attr_meta"] = meta
    return tensors


def build_positive_pairs(graph_data: dict[str, torch.Tensor | int | list[str]]) -> torch.Tensor:
    return torch.stack(
        [
            graph_data["pos_tsrna_ids"].long(),
            graph_data["pos_disease_ids"].long(),
        ],
        dim=1,
    )


def _pairs_from_tensors(tsrna_ids: torch.Tensor, disease_ids: torch.Tensor) -> set[tuple[int, int]]:
    return set(zip(tsrna_ids.long().tolist(), disease_ids.long().tolist()))


def build_exclusion_set(graph_data: dict[str, torch.Tensor | int | list[str]]) -> set[tuple[int, int]]:
    exclusion = _pairs_from_tensors(graph_data["pos_tsrna_ids"], graph_data["pos_disease_ids"])
    exclusion.update(_pairs_from_tensors(graph_data["weak_tsrna_ids"], graph_data["weak_disease_ids"]))
    return exclusion


def random_negative_sampling(
    num_tsrna: int,
    num_disease: int,
    num_samples: int,
    exclusion_set: Iterable[tuple[int, int]],
    seed: int,
) -> torch.Tensor:
    exclusion = set(exclusion_set)
    max_possible = num_tsrna * num_disease - len(exclusion)
    if num_samples > max_possible:
        raise ValueError(f"Requested {num_samples} negatives, but only {max_possible} pairs are available.")

    rng = random.Random(seed)
    negatives: set[tuple[int, int]] = set()
    while len(negatives) < num_samples:
        pair = (rng.randrange(num_tsrna), rng.randrange(num_disease))
        if pair in exclusion or pair in negatives:
            continue
        negatives.add(pair)

    return torch.tensor(sorted(negatives), dtype=torch.long)


def _empty_negative_result(return_stats: bool) -> torch.Tensor | tuple[torch.Tensor, dict[str, int]]:
    negatives = torch.empty((0, 2), dtype=torch.long)
    stats = {
        "num_easy_negative": 0,
        "num_ontology_negative": 0,
        "num_svd_negative": 0,
        "fallback_count": 0,
    }
    return (negatives, stats) if return_stats else negatives


def _sample_random_excluding(
    num_tsrna: int,
    num_disease: int,
    num_samples: int,
    blocked: set[tuple[int, int]],
    seed: int,
) -> torch.Tensor:
    return random_negative_sampling(num_tsrna, num_disease, num_samples, blocked, seed)


def _build_disease_parent_groups(graph_data: dict[str, torch.Tensor | int | list[str]]) -> dict[int, list[int]]:
    disease_to_doid = graph_data["disease_to_doid_idx"].long()
    up_edges = graph_data["doid_up_edges"].long()
    parents_by_doid: dict[int, set[int]] = {}
    for child, parent in up_edges.t().tolist():
        parents_by_doid.setdefault(child, set()).add(parent)

    group_to_disease: dict[int, list[int]] = {}
    for disease_id, doid_idx in enumerate(disease_to_doid.tolist()):
        if doid_idx < 0:
            continue
        groups = set(parents_by_doid.get(doid_idx, set()))
        groups.add(doid_idx)
        for group in groups:
            group_to_disease.setdefault(group, []).append(disease_id)
    return group_to_disease


def ontology_hard_negative_sampling(
    pos_pairs: torch.Tensor,
    num_tsrna: int,
    num_disease: int,
    num_samples: int,
    exclusion_set: Iterable[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    seed: int,
) -> torch.Tensor:
    exclusion = set(exclusion_set)
    rng = random.Random(seed)
    group_to_disease = _build_disease_parent_groups(graph_data)
    disease_to_doid = graph_data["disease_to_doid_idx"].long().tolist()
    up_edges = graph_data["doid_up_edges"].long()
    parents_by_doid: dict[int, set[int]] = {}
    for child, parent in up_edges.t().tolist():
        parents_by_doid.setdefault(child, set()).add(parent)

    negatives: set[tuple[int, int]] = set()
    shuffled_pos = pos_pairs[torch.randperm(pos_pairs.shape[0], generator=torch.Generator().manual_seed(seed))]
    for tsrna_id, disease_id in shuffled_pos.tolist():
        doid_idx = disease_to_doid[disease_id]
        candidate_diseases: set[int] = set()
        if doid_idx >= 0:
            groups = set(parents_by_doid.get(doid_idx, set()))
            groups.add(doid_idx)
            for group in groups:
                candidate_diseases.update(group_to_disease.get(group, []))
        candidates = list(candidate_diseases)
        rng.shuffle(candidates)
        for candidate_disease in candidates:
            pair = (int(tsrna_id), int(candidate_disease))
            if candidate_disease == disease_id or pair in exclusion or pair in negatives:
                continue
            negatives.add(pair)
            break
        if len(negatives) >= num_samples:
            break

    if len(negatives) < num_samples:
        fallback = random_negative_sampling(num_tsrna, num_disease, num_samples - len(negatives), exclusion | negatives, seed + 999)
        negatives.update((int(t), int(d)) for t, d in fallback.tolist())

    return torch.tensor(sorted(negatives), dtype=torch.long)


def _ontology_hard_negative_candidates(
    disease_id: int,
    group_to_disease: dict[int, list[int]],
    disease_to_doid: list[int],
    parents_by_doid: dict[int, set[int]],
) -> list[int]:
    doid_idx = disease_to_doid[disease_id]
    candidate_diseases: set[int] = set()
    if doid_idx >= 0:
        groups = set(parents_by_doid.get(doid_idx, set()))
        groups.add(doid_idx)
        for group in groups:
            candidate_diseases.update(group_to_disease.get(group, []))
    return list(candidate_diseases)


def _prepare_ontology_negative_context(
    graph_data: dict[str, torch.Tensor | int | list[str]],
) -> tuple[dict[int, list[int]], list[int], dict[int, set[int]]]:
    group_to_disease = _build_disease_parent_groups(graph_data)
    disease_to_doid = graph_data["disease_to_doid_idx"].long().tolist()
    up_edges = graph_data["doid_up_edges"].long()
    parents_by_doid: dict[int, set[int]] = {}
    for child, parent in up_edges.t().tolist():
        parents_by_doid.setdefault(child, set()).add(parent)
    return group_to_disease, disease_to_doid, parents_by_doid


def _sample_ontology_hard_no_fallback(
    pos_pairs: torch.Tensor,
    num_samples: int,
    blocked: set[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    seed: int,
) -> torch.Tensor:
    if num_samples <= 0:
        return torch.empty((0, 2), dtype=torch.long)

    rng = random.Random(seed)
    group_to_disease, disease_to_doid, parents_by_doid = _prepare_ontology_negative_context(graph_data)
    negatives: set[tuple[int, int]] = set()
    generator = torch.Generator().manual_seed(seed)
    shuffled_pos = pos_pairs[torch.randperm(pos_pairs.shape[0], generator=generator)]

    for tsrna_id, disease_id in shuffled_pos.tolist():
        candidates = _ontology_hard_negative_candidates(int(disease_id), group_to_disease, disease_to_doid, parents_by_doid)
        rng.shuffle(candidates)
        for candidate_disease in candidates:
            pair = (int(tsrna_id), int(candidate_disease))
            if candidate_disease == disease_id or pair in blocked or pair in negatives:
                continue
            negatives.add(pair)
            break
        if len(negatives) >= num_samples:
            break

    return torch.tensor(sorted(negatives), dtype=torch.long) if negatives else torch.empty((0, 2), dtype=torch.long)


def _sample_svd_hard_no_fallback(
    pos_pairs: torch.Tensor,
    num_samples: int,
    blocked: set[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    seed: int,
) -> torch.Tensor:
    if num_samples <= 0:
        return torch.empty((0, 2), dtype=torch.long)
    disease_features = graph_data.get("sampling_disease_svd_features", graph_data.get("disease_svd_features"))
    if not isinstance(disease_features, torch.Tensor) or disease_features.numel() == 0:
        return torch.empty((0, 2), dtype=torch.long)

    rng = random.Random(seed)
    features = F.normalize(disease_features.float(), p=2, dim=1)
    similarity = features @ features.T
    num_disease = similarity.shape[0]
    negatives: set[tuple[int, int]] = set()
    generator = torch.Generator().manual_seed(seed)
    shuffled_pos = pos_pairs[torch.randperm(pos_pairs.shape[0], generator=generator)]

    max_rounds = max(1, math.ceil(num_samples / max(1, shuffled_pos.shape[0])))
    for _ in range(max_rounds):
        for tsrna_id, disease_id in shuffled_pos.tolist():
            scores = similarity[int(disease_id)].clone()
            scores[int(disease_id)] = -float("inf")
            ranked = torch.argsort(scores, descending=True).tolist()
            top_window = ranked[: min(num_disease, max(20, num_disease))]
            if len(top_window) > 3:
                top_window = top_window[: max(3, int(len(top_window) * 0.5))]
            rng.shuffle(top_window)
            for candidate_disease in top_window:
                pair = (int(tsrna_id), int(candidate_disease))
                if candidate_disease == disease_id or pair in blocked or pair in negatives:
                    continue
                negatives.add(pair)
                break
            if len(negatives) >= num_samples:
                break
        if len(negatives) >= num_samples:
            break

    return torch.tensor(sorted(negatives), dtype=torch.long) if negatives else torch.empty((0, 2), dtype=torch.long)


def _three_level_counts(
    num_samples: int,
    easy_negative_ratio: float,
    ontology_negative_ratio: float,
    svd_negative_ratio: float,
) -> tuple[int, int, int]:
    ratio_sum = easy_negative_ratio + ontology_negative_ratio + svd_negative_ratio
    if abs(ratio_sum - 1.0) > 1e-6:
        raise ValueError(f"three-level negative ratios must sum to 1.0, got {ratio_sum}")
    ontology_count = int(round(num_samples * ontology_negative_ratio))
    svd_count = int(round(num_samples * svd_negative_ratio))
    easy_count = num_samples - ontology_count - svd_count
    return easy_count, ontology_count, svd_count


def three_level_negative_sampling(
    pos_pairs: torch.Tensor,
    num_tsrna: int,
    num_disease: int,
    num_samples: int,
    exclusion_set: Iterable[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    seed: int,
    easy_negative_ratio: float = 0.5,
    ontology_negative_ratio: float = 0.3,
    svd_negative_ratio: float = 0.2,
    return_stats: bool = False,
) -> torch.Tensor | tuple[torch.Tensor, dict[str, int]]:
    if num_samples <= 0:
        return _empty_negative_result(return_stats)

    easy_target, ontology_target, svd_target = _three_level_counts(
        num_samples,
        easy_negative_ratio,
        ontology_negative_ratio,
        svd_negative_ratio,
    )
    blocked = set(exclusion_set)
    fallback_count = 0

    ontology = _sample_ontology_hard_no_fallback(pos_pairs, ontology_target, blocked, graph_data, seed + 11)
    blocked.update((int(t), int(d)) for t, d in ontology.tolist())
    if ontology.shape[0] < ontology_target:
        fallback_count += ontology_target - ontology.shape[0]

    svd = _sample_svd_hard_no_fallback(pos_pairs, svd_target, blocked, graph_data, seed + 22)
    blocked.update((int(t), int(d)) for t, d in svd.tolist())
    if svd.shape[0] < svd_target:
        fallback_count += svd_target - svd.shape[0]

    remaining = num_samples - ontology.shape[0] - svd.shape[0]
    easy = _sample_random_excluding(num_tsrna, num_disease, remaining, blocked, seed + 33)
    negatives = torch.cat([easy, ontology, svd], dim=0)
    stats = {
        "num_easy_negative": int(easy.shape[0]),
        "num_ontology_negative": int(ontology.shape[0]),
        "num_svd_negative": int(svd.shape[0]),
        "fallback_count": int(fallback_count),
    }
    return (negatives, stats) if return_stats else negatives


def sample_negatives(
    pos_pairs: torch.Tensor,
    num_tsrna: int,
    num_disease: int,
    num_samples: int,
    exclusion_set: Iterable[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    seed: int,
    mode: str = "random",
    hard_negative_ratio: float = 0.3,
    easy_negative_ratio: float = 0.5,
    ontology_negative_ratio: float = 0.3,
    svd_negative_ratio: float = 0.2,
    return_stats: bool = False,
) -> torch.Tensor | tuple[torch.Tensor, dict[str, int]]:
    if num_samples <= 0:
        return _empty_negative_result(return_stats)
    if mode == "random":
        negatives = random_negative_sampling(num_tsrna, num_disease, num_samples, exclusion_set, seed)
        stats = {
            "num_easy_negative": int(negatives.shape[0]),
            "num_ontology_negative": 0,
            "num_svd_negative": 0,
            "fallback_count": 0,
        }
        return (negatives, stats) if return_stats else negatives
    if mode == "ontology_hard":
        negatives = ontology_hard_negative_sampling(pos_pairs, num_tsrna, num_disease, num_samples, exclusion_set, graph_data, seed)
        stats = {
            "num_easy_negative": 0,
            "num_ontology_negative": int(negatives.shape[0]),
            "num_svd_negative": 0,
            "fallback_count": 0,
        }
        return (negatives, stats) if return_stats else negatives
    if mode == "three_level":
        return three_level_negative_sampling(
            pos_pairs,
            num_tsrna,
            num_disease,
            num_samples,
            exclusion_set,
            graph_data,
            seed,
            easy_negative_ratio=easy_negative_ratio,
            ontology_negative_ratio=ontology_negative_ratio,
            svd_negative_ratio=svd_negative_ratio,
            return_stats=return_stats,
        )
    if mode != "mixed":
        raise ValueError(f"Unknown negative sampling mode: {mode}")

    hard_count = int(round(num_samples * hard_negative_ratio))
    hard = ontology_hard_negative_sampling(pos_pairs, num_tsrna, num_disease, hard_count, exclusion_set, graph_data, seed)
    random_part = random_negative_sampling(
        num_tsrna,
        num_disease,
        num_samples - hard.shape[0],
        set(exclusion_set) | {(int(t), int(d)) for t, d in hard.tolist()},
        seed + 1234,
    )
    negatives = torch.cat([hard, random_part], dim=0)
    stats = {
        "num_easy_negative": int(random_part.shape[0]),
        "num_ontology_negative": int(hard.shape[0]),
        "num_svd_negative": 0,
        "fallback_count": 0,
    }
    return (negatives, stats) if return_stats else negatives


def split_edges(
    pos_pairs: torch.Tensor,
    seed: int,
    train_ratio: float = 0.8,
    val_ratio: float = 0.1,
    test_ratio: float = 0.1,
) -> dict[str, torch.Tensor]:
    ratio_sum = train_ratio + val_ratio + test_ratio
    if abs(ratio_sum - 1.0) > 1e-6:
        raise ValueError(f"Split ratios must sum to 1.0, got {ratio_sum}")

    num_edges = pos_pairs.shape[0]
    generator = torch.Generator().manual_seed(seed)
    perm = torch.randperm(num_edges, generator=generator)

    train_end = int(num_edges * train_ratio)
    val_end = train_end + int(num_edges * val_ratio)

    train_idx = perm[:train_end]
    val_idx = perm[train_end:val_end]
    test_idx = perm[val_end:]

    return {
        "train_pairs": pos_pairs[train_idx],
        "val_pairs": pos_pairs[val_idx],
        "test_pairs": pos_pairs[test_idx],
        "train_idx": train_idx,
        "val_idx": val_idx,
        "test_idx": test_idx,
    }


def split_edges_kfold(
    pos_pairs: torch.Tensor,
    seed: int,
    fold_id: int,
    num_folds: int,
    val_ratio: float = 0.1,
) -> dict[str, torch.Tensor]:
    if num_folds < 2:
        raise ValueError(f"num_folds must be >= 2, got {num_folds}")
    if fold_id < 0 or fold_id >= num_folds:
        raise ValueError(f"fold_id must be in [0, {num_folds - 1}], got {fold_id}")
    if not 0.0 < val_ratio < 1.0:
        raise ValueError(f"val_ratio must be between 0 and 1, got {val_ratio}")

    num_edges = pos_pairs.shape[0]
    generator = torch.Generator().manual_seed(seed)
    perm = torch.randperm(num_edges, generator=generator)
    folds = torch.tensor_split(perm, num_folds)

    test_idx = folds[fold_id]
    remaining = torch.cat([folds[idx] for idx in range(num_folds) if idx != fold_id], dim=0)

    val_generator = torch.Generator().manual_seed(seed + 100_000 + fold_id)
    remaining = remaining[torch.randperm(remaining.shape[0], generator=val_generator)]
    val_count = max(1, int(round(remaining.shape[0] * val_ratio)))
    val_idx = remaining[:val_count]
    train_idx = remaining[val_count:]

    return {
        "train_pairs": pos_pairs[train_idx],
        "val_pairs": pos_pairs[val_idx],
        "test_pairs": pos_pairs[test_idx],
        "train_idx": train_idx,
        "val_idx": val_idx,
        "test_idx": test_idx,
    }


def pairs_to_tensors(pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    if pairs.numel() == 0:
        return torch.empty(0, dtype=torch.long), torch.empty(0, dtype=torch.long)
    return pairs[:, 0].long(), pairs[:, 1].long()
