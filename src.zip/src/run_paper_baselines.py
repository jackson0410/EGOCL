from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.utils import ensure_dir, load_csv, save_csv


BASELINES = [
    {
        "name": "AGCLNDA_style",
        "description": (
            "Adaptive graph contrastive learning style baseline: train-fold SVD graph view, "
            "association GNN, contrastive objective, BPR ranking loss, and hard negative sampling."
        ),
        "flags": ["--use_svd_features", "--use_contrastive", "--use_bpr"],
        "options": {
            "decoder_type": "mlp",
            "negative_sampling": "mixed",
            "hard_negative_ratio": 0.5,
            "contrastive_weight": 0.2,
            "temperature": 0.2,
            "bpr_weight": 0.1,
        },
    },
    {
        "name": "MSMCDA_style",
        "description": (
            "Multi-source/multi-view similarity and attention-fusion style baseline using "
            "train-fold SVD features, evidence-gated association propagation, contrastive alignment, "
            "and a hybrid decoder."
        ),
        "flags": ["--use_evidence_gate", "--use_svd_features", "--use_contrastive"],
        "options": {
            "decoder_type": "hybrid",
            "negative_sampling": "mixed",
            "hard_negative_ratio": 0.3,
            "contrastive_weight": 0.1,
            "temperature": 0.2,
        },
    },
    {
        "name": "HybridGNN_style",
        "description": (
            "Hybrid GCN/GAT plus matrix-factorization style baseline approximated with "
            "evidence-gated association propagation, train-fold SVD features, and a hybrid decoder."
        ),
        "flags": ["--use_evidence_gate", "--use_svd_features"],
        "options": {
            "decoder_type": "hybrid",
            "negative_sampling": "random",
        },
    },
    {
        "name": "DualVGAE_style",
        "description": (
            "Dual variational graph/reconstruction style baseline approximated with train-fold "
            "SVD reconstructed features, association-graph propagation, BPR ranking, and a hybrid decoder."
        ),
        "flags": ["--use_svd_features", "--use_bpr"],
        "options": {
            "decoder_type": "hybrid",
            "negative_sampling": "mixed",
            "hard_negative_ratio": 0.3,
            "bpr_weight": 0.1,
        },
    },
    {
        "name": "GCLNSTDA_style",
        "description": "Association-graph contrastive baseline with SVD-reconstructed graph view and hard negative sampling.",
        "flags": ["--use_svd_features", "--use_contrastive"],
        "options": {
            "decoder_type": "mlp",
            "negative_sampling": "mixed",
            "hard_negative_ratio": 0.3,
            "contrastive_weight": 0.1,
            "temperature": 0.2,
        },
    },
    {
        "name": "CLTDA_style",
        "description": "SVD reconstruction + association GCN + contrastive learning + BPR with SVD-biased negatives.",
        "flags": ["--use_svd_features", "--use_contrastive", "--use_bpr"],
        "options": {
            "decoder_type": "mlp",
            "negative_sampling": "three_level",
            "easy_negative_ratio": 0.5,
            "ontology_negative_ratio": 0.0,
            "svd_negative_ratio": 0.5,
            "contrastive_weight": 0.1,
            "temperature": 0.2,
            "bpr_weight": 0.1,
        },
    },
    {
        "name": "ERFMTDA_style",
        "description": "Enhanced factorization-machine style baseline using train-fold SVD features without GNN message passing.",
        "flags": ["--use_svd_features"],
        "options": {
            "decoder_type": "hybrid",
            "negative_sampling": "random",
            "num_layers": 0,
        },
    },
]

SUMMARY_FIELDS = [
    "model",
    "auc_mean",
    "auc_std",
    "aupr_mean",
    "aupr_std",
    "selected_f1_mean",
    "selected_f1_std",
    "precision_mean",
    "precision_std",
    "recall_mean",
    "recall_std",
    "best_val_aupr_mean",
    "best_val_aupr_std",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run paper-style baseline comparisons for EGO-CLGNN.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", default="results/paper_baselines")
    parser.add_argument("--full_reference_dir", default="results/selected_ablation/Full_EGO_CLGNN")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--svd_dim", type=int, default=64)
    parser.add_argument("--svd_topk", type=int, default=20)
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--quick_test", action="store_true")
    parser.add_argument("--skip_existing", action="store_true")
    return parser.parse_args()


def add_bool_flag(command: list[str], flag: str, enabled: bool = True) -> None:
    if enabled:
        command.append(flag)


def add_option(command: list[str], name: str, value: object) -> None:
    command.extend([name, str(value)])


def metric_lookup(mean_std_path: Path) -> dict[str, tuple[float, float]]:
    rows = load_csv(mean_std_path)
    return {row["metric"]: (float(row["mean"]), float(row["std"])) for row in rows}


def metrics_to_row(model_name: str, mean_std_path: Path) -> dict[str, float | str]:
    metrics = metric_lookup(mean_std_path)
    return {
        "model": model_name,
        "auc_mean": metrics["test_auc"][0],
        "auc_std": metrics["test_auc"][1],
        "aupr_mean": metrics["test_aupr"][0],
        "aupr_std": metrics["test_aupr"][1],
        "selected_f1_mean": metrics["test_selected_threshold_f1"][0],
        "selected_f1_std": metrics["test_selected_threshold_f1"][1],
        "precision_mean": metrics["test_selected_threshold_precision"][0],
        "precision_std": metrics["test_selected_threshold_precision"][1],
        "recall_mean": metrics["test_selected_threshold_recall"][0],
        "recall_std": metrics["test_selected_threshold_recall"][1],
        "best_val_aupr_mean": metrics["best_val_aupr"][0],
        "best_val_aupr_std": metrics["best_val_aupr"][1],
    }


def save_baseline_manifest(output_dir: Path) -> None:
    rows = [{"model": item["name"], "description": item["description"]} for item in BASELINES]
    rows.insert(
        0,
        {
            "model": "EGO_CLGNN",
            "description": "Final tuned EGO-CLGNN reference; copied from selected ablation Full_EGO_CLGNN when available.",
        },
    )
    save_csv(rows, output_dir / "baseline_manifest.csv", ["model", "description"])


def run_cv_for_baseline(args: argparse.Namespace, baseline: dict[str, object], output_dir: Path) -> None:
    name = str(baseline["name"])
    baseline_dir = output_dir / name
    if args.skip_existing and (baseline_dir / "cv_mean_std.csv").exists():
        print(f"[run_paper_baselines] skipping existing baseline: {name}", flush=True)
        return

    ensure_dir(baseline_dir)
    options = dict(baseline.get("options", {}))
    effective_num_layers = int(options.pop("num_layers", args.num_layers))
    command = [
        sys.executable,
        str(ROOT / "src" / "run_cv_clgnn.py"),
        "--data_dir",
        args.data_dir,
        "--output_dir",
        str(baseline_dir),
        "--num_folds",
        str(args.num_folds),
        "--epochs",
        str(args.epochs),
        "--lr",
        str(args.lr),
        "--weight_decay",
        str(args.weight_decay),
        "--hidden_dim",
        str(args.hidden_dim),
        "--num_layers",
        str(effective_num_layers),
        "--dropout",
        str(args.dropout),
        "--batch_size",
        str(args.batch_size),
        "--seed",
        str(args.seed),
        "--patience",
        str(args.patience),
        "--device",
        args.device,
        "--svd_dim",
        str(args.svd_dim),
        "--svd_topk",
        str(args.svd_topk),
        "--threshold_search",
        args.threshold_search,
    ]
    for flag in baseline.get("flags", []):
        add_bool_flag(command, str(flag))
    for key, value in options.items():
        add_option(command, f"--{key}", value)

    print(f"[run_paper_baselines] starting baseline: {name}", flush=True)
    subprocess.run(command, cwd=ROOT, check=True)
    print(f"[run_paper_baselines] completed baseline: {name}", flush=True)


def copy_full_reference(args: argparse.Namespace, output_dir: Path) -> Path | None:
    reference_dir = Path(args.full_reference_dir)
    if args.quick_test:
        return None
    if not (reference_dir / "cv_mean_std.csv").exists():
        print(f"[run_paper_baselines] full reference missing, skipped: {reference_dir}", flush=True)
        return None
    target_dir = output_dir / "EGO_CLGNN"
    if not target_dir.exists():
        shutil.copytree(reference_dir, target_dir)
    elif not (target_dir / "cv_mean_std.csv").exists():
        raise FileExistsError(f"Reference target exists but is incomplete: {target_dir}")
    return target_dir


def write_summary(output_dir: Path, full_reference: Path | None) -> None:
    rows = []
    if full_reference is not None and (full_reference / "cv_mean_std.csv").exists():
        rows.append(metrics_to_row("EGO_CLGNN", full_reference / "cv_mean_std.csv"))
    for baseline in BASELINES:
        name = str(baseline["name"])
        mean_std_path = output_dir / name / "cv_mean_std.csv"
        if mean_std_path.exists():
            rows.append(metrics_to_row(name, mean_std_path))
    if not rows:
        raise FileNotFoundError(f"No baseline cv_mean_std.csv files found under {output_dir}")
    save_csv(rows, output_dir / "paper_baseline_summary.csv", SUMMARY_FIELDS)

    full = next((row for row in rows if row["model"] == "EGO_CLGNN"), None)
    if full is None:
        print("[run_paper_baselines] delta skipped; EGO_CLGNN reference row missing", flush=True)
        return
    delta_rows = []
    for row in rows:
        delta_rows.append(
            {
                "model": row["model"],
                "delta_auc": float(full["auc_mean"]) - float(row["auc_mean"]),
                "delta_aupr": float(full["aupr_mean"]) - float(row["aupr_mean"]),
                "delta_selected_f1": float(full["selected_f1_mean"]) - float(row["selected_f1_mean"]),
                "delta_precision": float(full["precision_mean"]) - float(row["precision_mean"]),
                "delta_recall": float(full["recall_mean"]) - float(row["recall_mean"]),
            }
        )
    save_csv(
        delta_rows,
        output_dir / "paper_baseline_delta.csv",
        ["model", "delta_auc", "delta_aupr", "delta_selected_f1", "delta_precision", "delta_recall"],
    )


def main() -> None:
    args = parse_args()
    if args.quick_test and args.output_dir == "results/paper_baselines":
        args.output_dir = "results/paper_baselines_quick_test"
        args.num_folds = min(args.num_folds, 2)

    output_dir = ensure_dir(args.output_dir)
    save_baseline_manifest(output_dir)
    full_reference = copy_full_reference(args, output_dir)

    for baseline in BASELINES:
        run_cv_for_baseline(args, baseline, output_dir)
        summarize_cv(output_dir / str(baseline["name"]))

    write_summary(output_dir, full_reference)
    print(f"[run_paper_baselines] outputs written to: {output_dir}", flush=True)


if __name__ == "__main__":
    main()
