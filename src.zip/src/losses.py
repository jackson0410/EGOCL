from __future__ import annotations

import torch
import torch.nn.functional as F


def info_nce_loss(view1: torch.Tensor, view2: torch.Tensor, temperature: float = 0.2) -> torch.Tensor:
    if view1.shape[0] == 0:
        return view1.new_tensor(0.0)
    z1 = F.normalize(view1, dim=-1)
    z2 = F.normalize(view2, dim=-1)
    logits = z1 @ z2.T / temperature
    labels = torch.arange(z1.shape[0], device=z1.device)
    return 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.T, labels))


def attribute_contrastive_loss(
    h_graph: torch.Tensor,
    h_attr: torch.Tensor,
    valid_mask: torch.Tensor | None = None,
    temperature: float = 0.2,
) -> torch.Tensor:
    if h_graph.shape[0] == 0:
        return h_graph.new_tensor(0.0)
    if valid_mask is not None:
        valid_mask = valid_mask.bool()
        h_graph = h_graph[valid_mask]
        h_attr = h_attr[valid_mask]
    if h_graph.shape[0] < 2:
        return h_graph.new_tensor(0.0)
    temperature = max(float(temperature), 1e-6)
    z_graph = F.normalize(h_graph, p=2, dim=-1, eps=1e-8)
    z_attr = F.normalize(h_attr, p=2, dim=-1, eps=1e-8)
    logits = z_graph @ z_attr.T / temperature
    labels = torch.arange(z_graph.shape[0], device=z_graph.device)
    loss = 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.T, labels))
    return torch.nan_to_num(loss, nan=0.0, posinf=0.0, neginf=0.0)


def bpr_loss(pos_score: torch.Tensor, neg_score: torch.Tensor) -> torch.Tensor:
    count = min(pos_score.shape[0], neg_score.shape[0])
    if count == 0:
        return pos_score.new_tensor(0.0)
    return -F.logsigmoid(pos_score[:count] - neg_score[:count]).mean()


def smooth_labels(labels: torch.Tensor, label_smoothing: float = 0.0) -> torch.Tensor:
    if label_smoothing <= 0.0:
        return labels.float()
    smoothing = min(max(label_smoothing, 0.0), 0.49)
    return labels.float() * (1.0 - smoothing) + (1.0 - labels.float()) * smoothing


def weighted_bce_with_logits(
    logits: torch.Tensor,
    labels: torch.Tensor,
    label_smoothing: float = 0.0,
    pos_weight: float = 1.0,
) -> torch.Tensor:
    targets = smooth_labels(labels, label_smoothing)
    loss = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    if pos_weight != 1.0:
        weights = torch.where(labels.float() > 0.5, logits.new_tensor(pos_weight), logits.new_tensor(1.0))
        loss = loss * weights
    return loss.mean()


def focal_bce_with_logits(
    logits: torch.Tensor,
    labels: torch.Tensor,
    label_smoothing: float = 0.0,
    alpha: float = 0.75,
    gamma: float = 2.0,
) -> torch.Tensor:
    targets = smooth_labels(labels, label_smoothing)
    bce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
    prob = torch.sigmoid(logits)
    pt = prob * targets + (1.0 - prob) * (1.0 - targets)
    alpha_t = alpha * targets + (1.0 - alpha) * (1.0 - targets)
    focal_weight = alpha_t * (1.0 - pt).clamp(min=0.0).pow(gamma)
    return (focal_weight * bce).mean()


def soft_f1_loss(logits: torch.Tensor, labels: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    prob = torch.sigmoid(logits)
    labels = labels.float()
    tp = torch.sum(prob * labels)
    fp = torch.sum(prob * (1.0 - labels))
    fn = torch.sum((1.0 - prob) * labels)
    soft_f1 = (2.0 * tp) / (2.0 * tp + fp + fn + eps)
    return 1.0 - soft_f1


def classification_loss_with_options(
    logits: torch.Tensor,
    labels: torch.Tensor,
    label_smoothing: float = 0.0,
    pos_weight: float = 1.0,
    use_focal_loss: bool = False,
    focal_alpha: float = 0.75,
    focal_gamma: float = 2.0,
) -> torch.Tensor:
    if use_focal_loss:
        return focal_bce_with_logits(logits, labels, label_smoothing, focal_alpha, focal_gamma)
    return weighted_bce_with_logits(logits, labels, label_smoothing, pos_weight)
