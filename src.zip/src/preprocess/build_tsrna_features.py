from __future__ import annotations

import argparse
import itertools
import json
import math
import re
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, load_csv


UNKNOWN = "Unknown"
VALID_BASES = set("AUCG")
SOURCE_PATTERNS = [
    re.compile(r"(tRNA-[A-Za-z]+[-_][A-Za-z]+(?:[-_][0-9]+)*(?:[-_][0-9]+)?)"),
    re.compile(r"(tRNA-[A-Za-z]+[A-Za-z]{3}(?:[_-]n?[0-9]+)?)"),
]
LENGTH_PATTERNS = [
    re.compile(r"tRF-(\d+)-"),
    re.compile(r"_L(\d+)\b"),
    re.compile(r"[-_](\d{2})$"),
]
TYPE_PATTERNS = [
    (re.compile(r"5['-]?[-_]?M|^5P|tRF-5", re.IGNORECASE), "tRF-5"),
    (re.compile(r"3['-]?[-_]?M|^3P|tRF-3", re.IGNORECASE), "tRF-3"),
    (re.compile(r"i[-_]?tRF", re.IGNORECASE), "i-tRF"),
    (re.compile(r"5['-]?[-_]?tiRNA", re.IGNORECASE), "5'-tiRNA"),
    (re.compile(r"3['-]?[-_]?tiRNA", re.IGNORECASE), "3'-tiRNA"),
]
AMINO_CODES = {
    "Ala",
    "Arg",
    "Asn",
    "Asp",
    "Cys",
    "Gln",
    "Glu",
    "Gly",
    "His",
    "Ile",
    "Leu",
    "Lys",
    "Met",
    "Phe",
    "Pro",
    "Ser",
    "Thr",
    "Trp",
    "Tyr",
    "Val",
    "iMet",
}


def clean_value(value: object) -> str:
    text = str(value or "").strip()
    if not text or text.upper() == "N/A" or text.lower() in {"na", "nan", "none"}:
        return UNKNOWN
    return text


def first_existing(row: dict[str, str], names: list[str]) -> str:
    for name in names:
        if name in row:
            value = clean_value(row.get(name))
            if value != UNKNOWN:
                return value
    return UNKNOWN


def normalize_sequence(value: str) -> str:
    if clean_value(value) == UNKNOWN:
        return UNKNOWN
    seq = str(value).upper().replace("T", "U")
    seq = "".join(base for base in seq if base in VALID_BASES)
    return seq if seq else UNKNOWN


def infer_length(row: dict[str, str], sequence: str) -> tuple[float, bool]:
    direct = first_existing(row, ["length", "Length"])
    if direct != UNKNOWN:
        try:
            value = float(direct)
            if value > 0:
                return value, True
        except ValueError:
            pass
    if sequence != UNKNOWN:
        return float(len(sequence)), True
    name = first_existing(row, ["tsrna_name", "tsRNA_Name", "name"])
    for pattern in LENGTH_PATTERNS:
        match = pattern.search(name)
        if match:
            return float(match.group(1)), True
    return 0.0, False


def infer_type(row: dict[str, str]) -> tuple[str, bool]:
    value = first_existing(row, ["tsrna_type", "tsRNA_Type", "type"])
    if value != UNKNOWN:
        return value, True
    name = first_existing(row, ["tsrna_name", "tsRNA_Name", "name"])
    for pattern, label in TYPE_PATTERNS:
        if pattern.search(name):
            return label, True
    return UNKNOWN, False


def infer_source_tRNA(row: dict[str, str]) -> tuple[str, bool]:
    value = first_existing(row, ["source_tRNA", "source_trna", "source_tRNA_id", "trfdb_id", "tRFdb_ID"])
    if value != UNKNOWN:
        return value, True
    name = first_existing(row, ["tsrna_name", "tsRNA_Name", "name"])
    for pattern in SOURCE_PATTERNS:
        match = pattern.search(name)
        if match:
            return match.group(1), True
    return UNKNOWN, False


def infer_anticodon(row: dict[str, str]) -> tuple[str, bool]:
    value = first_existing(row, ["anticodon", "Anticodon"])
    if value != UNKNOWN:
        return value, True
    candidates = " ".join(
        first_existing(row, [name])
        for name in ["tsrna_name", "tsRNA_Name", "trfdb_id", "tRFdb_ID", "source_tRNA"]
        if name in row
    )
    match = re.search(r"([A-Z][a-z]{2})([ACGTU]{3})", candidates)
    if match:
        return f"{match.group(1)}{match.group(2).replace('T', 'U')}", True
    return UNKNOWN, False


def infer_amino(row: dict[str, str], anticodon: str) -> tuple[str, bool]:
    value = first_existing(row, ["amino_acid", "aminoacid", "Aminoacid", "amino"])
    if value != UNKNOWN:
        return value, True
    if anticodon != UNKNOWN:
        for code in sorted(AMINO_CODES, key=len, reverse=True):
            if anticodon.startswith(code):
                return code, True
    name = first_existing(row, ["tsrna_name", "tsRNA_Name", "name", "trfdb_id", "tRFdb_ID"])
    match = re.search(r"tRNA[-_]?([A-Za-z]{3,4})", name)
    if match:
        candidate = match.group(1)
        for code in AMINO_CODES:
            if candidate.startswith(code):
                return code, True
    return UNKNOWN, False


def infer_species(row: dict[str, str]) -> tuple[str, bool]:
    value = first_existing(row, ["species", "Species", "organism", "Organism"])
    if value != UNKNOWN:
        return value, True
    return UNKNOWN, False


def build_vocab(k: int) -> list[str]:
    return ["".join(items) for items in itertools.product("AUCG", repeat=k)]


def kmer_vector(sequence: str, vocab: list[str], k: int) -> list[float]:
    counts = [0.0] * len(vocab)
    if sequence == UNKNOWN or len(sequence) < k:
        return counts
    index = {kmer: idx for idx, kmer in enumerate(vocab)}
    total = 0
    for start in range(0, len(sequence) - k + 1):
        kmer = sequence[start : start + k]
        if all(base in VALID_BASES for base in kmer):
            counts[index[kmer]] += 1.0
            total += 1
    if total > 0:
        counts = [value / total for value in counts]
    return counts


def category_ids(values: list[str]) -> tuple[torch.Tensor, dict[str, int]]:
    unique = [UNKNOWN] + sorted({value for value in values if value != UNKNOWN})
    mapping = {value: idx for idx, value in enumerate(unique)}
    ids = torch.tensor([mapping.get(value, 0) for value in values], dtype=torch.long)
    return ids, mapping


def standardize_lengths(lengths: list[float], available: list[bool]) -> torch.Tensor:
    observed = [value for value, ok in zip(lengths, available) if ok and value > 0]
    if not observed:
        return torch.zeros((len(lengths), 1), dtype=torch.float32)
    mean = sum(observed) / len(observed)
    variance = sum((value - mean) ** 2 for value in observed) / max(1, len(observed) - 1)
    std = math.sqrt(variance) if variance > 0 else 1.0
    standardized = [((value - mean) / std) if ok and value > 0 else 0.0 for value, ok in zip(lengths, available)]
    return torch.tensor(standardized, dtype=torch.float32).unsqueeze(1)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build intrinsic tsRNA attribute tensors.")
    parser.add_argument("--data_dir", default="data/processed")
    parser.add_argument("--kmer", type=int, default=3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data_dir = Path(args.data_dir)
    tensor_dir = ensure_dir(data_dir / "tensors")
    tsrna_path = data_dir / "tsrna.csv"
    if not tsrna_path.exists():
        raise FileNotFoundError(f"Missing tsRNA table: {tsrna_path}")

    rows = load_csv(tsrna_path)
    vocab = build_vocab(args.kmer)

    sequences: list[str] = []
    lengths: list[float] = []
    length_available: list[bool] = []
    types: list[str] = []
    sources: list[str] = []
    anticodons: list[str] = []
    aminos: list[str] = []
    species_values: list[str] = []
    masks: list[list[float]] = []

    for row in rows:
        sequence = normalize_sequence(first_existing(row, ["sequence", "Sequence"]))
        length, has_length = infer_length(row, sequence)
        tsrna_type, has_type = infer_type(row)
        source, has_source = infer_source_tRNA(row)
        anticodon, has_anticodon = infer_anticodon(row)
        amino, has_amino = infer_amino(row, anticodon)
        species, has_species = infer_species(row)

        sequences.append(sequence)
        lengths.append(length)
        length_available.append(has_length)
        types.append(tsrna_type)
        sources.append(source)
        anticodons.append(anticodon)
        aminos.append(amino)
        species_values.append(species)
        masks.append(
            [
                1.0 if sequence != UNKNOWN else 0.0,
                1.0 if has_length else 0.0,
                1.0 if has_type else 0.0,
                1.0 if has_source else 0.0,
                1.0 if has_anticodon else 0.0,
                1.0 if has_amino else 0.0,
                1.0 if has_species else 0.0,
            ]
        )

    kmer_features = torch.tensor([kmer_vector(seq, vocab, args.kmer) for seq in sequences], dtype=torch.float32)
    length_tensor = standardize_lengths(lengths, length_available)
    type_ids, type_mapping = category_ids(types)
    source_ids, source_mapping = category_ids(sources)
    anticodon_ids, anticodon_mapping = category_ids(anticodons)
    amino_ids, amino_mapping = category_ids(aminos)
    species_ids, species_mapping = category_ids(species_values)
    attr_mask = torch.tensor(masks, dtype=torch.float32)

    torch.save(kmer_features, tensor_dir / "tsrna_kmer_features.pt")
    torch.save(length_tensor, tensor_dir / "tsrna_length.pt")
    torch.save(type_ids, tensor_dir / "tsrna_type_ids.pt")
    torch.save(source_ids, tensor_dir / "tsrna_source_ids.pt")
    torch.save(anticodon_ids, tensor_dir / "tsrna_anticodon_ids.pt")
    torch.save(amino_ids, tensor_dir / "tsrna_amino_ids.pt")
    torch.save(species_ids, tensor_dir / "tsrna_species_ids.pt")
    torch.save(attr_mask, tensor_dir / "tsrna_attr_mask.pt")

    complete_attr = (attr_mask.sum(dim=1) == attr_mask.shape[1]).sum().item()
    any_missing = (attr_mask.sum(dim=1) < attr_mask.shape[1]).sum().item()
    meta = {
        "num_tsrna": len(rows),
        "kmer_size": args.kmer,
        "kmer_vocabulary": vocab,
        "kmer_dim": len(vocab),
        "num_tsrna_types": len(type_mapping),
        "num_source_tRNAs": len(source_mapping),
        "num_anticodons": len(anticodon_mapping),
        "num_amino_acid_families": len(amino_mapping),
        "num_species": len(species_mapping),
        "sequence_available_count": int(attr_mask[:, 0].sum().item()),
        "length_available_count": int(attr_mask[:, 1].sum().item()),
        "type_available_count": int(attr_mask[:, 2].sum().item()),
        "source_tRNA_available_count": int(attr_mask[:, 3].sum().item()),
        "anticodon_available_count": int(attr_mask[:, 4].sum().item()),
        "amino_acid_available_count": int(attr_mask[:, 5].sum().item()),
        "species_available_count": int(attr_mask[:, 6].sum().item()),
        "complete_attribute_count": int(complete_attr),
        "missing_attribute_count": int(any_missing),
        "mask_columns": ["sequence", "length", "tsrna_type", "source_tRNA", "anticodon", "amino_acid", "species"],
        "categorical_mappings": {
            "tsrna_type": type_mapping,
            "source_tRNA": source_mapping,
            "anticodon": anticodon_mapping,
            "amino_acid": amino_mapping,
            "species": species_mapping,
        },
    }
    with (tensor_dir / "tsrna_attr_meta.json").open("w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)

    print(f"[build_tsrna_features] output directory: {tensor_dir}")
    print(f"[build_tsrna_features] num_tsrna: {len(rows)}")
    print(f"[build_tsrna_features] kmer_dim: {len(vocab)}")
    print(f"[build_tsrna_features] sequence available: {meta['sequence_available_count']}")
    print(f"[build_tsrna_features] type available: {meta['type_available_count']}")
    print(f"[build_tsrna_features] source tRNA available: {meta['source_tRNA_available_count']}")
    print(f"[build_tsrna_features] anticodon available: {meta['anticodon_available_count']}")
    print(f"[build_tsrna_features] amino acid available: {meta['amino_acid_available_count']}")
    print(f"[build_tsrna_features] species available: {meta['species_available_count']}")


if __name__ == "__main__":
    main()
