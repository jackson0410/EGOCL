from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, normalize_disease_name, save_csv


RAW_PATH = ROOT / "data" / "raw" / "doid.obo"
OUT_DIR = ROOT / "data" / "processed"
IS_A_RE = re.compile(r"^is_a:\s+(\S+)")
SYNONYM_RE = re.compile(r'^synonym:\s+"(.*?)"\s+(\S+)')


def parse_term(lines: list[str]) -> dict | None:
    if not lines:
        return None

    term = {
        "doid_id": "",
        "doid_name": "",
        "is_obsolete": False,
        "alt_ids": [],
        "parents": [],
        "synonyms": [],
    }

    for line in lines:
        line = line.strip()
        if line.startswith("id: "):
            term["doid_id"] = line.removeprefix("id: ").strip()
        elif line.startswith("name: "):
            term["doid_name"] = line.removeprefix("name: ").strip()
        elif line.startswith("alt_id: "):
            term["alt_ids"].append(line.removeprefix("alt_id: ").strip())
        elif line == "is_obsolete: true":
            term["is_obsolete"] = True
        else:
            match = IS_A_RE.match(line)
            if match:
                term["parents"].append(match.group(1))
                continue

            match = SYNONYM_RE.match(line)
            if match:
                term["synonyms"].append(
                    {
                        "synonym": match.group(1).strip(),
                        "synonym_scope": match.group(2).strip(),
                    }
                )

    if not term["doid_id"] or not term["doid_name"]:
        return None
    return term


def parse_obo(path: Path) -> list[dict]:
    terms: list[dict] = []
    current: list[str] | None = None

    with path.open("r", encoding="utf-8") as f:
        for raw_line in f:
            line = raw_line.rstrip("\n")
            if line == "[Term]":
                parsed = parse_term(current or [])
                if parsed:
                    terms.append(parsed)
                current = []
            elif line.startswith("[") and line.endswith("]"):
                parsed = parse_term(current or [])
                if parsed:
                    terms.append(parsed)
                current = None
            elif current is not None:
                current.append(line)

    parsed = parse_term(current or [])
    if parsed:
        terms.append(parsed)

    return terms


def main() -> None:
    ensure_dir(OUT_DIR)
    terms = parse_obo(RAW_PATH)

    active_terms = [term for term in terms if not term["is_obsolete"]]
    active_ids = {term["doid_id"] for term in active_terms}

    term_rows = [
        {
            "doid_id": term["doid_id"],
            "doid_name": term["doid_name"],
            "normalized_name": normalize_disease_name(term["doid_name"]),
            "is_obsolete": int(term["is_obsolete"]),
            "alt_ids": "//".join(term["alt_ids"]) if term["alt_ids"] else "N/A",
        }
        for term in active_terms
    ]

    edge_rows = []
    dropped_edges = 0
    seen_edges = set()
    for term in active_terms:
        child_id = term["doid_id"]
        for parent_id in term["parents"]:
            if parent_id not in active_ids:
                dropped_edges += 1
                continue
            edge = (child_id, parent_id)
            if edge in seen_edges:
                continue
            seen_edges.add(edge)
            edge_rows.append({"child_doid_id": child_id, "parent_doid_id": parent_id})

    synonym_rows = []
    seen_synonyms = set()
    for term in active_terms:
        for synonym in term["synonyms"]:
            normalized_synonym = normalize_disease_name(synonym["synonym"])
            key = (term["doid_id"], normalized_synonym, synonym["synonym_scope"])
            if not normalized_synonym or key in seen_synonyms:
                continue
            seen_synonyms.add(key)
            synonym_rows.append(
                {
                    "doid_id": term["doid_id"],
                    "synonym": synonym["synonym"],
                    "synonym_scope": synonym["synonym_scope"],
                    "normalized_synonym": normalized_synonym,
                }
            )

    save_csv(
        term_rows,
        OUT_DIR / "doid_terms.csv",
        ["doid_id", "doid_name", "normalized_name", "is_obsolete", "alt_ids"],
    )
    save_csv(edge_rows, OUT_DIR / "doid_edges.csv", ["child_doid_id", "parent_doid_id"])
    save_csv(
        synonym_rows,
        OUT_DIR / "doid_synonyms.csv",
        ["doid_id", "synonym", "synonym_scope", "normalized_synonym"],
    )

    print(f"[parse_doid] raw terms: {len(terms)}")
    print(f"[parse_doid] active terms: {len(active_terms)}")
    print(f"[parse_doid] obsolete terms removed: {len(terms) - len(active_terms)}")
    print(f"[parse_doid] active is_a edges: {len(edge_rows)}")
    print(f"[parse_doid] active synonyms: {len(synonym_rows)}")
    print(f"[parse_doid] edges dropped because parent is obsolete/missing: {dropped_edges}")
    print(f"[parse_doid] outputs written to: {OUT_DIR}")


if __name__ == "__main__":
    main()
