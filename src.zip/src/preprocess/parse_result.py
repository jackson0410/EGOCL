from __future__ import annotations

import sys
from collections import Counter, OrderedDict, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, load_csv, save_csv


RAW_PATH = ROOT / "data" / "raw" / "result1.csv"
OUT_DIR = ROOT / "data" / "processed"

CONFIDENCE_RANK = {
    "very high": 5,
    "high": 4,
    "median": 3,
    "medium": 3,
    "moderate": 3,
    "low": 2,
    "very low": 1,
    "n/a": 0,
    "na": 0,
    "": 0,
}


def clean_value(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_way(value: str) -> str:
    return clean_value(value)


def normalize_missing(value: str) -> str:
    value = clean_value(value)
    return value if value else "N/A"


def confidence_score(value: str) -> int:
    return CONFIDENCE_RANK.get(clean_value(value).lower(), 0)


def join_unique(values: list[str]) -> str:
    seen: OrderedDict[str, None] = OrderedDict()
    for value in values:
        value = normalize_missing(value)
        if value.upper() == "N/A":
            continue
        seen[value] = None
    return "//".join(seen.keys()) if seen else "N/A"


def best_confidence(values: list[str]) -> str:
    cleaned = [normalize_missing(value) for value in values]
    return max(cleaned, key=confidence_score) if cleaned else "N/A"


def collect_entities(rows: list[dict[str, str]]) -> tuple[dict[str, dict], dict[str, dict]]:
    tsrna_info: OrderedDict[str, dict] = OrderedDict()
    disease_info: OrderedDict[str, dict] = OrderedDict()
    disease_extra = defaultdict(lambda: defaultdict(list))

    for row in rows:
        tsrna_name = clean_value(row.get("tsRNA_Name"))
        disease_name = clean_value(row.get("Disease")) or clean_value(row.get("Disease_Name1"))
        if not tsrna_name or not disease_name:
            continue

        if tsrna_name not in tsrna_info:
            tsrna_info[tsrna_name] = {
                "tsrna_name": tsrna_name,
                "sequence": normalize_missing(row.get("Sequence", "")),
                "anticodon": normalize_missing(row.get("Anticodon", "")),
                "tsrna_type": normalize_missing(row.get("tsRNA_Type", "")),
                "aminoacid": normalize_missing(row.get("Aminoacid", "")),
                "mintbase_id": normalize_missing(row.get("MINTbase_ID", "")),
                "trfdb_id": normalize_missing(row.get("tRFdb_ID", "")),
            }

        for field in ("Disease_Name1", "Disease_Name2", "Tissue", "Type1"):
            disease_extra[disease_name][field].append(row.get(field, ""))

        if disease_name not in disease_info:
            disease_info[disease_name] = {
                "disease_name": disease_name,
            }

    tsrna_rows: list[dict] = []
    for idx, (_, info) in enumerate(tsrna_info.items()):
        tsrna_rows.append({"tsrna_id": idx, **info})

    disease_rows: list[dict] = []
    for idx, (disease_name, info) in enumerate(disease_info.items()):
        disease_rows.append(
            {
                "disease_id": idx,
                **info,
                "disease_name1": join_unique(disease_extra[disease_name]["Disease_Name1"]),
                "disease_name2": join_unique(disease_extra[disease_name]["Disease_Name2"]),
                "tissue": join_unique(disease_extra[disease_name]["Tissue"]),
                "type1": join_unique(disease_extra[disease_name]["Type1"]),
            }
        )

    return (
        {row["tsrna_name"]: row for row in tsrna_rows},
        {row["disease_name"]: row for row in disease_rows},
    )


def aggregate_edges(
    rows: list[dict[str, str]],
    tsrna_by_name: dict[str, dict],
    disease_by_name: dict[str, dict],
    way: str,
) -> list[dict]:
    grouped: OrderedDict[tuple[str, str], list[dict[str, str]]] = OrderedDict()

    for row in rows:
        if normalize_way(row.get("Way", "")) != way:
            continue
        tsrna_name = clean_value(row.get("tsRNA_Name"))
        disease_name = clean_value(row.get("Disease")) or clean_value(row.get("Disease_Name1"))
        if not tsrna_name or not disease_name:
            continue
        grouped.setdefault((tsrna_name, disease_name), []).append(row)

    edge_rows: list[dict] = []
    for idx, ((tsrna_name, disease_name), records) in enumerate(grouped.items()):
        tsrna_id = tsrna_by_name[tsrna_name]["tsrna_id"]
        disease_id = disease_by_name[disease_name]["disease_id"]
        confidences = [record.get("Confidence", "") for record in records]

        edge_rows.append(
            {
                "edge_id": idx,
                "tsrna_id": tsrna_id,
                "disease_id": disease_id,
                "tsrna_name": tsrna_name,
                "disease_name": disease_name,
                "confidence": best_confidence(confidences),
                "confidence_values": join_unique(confidences),
                "strong_evidence": join_unique([record.get("Strong_Evidence", "") for record in records]),
                "weak_evidence": join_unique([record.get("Weak_Evidence", "") for record in records]),
                "method": join_unique([record.get("Method", "") for record in records]),
                "database_id": join_unique([record.get("Database_ID", "") for record in records]),
                "way": way,
                "evidence_count": len(records),
            }
        )

    return edge_rows


def main() -> None:
    ensure_dir(OUT_DIR)
    rows = load_csv(RAW_PATH)

    tsrna_by_name, disease_by_name = collect_entities(rows)
    associations = aggregate_edges(rows, tsrna_by_name, disease_by_name, "Experimental")
    weak_edges = aggregate_edges(rows, tsrna_by_name, disease_by_name, "Prediction")

    supervised_pairs = {(row["tsrna_id"], row["disease_id"]) for row in associations}
    for row in associations:
        row["label"] = 1
    for row in weak_edges:
        row["edge_type"] = "weak_prediction"
        row["has_supervised_positive"] = int((row["tsrna_id"], row["disease_id"]) in supervised_pairs)

    tsrna_rows = sorted(tsrna_by_name.values(), key=lambda x: x["tsrna_id"])
    disease_rows = sorted(disease_by_name.values(), key=lambda x: x["disease_id"])

    save_csv(
        tsrna_rows,
        OUT_DIR / "tsrna.csv",
        [
            "tsrna_id",
            "tsrna_name",
            "sequence",
            "anticodon",
            "tsrna_type",
            "aminoacid",
            "mintbase_id",
            "trfdb_id",
        ],
    )
    save_csv(
        disease_rows,
        OUT_DIR / "disease.csv",
        ["disease_id", "disease_name", "disease_name1", "disease_name2", "tissue", "type1"],
    )
    save_csv(
        associations,
        OUT_DIR / "associations.csv",
        [
            "edge_id",
            "tsrna_id",
            "disease_id",
            "tsrna_name",
            "disease_name",
            "label",
            "confidence",
            "confidence_values",
            "strong_evidence",
            "weak_evidence",
            "method",
            "database_id",
            "way",
            "evidence_count",
        ],
    )
    save_csv(
        weak_edges,
        OUT_DIR / "weak_edges.csv",
        [
            "edge_id",
            "tsrna_id",
            "disease_id",
            "tsrna_name",
            "disease_name",
            "edge_type",
            "has_supervised_positive",
            "confidence",
            "confidence_values",
            "strong_evidence",
            "weak_evidence",
            "method",
            "database_id",
            "way",
            "evidence_count",
        ],
    )

    way_counts = Counter(normalize_way(row.get("Way", "")) or "N/A" for row in rows)
    duplicate_experimental = sum(row["evidence_count"] - 1 for row in associations)
    duplicate_prediction = sum(row["evidence_count"] - 1 for row in weak_edges)

    print(f"[parse_result] input rows: {len(rows)}")
    print(f"[parse_result] Way counts: {dict(way_counts)}")
    print(f"[parse_result] tsRNA nodes: {len(tsrna_rows)}")
    print(f"[parse_result] disease nodes: {len(disease_rows)}")
    print(f"[parse_result] supervised Experimental pairs: {len(associations)}")
    print(f"[parse_result] weak Prediction pairs: {len(weak_edges)}")
    print(f"[parse_result] removed duplicate Experimental records: {duplicate_experimental}")
    print(f"[parse_result] removed duplicate Prediction records: {duplicate_prediction}")
    print(f"[parse_result] outputs written to: {OUT_DIR}")


if __name__ == "__main__":
    main()
