from __future__ import annotations

import difflib
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv, normalize_disease_name, save_csv


PROCESSED_DIR = ROOT / "data" / "processed"
OVERRIDE_PATH = PROCESSED_DIR / "disease_doid_overrides.csv"
OVERRIDE_FIELDS = ["disease_id", "disease_name", "doid_id", "doid_name", "note"]
MAP_FIELDS = ["disease_id", "disease_name", "doid_id", "doid_name", "match_method"]
UNMATCHED_FIELDS = [
    "disease_id",
    "disease_name",
    "normalized_name",
    "positive_assoc_count",
    "total_record_count",
]
CANDIDATE_FIELDS = [
    "disease_id",
    "disease_name",
    "normalized_name",
    "candidate_doid_id",
    "candidate_doid_name",
    "match_score",
    "candidate_source",
]


def ensure_override_template(disease_rows: list[dict[str, str]]) -> None:
    if OVERRIDE_PATH.exists():
        return

    rows = [
        {
            "disease_id": row["disease_id"],
            "disease_name": row["disease_name"],
            "doid_id": "",
            "doid_name": "",
            "note": "",
        }
        for row in disease_rows
    ]
    save_csv(rows, OVERRIDE_PATH, OVERRIDE_FIELDS)
    print(f"[build_graph] created manual override template: {OVERRIDE_PATH}")


def build_doid_lookup(doid_rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["doid_id"]: row for row in doid_rows}


def index_by_normalized_name(rows: list[dict[str, str]]) -> dict[str, list[dict[str, str]]]:
    index: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        normalized = row.get("normalized_name") or normalize_disease_name(row.get("doid_name", ""))
        if normalized:
            index[normalized].append(row)
    return index


def index_synonyms(
    synonym_rows: list[dict[str, str]],
    doid_by_id: dict[str, dict[str, str]],
) -> dict[str, list[dict[str, str]]]:
    index: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in synonym_rows:
        doid_id = row["doid_id"]
        if doid_id not in doid_by_id:
            continue
        normalized = row.get("normalized_synonym") or normalize_disease_name(row.get("synonym", ""))
        if not normalized:
            continue
        index[normalized].append(
            {
                "doid_id": doid_id,
                "doid_name": doid_by_id[doid_id]["doid_name"],
                "synonym": row.get("synonym", ""),
                "synonym_scope": row.get("synonym_scope", ""),
            }
        )
    return index


def dedupe_candidates(candidates: list[dict[str, str]]) -> list[dict[str, str]]:
    seen = set()
    deduped = []
    for candidate in candidates:
        key = (candidate["doid_id"], candidate["doid_name"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(candidate)
    return deduped


def split_aliases(value: str) -> list[str]:
    aliases = []
    seen = set()
    for alias in str(value or "").split("//"):
        alias = alias.strip()
        if not alias or alias.upper() == "N/A":
            continue
        normalized = normalize_disease_name(alias)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        aliases.append(alias)
    return aliases


def get_disease_name2_aliases(disease: dict[str, str]) -> list[tuple[str, str]]:
    return [(alias, normalize_disease_name(alias)) for alias in split_aliases(disease.get("disease_name2", ""))]


def add_mapping(
    mappings: list[dict[str, str]],
    disease: dict[str, str],
    doid_id: str,
    doid_name: str,
    method: str,
) -> None:
    mappings.append(
        {
            "disease_id": disease["disease_id"],
            "disease_name": disease["disease_name"],
            "doid_id": doid_id,
            "doid_name": doid_name,
            "match_method": method,
        }
    )


def load_manual_mappings(
    disease_rows: list[dict[str, str]],
    doid_by_id: dict[str, dict[str, str]],
) -> tuple[list[dict[str, str]], set[str]]:
    ensure_override_template(disease_rows)

    disease_by_id = {row["disease_id"]: row for row in disease_rows}
    mappings = []
    mapped_ids: set[str] = set()
    invalid_rows = 0

    for row in load_csv(OVERRIDE_PATH):
        disease_id = str(row.get("disease_id", "")).strip()
        doid_id = str(row.get("doid_id", "")).strip()
        if not disease_id or not doid_id:
            continue
        if disease_id not in disease_by_id or doid_id not in doid_by_id:
            invalid_rows += 1
            continue

        disease = disease_by_id[disease_id]
        doid_name = str(row.get("doid_name", "")).strip() or doid_by_id[doid_id]["doid_name"]
        add_mapping(mappings, disease, doid_id, doid_name, "manual")
        mapped_ids.add(disease_id)

    if invalid_rows:
        print(f"[build_graph] ignored invalid manual override rows: {invalid_rows}")
    return mappings, mapped_ids


def exact_match_aliases(
    aliases: list[tuple[str, str]],
    index: dict[str, list[dict[str, str]]],
) -> tuple[list[dict[str, str]], dict[tuple[str, str], list[str]]]:
    candidates = []
    aliases_by_candidate: dict[tuple[str, str], list[str]] = defaultdict(list)

    for alias, normalized_alias in aliases:
        for candidate in index.get(normalized_alias, []):
            key = (candidate["doid_id"], candidate["doid_name"])
            aliases_by_candidate[key].append(alias)
            candidates.append(candidate)

    return dedupe_candidates(candidates), aliases_by_candidate


def score_candidate(query: str, candidate_name: str) -> float:
    candidate = candidate_name if " " in candidate_name or candidate_name == normalize_disease_name(candidate_name) else normalize_disease_name(candidate_name)
    if not query or not candidate:
        return 0.0

    sequence_score = difflib.SequenceMatcher(None, query, candidate).ratio()
    query_tokens = set(query.split())
    candidate_tokens = set(candidate.split())
    token_score = 0.0
    if query_tokens and candidate_tokens:
        token_score = len(query_tokens & candidate_tokens) / len(query_tokens | candidate_tokens)
    return max(sequence_score, token_score)


def build_candidate_corpus(
    doid_rows: list[dict[str, str]],
    synonym_rows: list[dict[str, str]],
    doid_by_id: dict[str, dict[str, str]],
) -> list[dict[str, object]]:
    corpus: list[dict[str, object]] = []

    for row in doid_rows:
        normalized = row.get("normalized_name") or normalize_disease_name(row["doid_name"])
        corpus.append(
            {
                "doid_id": row["doid_id"],
                "doid_name": row["doid_name"],
                "normalized": normalized,
                "tokens": set(normalized.split()),
                "source": "doid_name_similarity",
            }
        )

    for row in synonym_rows:
        doid_id = row["doid_id"]
        if doid_id not in doid_by_id:
            continue
        normalized = row.get("normalized_synonym") or normalize_disease_name(row.get("synonym", ""))
        corpus.append(
            {
                "doid_id": doid_id,
                "doid_name": doid_by_id[doid_id]["doid_name"],
                "normalized": normalized,
                "tokens": set(normalized.split()),
                "source": f"synonym_similarity:{row.get('synonym_scope', 'N/A')}",
            }
        )

    return corpus


def should_score_candidate(query: str, query_tokens: set[str], candidate: dict[str, object]) -> bool:
    candidate_normalized = str(candidate["normalized"])
    candidate_tokens = candidate["tokens"]
    if not candidate_normalized:
        return False
    if query_tokens & candidate_tokens:
        return True
    return query[:1] == candidate_normalized[:1] and abs(len(query) - len(candidate_normalized)) <= 8


def generate_review_candidates(
    disease: dict[str, str],
    candidate_corpus: list[dict[str, object]],
    limit: int = 8,
) -> list[dict[str, str]]:
    primary_normalized = normalize_disease_name(disease["disease_name"])
    queries = [(disease["disease_name"], primary_normalized, "primary_name")]
    queries.extend((alias, normalized, "disease_name2") for alias, normalized in get_disease_name2_aliases(disease))
    scored = []

    for query_name, normalized, query_source in queries:
        query_tokens = set(normalized.split())
        for candidate in candidate_corpus:
            if not should_score_candidate(normalized, query_tokens, candidate):
                continue
            score = score_candidate(normalized, str(candidate["normalized"]))
            threshold = 0.58 if str(candidate["source"]) == "doid_name_similarity" else 0.62
            if score >= threshold:
                scored.append(
                    {
                        "candidate_doid_id": str(candidate["doid_id"]),
                        "candidate_doid_name": str(candidate["doid_name"]),
                        "match_score": score,
                        "candidate_source": f"{query_source}:{query_name}:{candidate['source']}",
                    }
                )

    scored.sort(key=lambda row: float(row["match_score"]), reverse=True)

    rows = []
    seen = set()
    for candidate in scored:
        key = (candidate["candidate_doid_id"], candidate["candidate_doid_name"])
        if key in seen:
            continue
        seen.add(key)
        rows.append(
            {
                "disease_id": disease["disease_id"],
                "disease_name": disease["disease_name"],
                "normalized_name": primary_normalized,
                "candidate_doid_id": candidate["candidate_doid_id"],
                "candidate_doid_name": candidate["candidate_doid_name"],
                "match_score": f"{candidate['match_score']:.4f}",
                "candidate_source": candidate["candidate_source"],
            }
        )
        if len(rows) >= limit:
            break

    return rows


def count_by_disease(rows: list[dict[str, str]]) -> dict[str, int]:
    counts: dict[str, int] = defaultdict(int)
    for row in rows:
        counts[str(row["disease_id"])] += 1
    return counts


def coverage(rows: list[dict[str, str]], mapped_disease_ids: set[str]) -> tuple[int, int, float]:
    total = len(rows)
    covered = sum(1 for row in rows if str(row["disease_id"]) in mapped_disease_ids)
    rate = covered / total if total else 0.0
    return total, covered, rate


def main() -> None:
    disease_rows = load_csv(PROCESSED_DIR / "disease.csv")
    doid_rows = load_csv(PROCESSED_DIR / "doid_terms.csv")
    synonym_path = PROCESSED_DIR / "doid_synonyms.csv"
    synonym_rows = load_csv(synonym_path) if synonym_path.exists() else []
    associations = load_csv(PROCESSED_DIR / "associations.csv")
    weak_edges = load_csv(PROCESSED_DIR / "weak_edges.csv")

    doid_by_id = build_doid_lookup(doid_rows)
    doid_by_name = index_by_normalized_name(doid_rows)
    doid_by_synonym = index_synonyms(synonym_rows, doid_by_id)
    candidate_corpus = build_candidate_corpus(doid_rows, synonym_rows, doid_by_id)
    positive_counts = count_by_disease(associations)
    weak_counts = count_by_disease(weak_edges)

    mappings, mapped_disease_ids = load_manual_mappings(disease_rows, doid_by_id)
    candidate_rows = []

    name_exact_ambiguous = 0
    synonym_exact_ambiguous = 0
    disease2_name_exact_ambiguous = 0
    disease2_synonym_exact_ambiguous = 0

    for disease in disease_rows:
        disease_id = str(disease["disease_id"])
        if disease_id in mapped_disease_ids:
            continue

        normalized = normalize_disease_name(disease["disease_name"])

        name_candidates = dedupe_candidates(doid_by_name.get(normalized, []))
        if len(name_candidates) == 1:
            candidate = name_candidates[0]
            add_mapping(mappings, disease, candidate["doid_id"], candidate["doid_name"], "normalized_name_exact")
            mapped_disease_ids.add(disease_id)
            continue
        if len(name_candidates) > 1:
            name_exact_ambiguous += 1
            for candidate in name_candidates:
                candidate_rows.append(
                    {
                        "disease_id": disease_id,
                        "disease_name": disease["disease_name"],
                        "normalized_name": normalized,
                        "candidate_doid_id": candidate["doid_id"],
                        "candidate_doid_name": candidate["doid_name"],
                        "match_score": "1.0000",
                        "candidate_source": "ambiguous_normalized_name_exact",
                    }
                )
            continue

        synonym_candidates = dedupe_candidates(doid_by_synonym.get(normalized, []))
        if len(synonym_candidates) == 1:
            candidate = synonym_candidates[0]
            add_mapping(mappings, disease, candidate["doid_id"], candidate["doid_name"], "synonym_exact")
            mapped_disease_ids.add(disease_id)
            continue
        if len(synonym_candidates) > 1:
            synonym_exact_ambiguous += 1
            for candidate in synonym_candidates:
                candidate_rows.append(
                    {
                        "disease_id": disease_id,
                        "disease_name": disease["disease_name"],
                        "normalized_name": normalized,
                        "candidate_doid_id": candidate["doid_id"],
                        "candidate_doid_name": candidate["doid_name"],
                        "match_score": "1.0000",
                        "candidate_source": "ambiguous_synonym_exact",
                    }
                )

        disease2_aliases = get_disease_name2_aliases(disease)
        disease2_name_candidates, disease2_name_aliases = exact_match_aliases(disease2_aliases, doid_by_name)
        if len(disease2_name_candidates) == 1:
            candidate = disease2_name_candidates[0]
            add_mapping(
                mappings,
                disease,
                candidate["doid_id"],
                candidate["doid_name"],
                "disease_name2_normalized_name_exact",
            )
            mapped_disease_ids.add(disease_id)
            continue
        if len(disease2_name_candidates) > 1:
            disease2_name_exact_ambiguous += 1
            for candidate in disease2_name_candidates:
                alias_key = (candidate["doid_id"], candidate["doid_name"])
                aliases = "//".join(disease2_name_aliases.get(alias_key, []))
                candidate_rows.append(
                    {
                        "disease_id": disease_id,
                        "disease_name": disease["disease_name"],
                        "normalized_name": normalized,
                        "candidate_doid_id": candidate["doid_id"],
                        "candidate_doid_name": candidate["doid_name"],
                        "match_score": "1.0000",
                        "candidate_source": f"ambiguous_disease_name2_normalized_name_exact:{aliases}",
                    }
                )
            continue

        disease2_synonym_candidates, disease2_synonym_aliases = exact_match_aliases(disease2_aliases, doid_by_synonym)
        if len(disease2_synonym_candidates) == 1:
            candidate = disease2_synonym_candidates[0]
            add_mapping(mappings, disease, candidate["doid_id"], candidate["doid_name"], "disease_name2_synonym_exact")
            mapped_disease_ids.add(disease_id)
            continue
        if len(disease2_synonym_candidates) > 1:
            disease2_synonym_exact_ambiguous += 1
            for candidate in disease2_synonym_candidates:
                alias_key = (candidate["doid_id"], candidate["doid_name"])
                aliases = "//".join(disease2_synonym_aliases.get(alias_key, []))
                candidate_rows.append(
                    {
                        "disease_id": disease_id,
                        "disease_name": disease["disease_name"],
                        "normalized_name": normalized,
                        "candidate_doid_id": candidate["doid_id"],
                        "candidate_doid_name": candidate["doid_name"],
                        "match_score": "1.0000",
                        "candidate_source": f"ambiguous_disease_name2_synonym_exact:{aliases}",
                    }
                )

    unmatched_rows = []
    for disease in disease_rows:
        disease_id = str(disease["disease_id"])
        if disease_id in mapped_disease_ids:
            continue
        unmatched_rows.append(
            {
                "disease_id": disease_id,
                "disease_name": disease["disease_name"],
                "normalized_name": normalize_disease_name(disease["disease_name"]),
                "positive_assoc_count": positive_counts.get(disease_id, 0),
                "total_record_count": positive_counts.get(disease_id, 0) + weak_counts.get(disease_id, 0),
            }
        )
        candidate_rows.extend(generate_review_candidates(disease, candidate_corpus))

    mappings.sort(key=lambda row: (int(row["disease_id"]), row["doid_id"]))
    unmatched_rows.sort(key=lambda row: int(row["disease_id"]))
    candidate_rows.sort(
        key=lambda row: (
            int(row["disease_id"]),
            -float(row["match_score"]),
            row["candidate_doid_id"],
            row["candidate_source"],
        )
    )

    save_csv(mappings, PROCESSED_DIR / "disease_doid_map.csv", MAP_FIELDS)
    save_csv(unmatched_rows, PROCESSED_DIR / "unmatched_diseases.csv", UNMATCHED_FIELDS)
    save_csv(candidate_rows, PROCESSED_DIR / "ambiguous_disease_candidates.csv", CANDIDATE_FIELDS)

    total_diseases = len(disease_rows)
    matched_diseases = len(mapped_disease_ids)
    unmatched_diseases = total_diseases - matched_diseases
    disease_match_rate = matched_diseases / total_diseases if total_diseases else 0.0
    assoc_total, assoc_covered, assoc_rate = coverage(associations, mapped_disease_ids)
    weak_total, weak_covered, weak_rate = coverage(weak_edges, mapped_disease_ids)

    method_counts: dict[str, int] = defaultdict(int)
    for row in mappings:
        method_counts[row["match_method"]] += 1

    print(f"[build_graph] total diseases: {total_diseases}")
    print(f"[build_graph] matched diseases: {matched_diseases}")
    print(f"[build_graph] unmatched diseases: {unmatched_diseases}")
    print(f"[build_graph] disease match rate: {disease_match_rate:.2%}")
    print(f"[build_graph] match methods: {dict(method_counts)}")
    print(f"[build_graph] ambiguous normalized exact diseases: {name_exact_ambiguous}")
    print(f"[build_graph] ambiguous synonym exact diseases: {synonym_exact_ambiguous}")
    print(f"[build_graph] ambiguous disease_name2 normalized exact diseases: {disease2_name_exact_ambiguous}")
    print(f"[build_graph] ambiguous disease_name2 synonym exact diseases: {disease2_synonym_exact_ambiguous}")
    print(f"[build_graph] supervised positive associations total: {assoc_total}")
    print(f"[build_graph] supervised positive associations with mapped disease: {assoc_covered}")
    print(f"[build_graph] supervised association ontology coverage: {assoc_rate:.2%}")
    print(f"[build_graph] weak edges total: {weak_total}")
    print(f"[build_graph] weak edges with mapped disease: {weak_covered}")
    print(f"[build_graph] weak edge ontology coverage: {weak_rate:.2%}")
    print(f"[build_graph] review candidates written: {len(candidate_rows)}")
    print(f"[build_graph] outputs written to: {PROCESSED_DIR}")


if __name__ == "__main__":
    main()
