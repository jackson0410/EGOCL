from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, load_csv, save_csv


PROCESSED_DIR = ROOT / "data" / "processed"
TENSOR_DIR = PROCESSED_DIR / "tensors"
EDGE_FEATURE_NAMES = [
    "confidence_score",
    "has_strong_evidence",
    "has_weak_evidence",
    "is_experimental",
    "is_prediction",
    "log1p_evidence_count",
]
CONFIDENCE_SCORE = {
    "very high": 1.0,
    "high": 1.0,
    "median": 0.67,
    "medium": 0.67,
    "moderate": 0.67,
    "low": 0.33,
    "very low": 0.15,
    "prediction": 0.15,
    "n/a": 0.0,
    "na": 0.0,
    "": 0.0,
}


def is_present(value: str) -> float:
    value = str(value or "").strip()
    return 0.0 if not value or value.upper() == "N/A" else 1.0


def confidence_score(value: str) -> float:
    return CONFIDENCE_SCORE.get(str(value or "").strip().lower(), 0.0)


def edge_features(row: dict[str, str]) -> list[float]:
    way = str(row.get("way") or row.get("Way") or "").strip().lower()
    evidence_count = int(float(row.get("evidence_count", 1) or 1))
    return [
        confidence_score(row.get("confidence", "")),
        is_present(row.get("strong_evidence", "")),
        is_present(row.get("weak_evidence", "")),
        1.0 if way == "experimental" else 0.0,
        1.0 if way == "prediction" else 0.0,
        math.log1p(max(evidence_count, 0)),
    ]


def save_edge_tensors(rows: list[dict[str, str]], prefix: str) -> None:
    tsrna_ids = torch.tensor([int(row["tsrna_id"]) for row in rows], dtype=torch.long)
    disease_ids = torch.tensor([int(row["disease_id"]) for row in rows], dtype=torch.long)
    features = torch.tensor([edge_features(row) for row in rows], dtype=torch.float32)

    torch.save(tsrna_ids, TENSOR_DIR / f"{prefix}_tsrna_ids.pt")
    torch.save(disease_ids, TENSOR_DIR / f"{prefix}_disease_ids.pt")
    torch.save(features, TENSOR_DIR / f"{prefix}_edge_features.pt")


def parse_path_ids(path_value: str) -> list[str]:
    return [item.strip() for item in str(path_value or "").split(">") if item.strip()]


def main() -> None:
    ensure_dir(TENSOR_DIR)

    tsrna_rows = load_csv(PROCESSED_DIR / "tsrna.csv")
    disease_rows = load_csv(PROCESSED_DIR / "disease.csv")
    association_rows = load_csv(PROCESSED_DIR / "associations.csv")
    weak_rows = load_csv(PROCESSED_DIR / "weak_edges.csv")
    doid_rows = load_csv(PROCESSED_DIR / "doid_terms.csv")
    doid_edge_rows = load_csv(PROCESSED_DIR / "doid_edges.csv")
    disease_doid_rows = load_csv(PROCESSED_DIR / "disease_doid_map.csv")
    disease_path_rows = load_csv(PROCESSED_DIR / "disease_doid_paths.csv")

    num_tsrna = len(tsrna_rows)
    num_disease = len(disease_rows)
    num_doid = len(doid_rows)
    node_counts = {
        "num_tsrna": num_tsrna,
        "num_disease": num_disease,
        "num_doid": num_doid,
    }

    torch.save(node_counts, TENSOR_DIR / "node_counts.pt")
    with (TENSOR_DIR / "node_counts.json").open("w", encoding="utf-8") as f:
        json.dump(node_counts, f, indent=2)
    with (TENSOR_DIR / "edge_feature_names.json").open("w", encoding="utf-8") as f:
        json.dump(EDGE_FEATURE_NAMES, f, indent=2)

    save_edge_tensors(association_rows, "pos")
    save_edge_tensors(weak_rows, "weak")

    doid_id_to_idx = {row["doid_id"]: idx for idx, row in enumerate(doid_rows)}
    doid_map_rows = [
        {
            "doid_idx": idx,
            "doid_id": row["doid_id"],
            "doid_name": row["doid_name"],
        }
        for idx, row in enumerate(doid_rows)
    ]
    save_csv(doid_map_rows, TENSOR_DIR / "doid_id_map.csv", ["doid_idx", "doid_id", "doid_name"])

    up_edges = []
    skipped_doid_edges = 0
    for row in doid_edge_rows:
        child_id = row["child_doid_id"]
        parent_id = row["parent_doid_id"]
        if child_id not in doid_id_to_idx or parent_id not in doid_id_to_idx:
            skipped_doid_edges += 1
            continue
        up_edges.append([doid_id_to_idx[child_id], doid_id_to_idx[parent_id]])

    if up_edges:
        doid_up_edges = torch.tensor(up_edges, dtype=torch.long).t().contiguous()
        doid_down_edges = doid_up_edges.flip(0).contiguous()
    else:
        doid_up_edges = torch.empty((2, 0), dtype=torch.long)
        doid_down_edges = torch.empty((2, 0), dtype=torch.long)

    torch.save(doid_up_edges, TENSOR_DIR / "doid_up_edges.pt")
    torch.save(doid_down_edges, TENSOR_DIR / "doid_down_edges.pt")

    disease_to_doid_idx = torch.full((num_disease,), -1, dtype=torch.long)
    duplicate_mappings = 0
    for row in disease_doid_rows:
        disease_id = int(row["disease_id"])
        doid_id = row["doid_id"]
        if disease_id < 0 or disease_id >= num_disease or doid_id not in doid_id_to_idx:
            continue
        if disease_to_doid_idx[disease_id].item() != -1:
            duplicate_mappings += 1
            continue
        disease_to_doid_idx[disease_id] = doid_id_to_idx[doid_id]
    torch.save(disease_to_doid_idx, TENSOR_DIR / "disease_to_doid_idx.pt")

    paths_by_disease: dict[int, list[list[int]]] = {}
    skipped_path_nodes = 0
    for row in disease_path_rows:
        disease_id = int(row["disease_id"])
        path = []
        for doid_id in parse_path_ids(row["path_doid_ids"]):
            if doid_id not in doid_id_to_idx:
                skipped_path_nodes += 1
                continue
            path.append(doid_id_to_idx[doid_id])
        if path:
            paths_by_disease.setdefault(disease_id, []).append(path)

    max_paths = max((len(paths) for paths in paths_by_disease.values()), default=1)
    max_path_len = max((len(path) for paths in paths_by_disease.values() for path in paths), default=1)
    disease_path_indices = torch.full((num_disease, max_paths, max_path_len), -1, dtype=torch.long)
    disease_path_mask = torch.zeros((num_disease, max_paths, max_path_len), dtype=torch.bool)

    for disease_id, paths in paths_by_disease.items():
        if disease_id < 0 or disease_id >= num_disease:
            continue
        paths = sorted(paths, key=lambda path: (len(path), path))
        for path_idx, path in enumerate(paths[:max_paths]):
            length = min(len(path), max_path_len)
            disease_path_indices[disease_id, path_idx, :length] = torch.tensor(path[:length], dtype=torch.long)
            disease_path_mask[disease_id, path_idx, :length] = True

    torch.save(disease_path_indices, TENSOR_DIR / "disease_path_indices.pt")
    torch.save(disease_path_mask, TENSOR_DIR / "disease_path_mask.pt")

    print(f"[build_tensors] output directory: {TENSOR_DIR}")
    print(f"[build_tensors] num_tsrna: {num_tsrna}")
    print(f"[build_tensors] num_disease: {num_disease}")
    print(f"[build_tensors] num_doid: {num_doid}")
    print(f"[build_tensors] positive edges: {len(association_rows)}")
    print(f"[build_tensors] weak edges: {len(weak_rows)}")
    print(f"[build_tensors] edge feature dim: {len(EDGE_FEATURE_NAMES)}")
    print(f"[build_tensors] DOID up/down edges: {doid_up_edges.shape[1]}")
    print(f"[build_tensors] skipped DOID edges: {skipped_doid_edges}")
    print(f"[build_tensors] mapped disease count: {(disease_to_doid_idx >= 0).sum().item()}")
    print(f"[build_tensors] duplicate disease mappings skipped: {duplicate_mappings}")
    print(f"[build_tensors] diseases with ontology paths: {len(paths_by_disease)}")
    print(f"[build_tensors] disease_path_indices shape: {tuple(disease_path_indices.shape)}")
    print(f"[build_tensors] skipped path nodes: {skipped_path_nodes}")


if __name__ == "__main__":
    main()
