from __future__ import annotations

import sys
from collections import defaultdict, deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv, save_csv


PROCESSED_DIR = ROOT / "data" / "processed"
ROOT_DOID = "DOID:4"
PATH_FIELDS = [
    "disease_id",
    "disease_name",
    "doid_id",
    "path_index",
    "path_doid_ids",
    "path_doid_names",
    "path_length",
]


def build_parent_index(edge_rows: list[dict[str, str]]) -> dict[str, list[str]]:
    parents: dict[str, list[str]] = defaultdict(list)
    for row in edge_rows:
        parents[row["child_doid_id"]].append(row["parent_doid_id"])
    for child_id in parents:
        parents[child_id] = sorted(set(parents[child_id]))
    return parents


def find_paths_to_root(start_id: str, parents: dict[str, list[str]]) -> list[list[str]]:
    paths: list[list[str]] = []
    queue = deque([[start_id]])

    while queue:
        path = queue.popleft()
        node_id = path[-1]
        parent_ids = [parent_id for parent_id in parents.get(node_id, []) if parent_id not in path]

        if node_id == ROOT_DOID or not parent_ids:
            paths.append(path)
            continue

        for parent_id in parent_ids:
            queue.append([*path, parent_id])

    return paths


def select_shortest_and_longest(paths: list[list[str]]) -> list[list[str]]:
    if len(paths) <= 2:
        return paths

    shortest = min(paths, key=lambda path: (len(path), path))
    longest = max(paths, key=lambda path: (len(path), path))
    if shortest == longest:
        return [shortest]
    return [shortest, longest]


def main() -> None:
    map_rows = load_csv(PROCESSED_DIR / "disease_doid_map.csv")
    edge_rows = load_csv(PROCESSED_DIR / "doid_edges.csv")
    term_rows = load_csv(PROCESSED_DIR / "doid_terms.csv")

    parents = build_parent_index(edge_rows)
    doid_name_by_id = {row["doid_id"]: row["doid_name"] for row in term_rows}

    output_rows = []
    all_lengths = []
    diseases_with_multiple_paths = 0

    for mapping in map_rows:
        doid_id = mapping["doid_id"]
        paths = find_paths_to_root(doid_id, parents)
        if len(paths) > 1:
            diseases_with_multiple_paths += 1
        selected_paths = select_shortest_and_longest(paths)

        for path_index, path in enumerate(selected_paths):
            all_lengths.append(len(path))
            output_rows.append(
                {
                    "disease_id": mapping["disease_id"],
                    "disease_name": mapping["disease_name"],
                    "doid_id": doid_id,
                    "path_index": path_index,
                    "path_doid_ids": " > ".join(path),
                    "path_doid_names": " > ".join(doid_name_by_id.get(node_id, node_id) for node_id in path),
                    "path_length": len(path),
                }
            )

    save_csv(output_rows, PROCESSED_DIR / "disease_doid_paths.csv", PATH_FIELDS)

    if all_lengths:
        avg_length = sum(all_lengths) / len(all_lengths)
        min_length = min(all_lengths)
        max_length = max(all_lengths)
    else:
        avg_length = 0.0
        min_length = 0
        max_length = 0

    print(f"[build_doid_paths] mapped disease rows: {len(map_rows)}")
    print(f"[build_doid_paths] output paths: {len(output_rows)}")
    print(f"[build_doid_paths] diseases with multiple ontology paths: {diseases_with_multiple_paths}")
    print(f"[build_doid_paths] average path length: {avg_length:.2f}")
    print(f"[build_doid_paths] min path length: {min_length}")
    print(f"[build_doid_paths] max path length: {max_length}")
    print(f"[build_doid_paths] output written to: {PROCESSED_DIR / 'disease_doid_paths.csv'}")


if __name__ == "__main__":
    main()
