from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.utils import ensure_dir, load_csv, save_csv


BASELINES = [
    ("AGCLNDA-adapted", ROOT / "src" / "baselines" / "agclnda_adapted.py"),
    ("MSMCDA-adapted", ROOT / "src" / "baselines" / "msmcda_adapted.py"),
    ("HybridGNN-adapted", ROOT / "src" / "baselines" / "hybridgnn_adapted.py"),
    ("HybridGNN-adapted-degree-matched", ROOT / "src" / "baselines" / "hybridgnn_degree_matched.py"),
    ("DualVGAE-adapted", ROOT / "src" / "baselines" / "dualvgae_adapted.py"),
    ("iCircDA-MF-adapted", ROOT / "src" / "baselines" / "icircda_mf_adapted.py"),
    ("DMFCDA-adapted", ROOT / "src" / "baselines" / "dmfcda_adapted.py"),
    ("DMFCDA-adapted-degree-matched", ROOT / "src" / "baselines" / "dmfcda_adapted.py"),
]

SUMMARY_FIELDS = [
    "model",
    "auc_mean",
    "auc_std",
    "aupr_mean",
    "aupr_std",
    "selected_f1_mean",
    "selected_f1_std",
    "precision_mean",
    "precision_std",
    "recall_mean",
    "recall_std",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run adapted domain baseline comparison.")
    parser.add_argument("--common_data_dir", default=None)
    parser.add_argument("--output_dir", default="results/domain_baselines")
    parser.add_argument("--final_reference_dir", default="results/final_tuning/focal_alpha_0.85_gamma_1.5")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--latent_dim", type=int, default=32)
    parser.add_argument("--pca_dim", type=int, default=32)
    parser.add_argument("--gat_heads", type=int, default=4)
    parser.add_argument("--lambda_reg", type=float, default=0.0121)
    parser.add_argument("--projection_layers", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--neighbor_k", type=int, default=2)
    parser.add_argument("--mf_rank", type=int, default=70)
    parser.add_argument("--alpha", type=float, default=2e-3)
    parser.add_argument("--beta", type=float, default=1e-3)
    parser.add_argument("--max_iter", type=int, default=300)
    parser.add_argument("--tol", type=float, default=1e-5)
    parser.add_argument("--quick_test", action="store_true")
    parser.add_argument("--skip_existing", action="store_true")
    parser.add_argument("--summarize_only", action="store_true")
    parser.add_argument("--models", nargs="*", default=None)
    return parser.parse_args()


def metric_lookup(mean_std_path: Path) -> dict[str, tuple[float, float]]:
    rows = load_csv(mean_std_path)
    return {row["metric"]: (float(row["mean"]), float(row["std"])) for row in rows}


def row_from_mean_std(model_name: str, mean_std_path: Path) -> dict[str, object]:
    metrics = metric_lookup(mean_std_path)
    return {
        "model": model_name,
        "auc_mean": metrics["test_auc"][0],
        "auc_std": metrics["test_auc"][1],
        "aupr_mean": metrics["test_aupr"][0],
        "aupr_std": metrics["test_aupr"][1],
        "selected_f1_mean": metrics["test_selected_threshold_f1"][0],
        "selected_f1_std": metrics["test_selected_threshold_f1"][1],
        "precision_mean": metrics.get("test_selected_threshold_precision", (0.0, 0.0))[0],
        "precision_std": metrics.get("test_selected_threshold_precision", (0.0, 0.0))[1],
        "recall_mean": metrics.get("test_selected_threshold_recall", (0.0, 0.0))[0],
        "recall_std": metrics.get("test_selected_threshold_recall", (0.0, 0.0))[1],
    }


def copy_final_reference(args: argparse.Namespace, output_dir: Path) -> Path | None:
    source = ROOT / args.final_reference_dir
    if not source.exists():
        print(f"[run_domain_baseline_comparison] final reference missing: {source}", flush=True)
        return None
    target = output_dir / "EGO-CLGNN"
    if target.exists() and (target / "cv_mean_std.csv").exists() and args.skip_existing:
        return target
    ensure_dir(target)
    for fold_id in range(args.num_folds):
        src_fold = source / f"fold_{fold_id}"
        dst_fold = target / f"fold_{fold_id}"
        if dst_fold.exists():
            shutil.rmtree(dst_fold)
        if src_fold.exists():
            shutil.copytree(src_fold, dst_fold)
    summarize_cv(target)
    return target


def selected_baselines(args: argparse.Namespace) -> list[tuple[str, Path]]:
    if not args.models:
        return BASELINES
    requested = set(args.models)
    available = {name: script for name, script in BASELINES}
    missing = sorted(requested - set(available))
    if missing:
        raise ValueError(f"Unknown model(s): {missing}. Available: {sorted(available)}")
    return [(name, script) for name, script in BASELINES if name in requested]


def run_baseline(args: argparse.Namespace, output_dir: Path, model_name: str, script: Path) -> None:
    model_dir = output_dir / model_name
    if args.skip_existing and (model_dir / "cv_mean_std.csv").exists():
        print(f"[run_domain_baseline_comparison] skipping existing {model_name}", flush=True)
        return
    command = [
        sys.executable,
        str(script),
        "--common_data_dir",
        str(args.common_data_dir),
        "--output_dir",
        str(output_dir),
        "--num_folds",
        str(args.num_folds),
        "--epochs",
        str(args.epochs),
        "--hidden_dim",
        str(args.hidden_dim),
        "--latent_dim",
        str(args.latent_dim),
        "--projection_layers",
        str(args.projection_layers),
        "--batch_size",
        str(args.batch_size),
        "--lr",
        str(args.lr),
        "--dropout",
        str(args.dropout),
        "--weight_decay",
        str(args.weight_decay),
        "--patience",
        str(args.patience),
        "--seed",
        str(args.seed),
        "--device",
        args.device,
        "--threshold_search",
        args.threshold_search,
    ]
    if args.quick_test:
        command.append("--quick_test")
    if model_name != "DMFCDA-adapted" and model_name != "DMFCDA-adapted-degree-matched":
        command.extend(
            [
                "--pca_dim",
                str(args.pca_dim),
                "--gat_heads",
                str(args.gat_heads),
                "--lambda_reg",
                str(args.lambda_reg),
            ]
        )
    if model_name == "DMFCDA-adapted-degree-matched":
        command.extend(["--model_name", model_name, "--negative_sampling", "degree_matched"])
    if model_name == "iCircDA-MF-adapted":
        command.extend(
            [
                "--neighbor_k",
                str(args.neighbor_k),
                "--mf_rank",
                str(args.mf_rank),
                "--alpha",
                str(args.alpha),
                "--beta",
                str(args.beta),
                "--max_iter",
                str(args.max_iter),
                "--tol",
                str(args.tol),
            ]
        )
    print(f"[run_domain_baseline_comparison] starting {model_name}", flush=True)
    subprocess.run(command, cwd=ROOT, check=True)
    print(f"[run_domain_baseline_comparison] completed {model_name}", flush=True)


def write_summary(output_dir: Path) -> None:
    rows = []
    for model_name in ["EGO-CLGNN"] + [name for name, _ in BASELINES]:
        mean_std_path = output_dir / model_name / "cv_mean_std.csv"
        if mean_std_path.exists():
            rows.append(row_from_mean_std(model_name, mean_std_path))
    if not rows:
        raise FileNotFoundError(f"No cv_mean_std.csv files found under {output_dir}")
    save_csv(rows, output_dir / "domain_baseline_summary.csv", SUMMARY_FIELDS)

    full = next((row for row in rows if row["model"] == "EGO-CLGNN"), None)
    if full is None:
        print("[run_domain_baseline_comparison] delta skipped; EGO-CLGNN row missing", flush=True)
        return
    delta_rows = []
    for row in rows:
        delta_rows.append(
            {
                "model": row["model"],
                "delta_auc": float(full["auc_mean"]) - float(row["auc_mean"]),
                "delta_aupr": float(full["aupr_mean"]) - float(row["aupr_mean"]),
                "delta_selected_f1": float(full["selected_f1_mean"]) - float(row["selected_f1_mean"]),
                "delta_precision": float(full["precision_mean"]) - float(row["precision_mean"]),
                "delta_recall": float(full["recall_mean"]) - float(row["recall_mean"]),
            }
        )
    save_csv(delta_rows, output_dir / "domain_baseline_delta.csv")


def main() -> None:
    args = parse_args()
    if args.quick_test:
        args.num_folds = min(args.num_folds, 2)
    output_dir = ensure_dir(args.output_dir)
    if args.common_data_dir is None:
        args.common_data_dir = str(output_dir / "common_data")

    if not args.summarize_only:
        copy_final_reference(args, output_dir)
        for model_name, script in selected_baselines(args):
            run_baseline(args, output_dir, model_name, script)
    write_summary(output_dir)
    print(f"[run_domain_baseline_comparison] outputs written to {output_dir}", flush=True)


if __name__ == "__main__":
    main()
