from __future__ import annotations

import csv
import os
import random
import re
from pathlib import Path
from typing import Iterable, Mapping, Sequence


DISEASE_PUNCT_RE = re.compile(r"[,(){}\[\]:;/\\\-]+")
WHITESPACE_RE = re.compile(r"\s+")


def set_seed(seed: int = 42) -> None:
    """Set common random seeds used during preprocessing/model experiments."""
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

    try:
        import numpy as np

        np.random.seed(seed)
    except ImportError:
        pass

    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def normalize_disease_name(name: str) -> str:
    """Conservative disease-name normalization for exact matching.

    This intentionally keeps biomedical terms such as cancer, carcinoma,
    neoplasm, and tumor instead of stemming or dropping them.
    """
    normalized = str(name or "").strip().lower()
    normalized = DISEASE_PUNCT_RE.sub(" ", normalized)
    normalized = WHITESPACE_RE.sub(" ", normalized)
    return normalized.strip()


def load_csv(path: str | Path) -> list[dict[str, str]]:
    path = Path(path)
    encodings = ("utf-8-sig", "utf-8", "gbk", "latin-1")
    last_error: UnicodeDecodeError | None = None

    for encoding in encodings:
        try:
            with path.open("r", encoding=encoding, newline="") as f:
                return [dict(row) for row in csv.DictReader(f)]
        except UnicodeDecodeError as exc:
            last_error = exc

    raise UnicodeDecodeError(
        last_error.encoding if last_error else "unknown",
        last_error.object if last_error else b"",
        last_error.start if last_error else 0,
        last_error.end if last_error else 0,
        f"Unable to decode {path}",
    )


def save_csv(
    rows: Iterable[Mapping[str, object]],
    path: str | Path,
    fieldnames: Sequence[str] | None = None,
) -> None:
    path = Path(path)
    ensure_dir(path.parent)

    materialized_rows = [dict(row) for row in rows]
    if fieldnames is None:
        fieldnames = list(materialized_rows[0].keys()) if materialized_rows else []

    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized_rows)
