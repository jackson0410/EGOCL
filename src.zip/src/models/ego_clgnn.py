from __future__ import annotations

import torch
from torch import nn

from src.losses import attribute_contrastive_loss, info_nce_loss
from src.models.decoder import MLPDecoder
from src.models.hybrid_decoder import HybridDecoder
from src.models.layers import DirectionAwareOntologyLayer, EvidenceGatedGraphLayer
from src.models.path_attention import OntologyPathAttention
from src.models.tsrna_attribute_encoder import TsrnaAttributeConcatFusion, TsrnaAttributeEncoder, TsrnaAttributeGatedFusion


class EgoCLGNN(nn.Module):
    def __init__(
        self,
        num_tsrna: int,
        num_disease: int,
        num_doid: int,
        hidden_dim: int = 128,
        num_layers: int = 2,
        edge_feat_dim: int = 6,
        svd_dim: int = 64,
        dropout: float = 0.2,
        use_evidence_gate: bool = True,
        use_ontology: bool = True,
        use_path_attention: bool = True,
        use_direction: bool = True,
        use_svd_features: bool = True,
        decoder_type: str = "hybrid",
        use_tsrna_attr: bool = False,
        use_tsrna_seq: bool = True,
        use_attr_contrastive: bool = False,
        tsrna_attr_fusion: str = "gated",
        attr_kmer_dim: int = 64,
        attr_num_types: int = 1,
        attr_num_sources: int = 1,
        attr_num_anticodons: int = 1,
        attr_num_aminos: int = 1,
        attr_num_species: int = 1,
    ) -> None:
        super().__init__()
        self.use_ontology = use_ontology
        self.use_path_attention = use_path_attention
        self.use_svd_features = use_svd_features
        self.use_tsrna_attr = use_tsrna_attr
        self.use_attr_contrastive = use_attr_contrastive
        self.tsrna_attr_fusion = tsrna_attr_fusion

        self.tsrna_embedding = nn.Embedding(num_tsrna, hidden_dim)
        self.disease_embedding = nn.Embedding(num_disease, hidden_dim)
        self.doid_embedding = nn.Embedding(num_doid, hidden_dim)
        self.tsrna_svd_proj = nn.Linear(svd_dim, hidden_dim)
        self.disease_svd_proj = nn.Linear(svd_dim, hidden_dim)

        self.view1_layers = nn.ModuleList(
            [EvidenceGatedGraphLayer(hidden_dim, edge_feat_dim, dropout, use_evidence_gate) for _ in range(num_layers)]
        )
        self.view2_layers = nn.ModuleList(
            [EvidenceGatedGraphLayer(hidden_dim, edge_feat_dim, dropout, use_evidence_gate) for _ in range(num_layers)]
        )
        self.ontology_layers = nn.ModuleList(
            [DirectionAwareOntologyLayer(hidden_dim, dropout, use_direction) for _ in range(num_layers)]
        )
        self.ontology_to_disease = nn.Linear(hidden_dim, hidden_dim)
        self.disease_fusion_norm = nn.LayerNorm(hidden_dim)
        self.path_attention = OntologyPathAttention(hidden_dim, dropout)
        self.decoder = HybridDecoder(hidden_dim, dropout) if decoder_type == "hybrid" else MLPDecoder(hidden_dim, dropout)
        if use_tsrna_attr:
            self.attribute_encoder = TsrnaAttributeEncoder(
                kmer_dim=attr_kmer_dim,
                num_types=attr_num_types,
                num_sources=attr_num_sources,
                num_anticodons=attr_num_anticodons,
                num_aminos=attr_num_aminos,
                num_species=attr_num_species,
                hidden_dim=hidden_dim,
                dropout=dropout,
                use_sequence=use_tsrna_seq,
            )
            if tsrna_attr_fusion == "gated":
                self.attribute_fusion = TsrnaAttributeGatedFusion(hidden_dim=hidden_dim, mask_dim=7, dropout=dropout)
            elif tsrna_attr_fusion == "concat":
                self.attribute_fusion = TsrnaAttributeConcatFusion(hidden_dim=hidden_dim, dropout=dropout)
            elif tsrna_attr_fusion == "add":
                self.attribute_fusion = None
            else:
                raise ValueError(f"Unknown tsRNA attribute fusion mode: {tsrna_attr_fusion}")
        else:
            self.attribute_encoder = None
            self.attribute_fusion = None
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.tsrna_embedding.weight)
        nn.init.xavier_uniform_(self.disease_embedding.weight)
        nn.init.xavier_uniform_(self.doid_embedding.weight)

    @staticmethod
    def _to_device(value: torch.Tensor, device: torch.device) -> torch.Tensor:
        return value.to(device)

    def initial_embeddings(self, graph_data: dict[str, torch.Tensor], device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
        tsrna = self.tsrna_embedding.weight
        disease = self.disease_embedding.weight
        if self.use_svd_features and "tsrna_svd_features" in graph_data and "disease_svd_features" in graph_data:
            tsrna_svd = self._to_device(graph_data["tsrna_svd_features"], device).float()
            disease_svd = self._to_device(graph_data["disease_svd_features"], device).float()
            tsrna = tsrna + self.tsrna_svd_proj(tsrna_svd)
            disease = disease + self.disease_svd_proj(disease_svd)
        return tsrna, disease

    def attribute_embeddings(self, graph_data: dict[str, torch.Tensor], device: torch.device) -> tuple[torch.Tensor | None, torch.Tensor | None]:
        if not self.use_tsrna_attr or self.attribute_encoder is None:
            return None, None
        h_attr = self.attribute_encoder(
            self._to_device(graph_data["tsrna_kmer_features"], device),
            self._to_device(graph_data["tsrna_length"], device),
            self._to_device(graph_data["tsrna_type_ids"], device),
            self._to_device(graph_data["tsrna_source_ids"], device),
            self._to_device(graph_data["tsrna_anticodon_ids"], device),
            self._to_device(graph_data["tsrna_amino_ids"], device),
            self._to_device(graph_data["tsrna_species_ids"], device),
            self._to_device(graph_data["tsrna_attr_mask"], device),
        )
        return h_attr, self._to_device(graph_data["tsrna_attr_mask"], device)

    def fuse_tsrna_attributes(
        self,
        h_graph: torch.Tensor,
        h_attr: torch.Tensor | None,
        attr_mask: torch.Tensor | None,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        if not self.use_tsrna_attr or h_attr is None or attr_mask is None:
            return h_graph, None
        if self.tsrna_attr_fusion == "add":
            return h_graph + h_attr, torch.ones_like(h_graph)
        if self.attribute_fusion is None:
            return h_graph, None
        return self.attribute_fusion(h_graph, h_attr, attr_mask)

    def encode_view(
        self,
        tsrna_emb: torch.Tensor,
        disease_emb: torch.Tensor,
        edge_tsrna: torch.Tensor,
        edge_disease: torch.Tensor,
        edge_features: torch.Tensor,
        layers: nn.ModuleList,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        for layer in layers:
            tsrna_emb, disease_emb = layer(tsrna_emb, disease_emb, edge_tsrna, edge_disease, edge_features)
        return tsrna_emb, disease_emb

    def encode(self, graph_data: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        device = self.tsrna_embedding.weight.device
        base_t, base_d = self.initial_embeddings(graph_data, device)

        edge_t = self._to_device(graph_data["edge_tsrna"], device)
        edge_d = self._to_device(graph_data["edge_disease"], device)
        edge_f = self._to_device(graph_data["edge_features"], device).float()
        t1, d1 = self.encode_view(base_t, base_d, edge_t, edge_d, edge_f, self.view1_layers)

        if "recon_edge_tsrna" in graph_data and graph_data["recon_edge_tsrna"].numel() > 0:
            rt = self._to_device(graph_data["recon_edge_tsrna"], device)
            rd = self._to_device(graph_data["recon_edge_disease"], device)
            rf = self._to_device(graph_data["recon_edge_features"], device).float()
            t2, d2 = self.encode_view(base_t, base_d, rt, rd, rf, self.view2_layers)
        else:
            t2, d2 = t1, d1

        doid_emb = self.doid_embedding.weight
        if self.use_ontology:
            up = self._to_device(graph_data["doid_up_edges"], device)
            down = self._to_device(graph_data["doid_down_edges"], device)
            for layer in self.ontology_layers:
                doid_emb = layer(doid_emb, up, down)

        h_attr, attr_mask = self.attribute_embeddings(graph_data, device)

        return {"t1": t1, "d1": d1, "t2": t2, "d2": d2, "doid": doid_emb, "t_attr": h_attr, "attr_mask": attr_mask}

    def disease_ontology_repr(self, batch_disease_ids: torch.Tensor, doid_emb: torch.Tensor, graph_data: dict[str, torch.Tensor]) -> torch.Tensor:
        device = batch_disease_ids.device
        out = torch.zeros((batch_disease_ids.shape[0], doid_emb.shape[-1]), dtype=doid_emb.dtype, device=device)
        if not self.use_ontology:
            return out
        mapping = self._to_device(graph_data["disease_to_doid_idx"], device)
        idx = mapping[batch_disease_ids]
        valid = idx >= 0
        if valid.any():
            out[valid] = doid_emb[idx[valid]]
        return out

    def path_repr(self, h_t: torch.Tensor, batch_disease_ids: torch.Tensor, doid_emb: torch.Tensor, graph_data: dict[str, torch.Tensor]) -> torch.Tensor:
        if not (self.use_ontology and self.use_path_attention):
            return torch.zeros_like(h_t)
        device = batch_disease_ids.device
        path_idx = self._to_device(graph_data["disease_path_indices"], device)[batch_disease_ids]
        path_mask = self._to_device(graph_data["disease_path_mask"], device)[batch_disease_ids]
        return self.path_attention(h_t, doid_emb, path_idx, path_mask)

    def forward(
        self,
        batch_tsrna_ids: torch.Tensor,
        batch_disease_ids: torch.Tensor,
        graph_data: dict[str, torch.Tensor],
        return_aux: bool = False,
        temperature: float = 0.2,
    ):
        enc = self.encode(graph_data)
        h_t = 0.5 * (enc["t1"][batch_tsrna_ids] + enc["t2"][batch_tsrna_ids])
        h_t_graph = h_t
        batch_attr = enc["t_attr"][batch_tsrna_ids] if enc["t_attr"] is not None else None
        batch_attr_mask = enc["attr_mask"][batch_tsrna_ids] if enc["attr_mask"] is not None else None
        h_t, gate = self.fuse_tsrna_attributes(h_t, batch_attr, batch_attr_mask)
        h_d_base = 0.5 * (enc["d1"][batch_disease_ids] + enc["d2"][batch_disease_ids])
        h_d_onto = self.disease_ontology_repr(batch_disease_ids, enc["doid"], graph_data)
        h_d = self.disease_fusion_norm(h_d_base + self.ontology_to_disease(h_d_onto))
        h_path = self.path_repr(h_t, batch_disease_ids, enc["doid"], graph_data)
        logits = self.decoder(h_t, h_d, h_d_onto, h_path)

        if not return_aux:
            return logits

        cl_loss = info_nce_loss(enc["t1"], enc["t2"], temperature) + info_nce_loss(enc["d1"], enc["d2"], temperature)
        attr_cl_loss = logits.new_tensor(0.0)
        if self.use_tsrna_attr and self.use_attr_contrastive and enc["t_attr"] is not None and enc["attr_mask"] is not None:
            unique_tsrna = torch.unique(batch_tsrna_ids)
            unique_graph = 0.5 * (enc["t1"][unique_tsrna] + enc["t2"][unique_tsrna])
            unique_attr = enc["t_attr"][unique_tsrna]
            valid = enc["attr_mask"][unique_tsrna].sum(dim=1) > 0
            attr_cl_loss = attribute_contrastive_loss(unique_graph, unique_attr, valid_mask=valid, temperature=temperature)
        return logits, {"contrastive_loss": cl_loss, "attribute_contrastive_loss": attr_cl_loss, "attribute_gate": gate}
