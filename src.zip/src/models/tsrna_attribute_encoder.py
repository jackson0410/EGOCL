from __future__ import annotations

import torch
from torch import nn


class TsrnaAttributeEncoder(nn.Module):
    def __init__(
        self,
        kmer_dim: int,
        num_types: int,
        num_sources: int,
        num_anticodons: int,
        num_aminos: int,
        num_species: int,
        hidden_dim: int = 128,
        dropout: float = 0.2,
        use_sequence: bool = True,
    ) -> None:
        super().__init__()
        self.use_sequence = use_sequence
        small_dim = max(16, hidden_dim // 4)
        cat_dim = max(8, hidden_dim // 8)

        self.kmer_mlp = nn.Sequential(
            nn.Linear(kmer_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, small_dim),
            nn.ReLU(),
        )
        self.length_mlp = nn.Sequential(
            nn.Linear(1, small_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.type_emb = nn.Embedding(num_types, cat_dim)
        self.source_emb = nn.Embedding(num_sources, cat_dim)
        self.anticodon_emb = nn.Embedding(num_anticodons, cat_dim)
        self.amino_emb = nn.Embedding(num_aminos, cat_dim)
        self.species_emb = nn.Embedding(num_species, cat_dim)

        input_dim = small_dim + small_dim + cat_dim * 5 + 7
        self.output_mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
        )

    def forward(
        self,
        tsrna_kmer_features: torch.Tensor,
        tsrna_length: torch.Tensor,
        tsrna_type_ids: torch.Tensor,
        tsrna_source_ids: torch.Tensor,
        tsrna_anticodon_ids: torch.Tensor,
        tsrna_amino_ids: torch.Tensor,
        tsrna_species_ids: torch.Tensor,
        tsrna_attr_mask: torch.Tensor,
    ) -> torch.Tensor:
        if self.use_sequence:
            kmer_repr = self.kmer_mlp(tsrna_kmer_features.float())
        else:
            kmer_repr = torch.zeros(
                (tsrna_length.shape[0], self.kmer_mlp[-2].out_features),
                dtype=tsrna_length.dtype,
                device=tsrna_length.device,
            )
        length_repr = self.length_mlp(tsrna_length.float())
        pieces = [
            kmer_repr,
            length_repr,
            self.type_emb(tsrna_type_ids.long()),
            self.source_emb(tsrna_source_ids.long()),
            self.anticodon_emb(tsrna_anticodon_ids.long()),
            self.amino_emb(tsrna_amino_ids.long()),
            self.species_emb(tsrna_species_ids.long()),
            tsrna_attr_mask.float(),
        ]
        return self.output_mlp(torch.cat(pieces, dim=-1))


class TsrnaAttributeGatedFusion(nn.Module):
    def __init__(self, hidden_dim: int = 128, mask_dim: int = 7, dropout: float = 0.2) -> None:
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2 + mask_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

    def forward(
        self,
        h_t_graph: torch.Tensor,
        h_t_attr: torch.Tensor,
        tsrna_attr_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        z_t = self.gate(torch.cat([h_t_graph, h_t_attr, tsrna_attr_mask.float()], dim=-1))
        return h_t_graph + z_t * h_t_attr, z_t


class TsrnaAttributeConcatFusion(nn.Module):
    def __init__(self, hidden_dim: int = 128, dropout: float = 0.2) -> None:
        super().__init__()
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
        )

    def forward(
        self,
        h_t_graph: torch.Tensor,
        h_t_attr: torch.Tensor,
        tsrna_attr_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        del tsrna_attr_mask
        fused = self.fusion(torch.cat([h_t_graph, h_t_attr], dim=-1))
        gate_proxy = torch.ones_like(h_t_graph)
        return fused, gate_proxy
