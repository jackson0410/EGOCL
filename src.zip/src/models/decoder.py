from __future__ import annotations

import torch
from torch import nn


class MLPDecoder(nn.Module):
    def __init__(self, hidden_dim: int, dropout: float = 0.1) -> None:
        super().__init__()
        input_dim = hidden_dim * 6
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        h_t: torch.Tensor,
        h_d_assoc: torch.Tensor,
        h_d_onto: torch.Tensor,
        h_d_path: torch.Tensor,
    ) -> torch.Tensor:
        z = torch.cat(
            [
                h_t,
                h_d_assoc,
                h_d_onto,
                h_d_path,
                h_t * h_d_assoc,
                torch.abs(h_t - h_d_assoc),
            ],
            dim=-1,
        )
        return self.mlp(z).squeeze(-1)
