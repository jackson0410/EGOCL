from __future__ import annotations

import torch
from torch import nn


class EvidenceGatedGraphLayer(nn.Module):
    """Bidirectional tsRNA-disease message passing with optional evidence gates."""

    def __init__(
        self,
        hidden_dim: int,
        edge_feat_dim: int,
        dropout: float = 0.1,
        use_evidence_gate: bool = True,
    ) -> None:
        super().__init__()
        self.use_evidence_gate = use_evidence_gate
        self.msg_t_to_d = nn.Linear(hidden_dim, hidden_dim)
        self.msg_d_to_t = nn.Linear(hidden_dim, hidden_dim)
        self.gate_mlp = nn.Sequential(
            nn.Linear(hidden_dim * 2 + edge_feat_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )
        self.tsrna_norm = nn.LayerNorm(hidden_dim)
        self.disease_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ReLU()

    def forward(
        self,
        tsrna_emb: torch.Tensor,
        disease_emb: torch.Tensor,
        edge_tsrna: torch.Tensor,
        edge_disease: torch.Tensor,
        edge_features: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if edge_tsrna.numel() == 0:
            return tsrna_emb, disease_emb

        h_t = tsrna_emb[edge_tsrna]
        h_d = disease_emb[edge_disease]

        if self.use_evidence_gate:
            gate_input = torch.cat([h_t, h_d, edge_features], dim=-1)
            gate = torch.sigmoid(self.gate_mlp(gate_input))
        else:
            gate = torch.ones((edge_tsrna.shape[0], 1), dtype=tsrna_emb.dtype, device=tsrna_emb.device)

        disease_messages = self.msg_t_to_d(h_t) * gate
        tsrna_messages = self.msg_d_to_t(h_d) * gate

        disease_agg = torch.zeros_like(disease_emb)
        tsrna_agg = torch.zeros_like(tsrna_emb)
        disease_agg.index_add_(0, edge_disease, disease_messages)
        tsrna_agg.index_add_(0, edge_tsrna, tsrna_messages)

        updated_disease = self.disease_norm(disease_emb + self.dropout(self.activation(disease_agg)))
        updated_tsrna = self.tsrna_norm(tsrna_emb + self.dropout(self.activation(tsrna_agg)))
        return updated_tsrna, updated_disease


class DirectionAwareOntologyLayer(nn.Module):
    """Direction-aware message passing over DOID child-parent DAG edges."""

    def __init__(
        self,
        hidden_dim: int,
        dropout: float = 0.1,
        use_direction: bool = True,
    ) -> None:
        super().__init__()
        self.use_direction = use_direction
        self.up_linear = nn.Linear(hidden_dim, hidden_dim)
        self.down_linear = nn.Linear(hidden_dim, hidden_dim)
        self.shared_linear = nn.Linear(hidden_dim, hidden_dim)
        self.norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = nn.ReLU()

    def _aggregate(self, doid_emb: torch.Tensor, edges: torch.Tensor, linear: nn.Linear) -> torch.Tensor:
        agg = torch.zeros_like(doid_emb)
        if edges.numel() == 0:
            return agg
        src, dst = edges[0], edges[1]
        messages = linear(doid_emb[src])
        agg.index_add_(0, dst, messages)
        return agg

    def forward(
        self,
        doid_emb: torch.Tensor,
        up_edges: torch.Tensor,
        down_edges: torch.Tensor,
    ) -> torch.Tensor:
        if self.use_direction:
            agg = self._aggregate(doid_emb, up_edges, self.up_linear)
            agg = agg + self._aggregate(doid_emb, down_edges, self.down_linear)
        else:
            agg = self._aggregate(doid_emb, up_edges, self.shared_linear)
            agg = agg + self._aggregate(doid_emb, down_edges, self.shared_linear)

        return self.norm(doid_emb + self.dropout(self.activation(agg)))
