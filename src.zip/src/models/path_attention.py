from __future__ import annotations

import math

import torch
from torch import nn


class OntologyPathAttention(nn.Module):
    """tsRNA-guided cross-attention over DOID path nodes."""

    def __init__(self, hidden_dim: int, dropout: float = 0.1, use_default_path: bool = False) -> None:
        super().__init__()
        self.query_proj = nn.Linear(hidden_dim, hidden_dim)
        self.key_proj = nn.Linear(hidden_dim, hidden_dim)
        self.value_proj = nn.Linear(hidden_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.default_path = nn.Parameter(torch.zeros(hidden_dim)) if use_default_path else None

    def forward(
        self,
        tsrna_emb_batch: torch.Tensor,
        doid_emb: torch.Tensor,
        path_indices: torch.Tensor,
        path_mask: torch.Tensor,
    ) -> torch.Tensor:
        if path_indices.dim() == 3 and path_mask.dim() == 3:
            batch_size, num_paths, max_path_len = path_indices.shape
            flat_indices = path_indices.reshape(batch_size * num_paths, max_path_len)
            flat_mask = path_mask.reshape(batch_size * num_paths, max_path_len)
            repeated_query = tsrna_emb_batch.repeat_interleave(num_paths, dim=0)

            flat_repr = self._attend_single_path(repeated_query, doid_emb, flat_indices, flat_mask)
            path_repr = flat_repr.reshape(batch_size, num_paths, -1)
            valid_path = (flat_mask.bool() & (flat_indices >= 0)).any(dim=1).reshape(batch_size, num_paths)
            denom = valid_path.sum(dim=1, keepdim=True).clamp(min=1).to(path_repr.dtype)
            pooled = (path_repr * valid_path.to(path_repr.dtype).unsqueeze(-1)).sum(dim=1) / denom
            has_any_path = valid_path.any(dim=1)
            return pooled * has_any_path.to(pooled.dtype).unsqueeze(-1)

        if path_indices.dim() == 2 and path_mask.dim() == 2:
            return self._attend_single_path(tsrna_emb_batch, doid_emb, path_indices, path_mask)

        raise ValueError("path_indices/path_mask must be [B, max_path_len] or [B, num_paths, max_path_len]")

    def _attend_single_path(
        self,
        tsrna_emb_batch: torch.Tensor,
        doid_emb: torch.Tensor,
        path_indices: torch.Tensor,
        path_mask: torch.Tensor,
    ) -> torch.Tensor:
        valid_mask = path_mask.bool() & (path_indices >= 0)
        safe_indices = path_indices.clamp(min=0)
        path_emb = doid_emb[safe_indices]

        query = self.query_proj(tsrna_emb_batch).unsqueeze(1)
        key = self.key_proj(path_emb)
        value = self.value_proj(path_emb)

        scores = torch.matmul(query, key.transpose(1, 2)).squeeze(1)
        scores = scores / math.sqrt(query.shape[-1])
        scores = scores.masked_fill(~valid_mask, torch.finfo(scores.dtype).min)

        has_path = valid_mask.any(dim=1)
        attn = torch.zeros_like(scores)
        if has_path.any():
            attn_valid = torch.softmax(scores[has_path], dim=-1)
            attn[has_path] = self.dropout(attn_valid)

        path_repr = torch.bmm(attn.unsqueeze(1), value).squeeze(1)
        path_repr = self.out_proj(path_repr)

        if self.default_path is not None and (~has_path).any():
            path_repr = path_repr.clone()
            path_repr[~has_path] = self.default_path
        else:
            path_repr = path_repr * has_path.to(path_repr.dtype).unsqueeze(-1)

        return path_repr
