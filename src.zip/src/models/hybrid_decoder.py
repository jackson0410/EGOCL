from __future__ import annotations

import torch
from torch import nn

from src.models.decoder import MLPDecoder


class HybridDecoder(nn.Module):
    def __init__(self, hidden_dim: int, dropout: float = 0.1) -> None:
        super().__init__()
        self.mlp = MLPDecoder(hidden_dim, dropout)
        self.bilinear = nn.Bilinear(hidden_dim, hidden_dim, 1)
        input_dim = hidden_dim * 6
        self.fm_linear = nn.Linear(input_dim, 1)
        self.fm_factor = nn.Parameter(torch.empty(input_dim, hidden_dim))
        nn.init.xavier_uniform_(self.fm_factor)

    def _features(
        self,
        h_t: torch.Tensor,
        h_d_assoc: torch.Tensor,
        h_d_onto: torch.Tensor,
        h_d_path: torch.Tensor,
    ) -> torch.Tensor:
        return torch.cat(
            [h_t, h_d_assoc, h_d_onto, h_d_path, h_t * h_d_assoc, torch.abs(h_t - h_d_assoc)],
            dim=-1,
        )

    def forward(
        self,
        h_t: torch.Tensor,
        h_d_assoc: torch.Tensor,
        h_d_onto: torch.Tensor,
        h_d_path: torch.Tensor,
    ) -> torch.Tensor:
        z = self._features(h_t, h_d_assoc, h_d_onto, h_d_path)
        mlp_score = self.mlp(h_t, h_d_assoc, h_d_onto, h_d_path)
        bilinear_score = self.bilinear(h_t, h_d_assoc).squeeze(-1)
        linear_score = self.fm_linear(z).squeeze(-1)
        square_of_sum = (z @ self.fm_factor).pow(2)
        sum_of_square = (z.pow(2) @ self.fm_factor.pow(2))
        fm_score = 0.5 * (square_of_sum - sum_of_square).sum(dim=-1)
        return mlp_score + bilinear_score + linear_score + fm_score
