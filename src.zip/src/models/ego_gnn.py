from __future__ import annotations

import torch
from torch import nn

from src.models.decoder import MLPDecoder
from src.models.layers import DirectionAwareOntologyLayer, EvidenceGatedGraphLayer
from src.models.path_attention import OntologyPathAttention


class EgoGNN(nn.Module):
    def __init__(
        self,
        num_tsrna: int,
        num_disease: int,
        num_doid: int,
        hidden_dim: int = 64,
        num_layers: int = 2,
        edge_feat_dim: int = 6,
        dropout: float = 0.1,
        use_evidence_gate: bool = True,
        use_ontology: bool = True,
        use_path_attention: bool = True,
        use_direction: bool = True,
    ) -> None:
        super().__init__()
        self.use_ontology = use_ontology
        self.use_path_attention = use_path_attention

        self.tsrna_embedding = nn.Embedding(num_tsrna, hidden_dim)
        self.disease_embedding = nn.Embedding(num_disease, hidden_dim)
        self.doid_embedding = nn.Embedding(num_doid, hidden_dim)

        self.assoc_layers = nn.ModuleList(
            [
                EvidenceGatedGraphLayer(
                    hidden_dim=hidden_dim,
                    edge_feat_dim=edge_feat_dim,
                    dropout=dropout,
                    use_evidence_gate=use_evidence_gate,
                )
                for _ in range(num_layers)
            ]
        )
        self.ontology_layers = nn.ModuleList(
            [
                DirectionAwareOntologyLayer(
                    hidden_dim=hidden_dim,
                    dropout=dropout,
                    use_direction=use_direction,
                )
                for _ in range(num_layers)
            ]
        )
        self.ontology_to_disease = nn.Linear(hidden_dim, hidden_dim)
        self.disease_fusion_norm = nn.LayerNorm(hidden_dim)
        self.path_attention = OntologyPathAttention(hidden_dim=hidden_dim, dropout=dropout)
        self.decoder = MLPDecoder(hidden_dim=hidden_dim, dropout=dropout)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.tsrna_embedding.weight)
        nn.init.xavier_uniform_(self.disease_embedding.weight)
        nn.init.xavier_uniform_(self.doid_embedding.weight)

    @staticmethod
    def _to_device(value: torch.Tensor, device: torch.device) -> torch.Tensor:
        return value.to(device)

    def _association_graph_tensors(self, graph_data: dict[str, torch.Tensor], device: torch.device) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if "edge_tsrna" in graph_data and "edge_disease" in graph_data and "edge_features" in graph_data:
            return (
                self._to_device(graph_data["edge_tsrna"], device),
                self._to_device(graph_data["edge_disease"], device),
                self._to_device(graph_data["edge_features"], device).float(),
            )

        return (
            self._to_device(graph_data["pos_tsrna_ids"], device),
            self._to_device(graph_data["pos_disease_ids"], device),
            self._to_device(graph_data["pos_edge_features"], device).float(),
        )

    def _disease_ontology_repr(
        self,
        batch_disease_ids: torch.Tensor,
        doid_emb: torch.Tensor,
        graph_data: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        device = batch_disease_ids.device
        disease_to_doid_idx = self._to_device(graph_data["disease_to_doid_idx"], device)
        mapped_idx = disease_to_doid_idx[batch_disease_ids]
        valid = mapped_idx >= 0
        safe_idx = mapped_idx.clamp(min=0)
        h_d_onto = torch.zeros((batch_disease_ids.shape[0], doid_emb.shape[-1]), dtype=doid_emb.dtype, device=device)
        if valid.any():
            h_d_onto[valid] = doid_emb[safe_idx[valid]]
        return h_d_onto

    def _path_repr(
        self,
        batch_tsrna_emb: torch.Tensor,
        batch_disease_ids: torch.Tensor,
        doid_emb: torch.Tensor,
        graph_data: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        device = batch_disease_ids.device
        path_indices_all = self._to_device(graph_data["disease_path_indices"], device)
        path_mask_all = self._to_device(graph_data["disease_path_mask"], device)
        path_indices = path_indices_all[batch_disease_ids]
        path_mask = path_mask_all[batch_disease_ids]

        return self.path_attention(batch_tsrna_emb, doid_emb, path_indices, path_mask)

    def forward(
        self,
        batch_tsrna_ids: torch.Tensor,
        batch_disease_ids: torch.Tensor,
        graph_data: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        device = batch_tsrna_ids.device

        tsrna_emb = self.tsrna_embedding.weight
        disease_emb = self.disease_embedding.weight
        doid_emb = self.doid_embedding.weight

        edge_tsrna, edge_disease, edge_features = self._association_graph_tensors(graph_data, device)
        for layer in self.assoc_layers:
            tsrna_emb, disease_emb = layer(tsrna_emb, disease_emb, edge_tsrna, edge_disease, edge_features)

        if self.use_ontology:
            up_edges = self._to_device(graph_data["doid_up_edges"], device)
            down_edges = self._to_device(graph_data["doid_down_edges"], device)
            for layer in self.ontology_layers:
                doid_emb = layer(doid_emb, up_edges, down_edges)
            h_d_onto = self._disease_ontology_repr(batch_disease_ids, doid_emb, graph_data)
        else:
            h_d_onto = torch.zeros((batch_disease_ids.shape[0], disease_emb.shape[-1]), dtype=disease_emb.dtype, device=device)

        h_t = tsrna_emb[batch_tsrna_ids]
        h_d_assoc_base = disease_emb[batch_disease_ids]
        h_d_assoc = self.disease_fusion_norm(h_d_assoc_base + self.ontology_to_disease(h_d_onto))

        if self.use_ontology and self.use_path_attention:
            h_d_path = self._path_repr(h_t, batch_disease_ids, doid_emb, graph_data)
        else:
            h_d_path = torch.zeros_like(h_d_assoc)

        return self.decoder(h_t, h_d_assoc, h_d_onto, h_d_path)
