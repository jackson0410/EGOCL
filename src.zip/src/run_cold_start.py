from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.data_utils import build_exclusion_set, build_positive_pairs, load_graph_tensors, load_tsrna_attribute_tensors
from src.metrics import evaluate_binary_classification
from src.models.ego_clgnn import EgoCLGNN
from src.train import (
    build_train_graph_data,
    evaluate_split,
    make_labeled_pairs,
    move_graph_data_to_device,
    save_predictions,
    save_split_files,
    selected_threshold_metrics,
)
from src.train_clgnn import (
    add_fold_local_svd,
    add_sampling_svd_features,
    attribute_meta_counts,
    save_attr_gate_statistics,
    save_negative_sampling_stats,
    split_score_means,
    train_one_epoch_clgnn,
)
from src.utils import ensure_dir, save_csv, set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run strict cold-start EGOCL experiments.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", default="results/egocl_cold_start")
    parser.add_argument("--cold_start_mode", choices=["tsrna"], default="tsrna")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--use_evidence_gate", action="store_true")
    parser.add_argument("--use_ontology", action="store_true")
    parser.add_argument("--use_path_attention", action="store_true")
    parser.add_argument("--use_direction", action="store_true")
    parser.add_argument("--use_svd_features", action="store_true")
    parser.add_argument("--svd_dim", type=int, default=64)
    parser.add_argument("--svd_topk", type=int, default=20)
    parser.add_argument("--use_contrastive", action="store_true")
    parser.add_argument("--contrastive_weight", type=float, default=0.1)
    parser.add_argument("--temperature", type=float, default=0.2)
    parser.add_argument("--use_bpr", action="store_true")
    parser.add_argument("--bpr_weight", type=float, default=0.1)
    parser.add_argument("--negative_sampling", choices=["strict_random", "strict_three_level"], default="strict_three_level")
    parser.add_argument("--easy_negative_ratio", type=float, default=0.5)
    parser.add_argument("--ontology_negative_ratio", type=float, default=0.3)
    parser.add_argument("--svd_negative_ratio", type=float, default=0.2)
    parser.add_argument("--decoder_type", choices=["mlp", "hybrid"], default="hybrid")
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--use_focal_loss", action="store_true")
    parser.add_argument("--focal_alpha", type=float, default=0.85)
    parser.add_argument("--focal_gamma", type=float, default=1.5)
    parser.add_argument("--use_soft_f1_loss", action="store_true")
    parser.add_argument("--soft_f1_weight", type=float, default=0.1)
    parser.add_argument("--use_tsrna_attr", action="store_true")
    parser.add_argument("--use_tsrna_seq", action="store_true")
    parser.add_argument("--tsrna_kmer", type=int, default=3)
    parser.add_argument("--tsrna_attr_fusion", choices=["gated", "concat", "add"], default="gated")
    parser.add_argument("--use_attr_contrastive", action="store_true")
    parser.add_argument("--attr_cl_weight", type=float, default=0.05)
    parser.add_argument("--quick_test", action="store_true")
    return parser.parse_args()


def resolve_device(device_arg: str) -> torch.device:
    if device_arg == "cuda" and not torch.cuda.is_available():
        print("[run_cold_start] CUDA requested but unavailable; using CPU", flush=True)
        return torch.device("cpu")
    return torch.device(device_arg)


def make_tsrna_cold_splits(pos_pairs: torch.Tensor, num_folds: int, fold_id: int, seed: int) -> dict[str, torch.Tensor]:
    tsrna_ids = sorted(set(int(x) for x in pos_pairs[:, 0].tolist()))
    rng = random.Random(seed)
    rng.shuffle(tsrna_ids)
    folds = [set(chunk.tolist()) for chunk in np.array_split(np.asarray(tsrna_ids, dtype=int), num_folds)]
    test_entities = folds[fold_id]
    if num_folds >= 3:
        val_entities = folds[(fold_id + 1) % num_folds]
        train_entities = set(tsrna_ids) - test_entities - val_entities
    else:
        remaining = sorted(set(tsrna_ids) - test_entities)
        rng.shuffle(remaining)
        val_count = max(1, int(round(len(remaining) * 0.2)))
        val_entities = set(remaining[:val_count])
        train_entities = set(remaining[val_count:])

    train_idx: list[int] = []
    val_idx: list[int] = []
    test_idx: list[int] = []
    for idx, (tsrna_id, _) in enumerate(pos_pairs.tolist()):
        tsrna_id = int(tsrna_id)
        if tsrna_id in test_entities:
            test_idx.append(idx)
        elif tsrna_id in val_entities:
            val_idx.append(idx)
        elif tsrna_id in train_entities:
            train_idx.append(idx)

    splits = {
        "train_idx": torch.tensor(train_idx, dtype=torch.long),
        "val_idx": torch.tensor(val_idx, dtype=torch.long),
        "test_idx": torch.tensor(test_idx, dtype=torch.long),
    }
    splits["train_pairs"] = pos_pairs[splits["train_idx"]]
    splits["val_pairs"] = pos_pairs[splits["val_idx"]]
    splits["test_pairs"] = pos_pairs[splits["test_idx"]]
    splits["train_entities"] = torch.tensor(sorted(train_entities), dtype=torch.long)
    splits["val_entities"] = torch.tensor(sorted(val_entities), dtype=torch.long)
    splits["test_entities"] = torch.tensor(sorted(test_entities), dtype=torch.long)
    return splits


def _ontology_candidate_diseases(disease_id: int, graph_data: dict[str, torch.Tensor | int | list[str]]) -> list[int]:
    disease_to_doid = graph_data["disease_to_doid_idx"].long()
    doid_idx = int(disease_to_doid[disease_id].item())
    if doid_idx < 0:
        return []
    up_edges = graph_data["doid_up_edges"].long()
    parents = {doid_idx}
    for child, parent in up_edges.t().tolist():
        if int(child) == doid_idx:
            parents.add(int(parent))
    candidates: set[int] = set()
    for disease_idx, mapped in enumerate(disease_to_doid.tolist()):
        if int(mapped) in parents:
            candidates.add(int(disease_idx))
    return list(candidates)


def _svd_candidate_diseases(disease_id: int, graph_data: dict[str, torch.Tensor | int | list[str]]) -> list[int]:
    features = graph_data.get("sampling_disease_svd_features", graph_data.get("disease_svd_features"))
    if not isinstance(features, torch.Tensor) or features.numel() == 0:
        return []
    norm = torch.nn.functional.normalize(features.float(), p=2, dim=1)
    scores = norm[int(disease_id)] @ norm.T
    scores[int(disease_id)] = -float("inf")
    return torch.argsort(scores, descending=True).tolist()


def build_candidate_cache(
    graph_data: dict[str, torch.Tensor | int | list[str]],
    num_disease: int,
) -> tuple[dict[int, list[int]], dict[int, list[int]]]:
    ontology_cache = {disease_id: _ontology_candidate_diseases(disease_id, graph_data) for disease_id in range(num_disease)}
    svd_cache = {disease_id: _svd_candidate_diseases(disease_id, graph_data)[: min(num_disease, 80)] for disease_id in range(num_disease)}
    return ontology_cache, svd_cache


def sample_tsrna_cold_negatives(
    pos_pairs: torch.Tensor,
    num_disease: int,
    num_samples: int,
    exclusion_set: set[tuple[int, int]],
    graph_data: dict[str, torch.Tensor | int | list[str]],
    ontology_cache: dict[int, list[int]],
    svd_cache: dict[int, list[int]],
    seed: int,
    mode: str,
    easy_ratio: float,
    ontology_ratio: float,
    svd_ratio: float,
) -> tuple[torch.Tensor, dict[str, int]]:
    rng = random.Random(seed)
    positives = [(int(t), int(d)) for t, d in pos_pairs.tolist()]
    if not positives or num_samples <= 0:
        return torch.empty((0, 2), dtype=torch.long), {
            "num_easy_negative": 0,
            "num_ontology_negative": 0,
            "num_svd_negative": 0,
            "fallback_count": 0,
        }

    if mode == "strict_random":
        easy_target, ontology_target, svd_target = num_samples, 0, 0
    else:
        ratio_sum = easy_ratio + ontology_ratio + svd_ratio
        if abs(ratio_sum - 1.0) > 1e-6:
            raise ValueError(f"Cold-start negative ratios must sum to 1.0, got {ratio_sum}")
        ontology_target = int(round(num_samples * ontology_ratio))
        svd_target = int(round(num_samples * svd_ratio))
        easy_target = num_samples - ontology_target - svd_target

    blocked = set(exclusion_set)
    negatives: set[tuple[int, int]] = set()

    def try_add_from_candidates(target: int, source: str) -> int:
        if target <= 0:
            return 0
        added = 0
        shuffled = positives[:]
        rng.shuffle(shuffled)
        rounds = 0
        while added < target and rounds < max(3, len(shuffled)):
            rounds += 1
            for tsrna_id, disease_id in shuffled:
                if source == "ontology":
                    candidates = ontology_cache.get(disease_id, [])
                elif source == "svd":
                    candidates = svd_cache.get(disease_id, [])
                else:
                    candidates = list(range(num_disease))
                rng.shuffle(candidates)
                for cand_disease in candidates:
                    pair = (tsrna_id, int(cand_disease))
                    if int(cand_disease) == disease_id or pair in blocked or pair in negatives:
                        continue
                    negatives.add(pair)
                    added += 1
                    break
                if added >= target:
                    break
        return added

    ontology_added = try_add_from_candidates(ontology_target, "ontology")
    svd_added = try_add_from_candidates(svd_target, "svd")
    easy_added = try_add_from_candidates(num_samples - len(negatives), "easy")
    fallback_count = max(0, ontology_target - ontology_added) + max(0, svd_target - svd_added)

    if len(negatives) < num_samples:
        raise RuntimeError(f"Unable to sample enough cold-start negatives: {len(negatives)} / {num_samples}")

    negatives_tensor = torch.tensor(sorted(negatives)[:num_samples], dtype=torch.long)
    stats = {
        "num_easy_negative": int(easy_added),
        "num_ontology_negative": int(ontology_added),
        "num_svd_negative": int(svd_added),
        "fallback_count": int(fallback_count),
    }
    return negatives_tensor, stats


def save_entity_files(output_dir: Path, splits: dict[str, torch.Tensor]) -> None:
    for split in ["train", "val", "test"]:
        rows = [{"tsrna_id": int(x)} for x in splits[f"{split}_entities"].tolist()]
        save_csv(rows, output_dir / f"{split}_cold_tsrna_ids.csv", ["tsrna_id"])


def save_cold_summary(output_dir: Path) -> None:
    summarize_cv(output_dir)
    mean_std = {}
    for row in (output_dir / "cv_mean_std.csv").read_text(encoding="utf-8").splitlines()[1:]:
        if not row.strip():
            continue
        metric, mean, std = row.split(",")[:3]
        mean_std[metric] = (float(mean), float(std))
    lines = [
        "# EGOCL tsRNA Cold-Start Results",
        "",
        "| Metric | Mean | Std |",
        "|---|---:|---:|",
    ]
    for metric in [
        "test_auc",
        "test_aupr",
        "test_selected_threshold_f1",
        "test_selected_threshold_precision",
        "test_selected_threshold_recall",
        "test_oracle_best_f1",
        "best_val_aupr",
    ]:
        if metric in mean_std:
            mean, std = mean_std[metric]
            lines.append(f"| {metric} | {mean:.4f} | {std:.4f} |")
    (output_dir / "cold_start_summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_fold(args: argparse.Namespace, fold_id: int) -> None:
    set_seed(args.seed + fold_id)
    output_dir = ensure_dir(Path(args.output_dir) / f"fold_{fold_id}")
    device = resolve_device(args.device)
    graph_data = load_graph_tensors(args.data_dir)
    if args.use_tsrna_attr:
        graph_data.update(load_tsrna_attribute_tensors(args.data_dir))
    pos_pairs = build_positive_pairs(graph_data)
    exclusion_set = build_exclusion_set(graph_data)
    splits = make_tsrna_cold_splits(pos_pairs, args.num_folds, fold_id, args.seed)

    if min(splits["train_pairs"].shape[0], splits["val_pairs"].shape[0], splits["test_pairs"].shape[0]) == 0:
        raise RuntimeError(f"Empty cold-start split at fold {fold_id}")

    sampling_graph_data = graph_data
    if args.negative_sampling == "strict_three_level":
        sampling_graph_data = add_sampling_svd_features(graph_data, splits["train_pairs"], args.svd_dim)
    ontology_cache, svd_cache = build_candidate_cache(sampling_graph_data, int(graph_data["num_disease"]))

    train_neg, train_neg_stats = sample_tsrna_cold_negatives(
        splits["train_pairs"],
        int(graph_data["num_disease"]),
        splits["train_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        ontology_cache,
        svd_cache,
        args.seed + (fold_id + 1) * 10_000 + 101,
        args.negative_sampling,
        args.easy_negative_ratio,
        args.ontology_negative_ratio,
        args.svd_negative_ratio,
    )
    val_neg, val_neg_stats = sample_tsrna_cold_negatives(
        splits["val_pairs"],
        int(graph_data["num_disease"]),
        splits["val_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        ontology_cache,
        svd_cache,
        args.seed + (fold_id + 1) * 10_000 + 202,
        args.negative_sampling,
        args.easy_negative_ratio,
        args.ontology_negative_ratio,
        args.svd_negative_ratio,
    )
    test_neg, test_neg_stats = sample_tsrna_cold_negatives(
        splits["test_pairs"],
        int(graph_data["num_disease"]),
        splits["test_pairs"].shape[0],
        exclusion_set,
        sampling_graph_data,
        ontology_cache,
        svd_cache,
        args.seed + (fold_id + 1) * 10_000 + 303,
        args.negative_sampling,
        args.easy_negative_ratio,
        args.ontology_negative_ratio,
        args.svd_negative_ratio,
    )
    save_negative_sampling_stats(output_dir, {"train": train_neg_stats, "valid": val_neg_stats, "test": test_neg_stats})

    train_pairs, train_labels = make_labeled_pairs(splits["train_pairs"], train_neg)
    val_pairs, val_labels = make_labeled_pairs(splits["val_pairs"], val_neg)
    test_pairs, test_labels = make_labeled_pairs(splits["test_pairs"], test_neg)

    edge_feat_dim = graph_data["pos_edge_features"].shape[1]
    train_graph_data_cpu = build_train_graph_data(graph_data, splits["train_idx"], False)
    if args.use_svd_features:
        train_graph_data_cpu = add_fold_local_svd(output_dir, graph_data, train_graph_data_cpu, splits, args.svd_dim, args.svd_topk, edge_feat_dim)
    save_split_files(output_dir, splits, train_neg, val_neg, test_neg, train_graph_data_cpu)
    save_entity_files(output_dir, splits)
    train_graph_data = move_graph_data_to_device(train_graph_data_cpu, device)

    attr_counts = attribute_meta_counts(graph_data)
    model = EgoCLGNN(
        num_tsrna=int(graph_data["num_tsrna"]),
        num_disease=int(graph_data["num_disease"]),
        num_doid=int(graph_data["num_doid"]),
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        edge_feat_dim=edge_feat_dim,
        svd_dim=args.svd_dim,
        dropout=args.dropout,
        use_evidence_gate=args.use_evidence_gate,
        use_ontology=args.use_ontology,
        use_path_attention=args.use_path_attention,
        use_direction=args.use_direction,
        use_svd_features=args.use_svd_features,
        decoder_type=args.decoder_type,
        use_tsrna_attr=args.use_tsrna_attr,
        use_tsrna_seq=args.use_tsrna_seq,
        use_attr_contrastive=args.use_attr_contrastive,
        tsrna_attr_fusion=args.tsrna_attr_fusion,
        attr_kmer_dim=attr_counts["kmer_dim"],
        attr_num_types=attr_counts["num_tsrna_types"],
        attr_num_sources=attr_counts["num_source_tRNAs"],
        attr_num_anticodons=attr_counts["num_anticodons"],
        attr_num_aminos=attr_counts["num_amino_acid_families"],
        attr_num_species=attr_counts["num_species"],
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.BCEWithLogitsLoss()
    best_val_aupr = -1.0
    best_epoch = -1
    best_val_threshold = 0.5
    best_threshold_method = "unknown"
    epochs_without_improvement = 0
    train_log: list[dict[str, object]] = []
    best_model_path = output_dir / "best_model.pt"

    print(
        f"[run_cold_start] fold {fold_id}: train/val/test positives "
        f"{splits['train_pairs'].shape[0]}/{splits['val_pairs'].shape[0]}/{splits['test_pairs'].shape[0]}",
        flush=True,
    )
    print(
        f"[run_cold_start] fold {fold_id}: train/val/test cold tsRNAs "
        f"{splits['train_entities'].numel()}/{splits['val_entities'].numel()}/{splits['test_entities'].numel()}",
        flush=True,
    )

    for epoch in range(1, args.epochs + 1):
        train_losses = train_one_epoch_clgnn(
            model,
            train_pairs,
            train_labels,
            splits["train_pairs"],
            train_neg,
            train_graph_data,
            optimizer,
            device,
            args.use_contrastive,
            args.contrastive_weight,
            args.temperature,
            args.use_bpr,
            args.bpr_weight,
            0.0,
            1.0,
            args.use_focal_loss,
            args.focal_alpha,
            args.focal_gamma,
            args.use_soft_f1_loss,
            args.soft_f1_weight,
            0.0,
            args.use_attr_contrastive,
            args.attr_cl_weight,
        )
        val_metrics, val_scores, _, val_loss = evaluate_split(
            model,
            val_pairs,
            val_labels,
            train_graph_data,
            args.batch_size,
            device,
            criterion,
            threshold_search=args.threshold_search,
        )
        val_pos_mean, val_neg_mean = split_score_means(val_labels, val_scores)
        row = {
            "epoch": epoch,
            **train_losses,
            "val_loss": val_loss,
            "val_auc": val_metrics["AUC"],
            "val_aupr": val_metrics["AUPR"],
            "val_best_f1": val_metrics["best_f1"],
            "val_best_precision": val_metrics["best_precision"],
            "val_best_recall": val_metrics["best_recall"],
            "val_best_threshold": val_metrics["best_threshold"],
            "val_best_threshold_method": val_metrics["best_threshold_method"],
            "val_positive_score_mean": val_pos_mean,
            "val_negative_score_mean": val_neg_mean,
            "best_epoch": best_epoch,
        }
        if val_metrics["AUPR"] > best_val_aupr:
            best_val_aupr = val_metrics["AUPR"]
            best_epoch = epoch
            best_val_threshold = val_metrics["best_threshold"]
            best_threshold_method = val_metrics["best_threshold_method"]
            epochs_without_improvement = 0
            torch.save({"model_state_dict": model.state_dict(), "epoch": epoch, "val_aupr": best_val_aupr}, best_model_path)
        else:
            epochs_without_improvement += 1
        row["best_epoch"] = best_epoch
        train_log.append(row)
        print(
            f"[run_cold_start] fold {fold_id} epoch {epoch:03d} "
            f"loss={train_losses['train_loss']:.4f} val_auc={val_metrics['AUC']:.4f} "
            f"val_aupr={val_metrics['AUPR']:.4f} val_f1={val_metrics['best_f1']:.4f}",
            flush=True,
        )
        if epochs_without_improvement >= args.patience:
            print(f"[run_cold_start] fold {fold_id} early stopping at epoch {epoch}; best epoch {best_epoch}", flush=True)
            break

    checkpoint = torch.load(best_model_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    train_metrics, train_scores, train_logits, train_loss_eval = evaluate_split(
        model, train_pairs, train_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    val_metrics, val_scores, val_logits, val_loss_eval = evaluate_split(
        model, val_pairs, val_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    test_metrics, test_scores, test_logits, test_loss_eval = evaluate_split(
        model, test_pairs, test_labels, train_graph_data, args.batch_size, device, criterion, threshold_search=args.threshold_search
    )
    test_selected = selected_threshold_metrics(test_labels, test_scores, best_val_threshold)
    test_pos_mean, test_neg_mean = split_score_means(test_labels, test_scores)
    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_selected_threshold_precision": test_selected["selected_threshold_precision"],
        "test_selected_threshold_recall": test_selected["selected_threshold_recall"],
        "test_selected_threshold_f1": test_selected["selected_threshold_f1"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "val_selected_threshold": best_val_threshold,
        "best_epoch": best_epoch,
        "best_val_aupr": best_val_aupr,
        "train_loss": train_loss_eval,
        "val_loss": val_loss_eval,
        "test_loss": test_loss_eval,
        "test_positive_score_mean": test_pos_mean,
        "test_negative_score_mean": test_neg_mean,
        "cold_start_mode": args.cold_start_mode,
        "train_cold_entity_count": int(splits["train_entities"].numel()),
        "val_cold_entity_count": int(splits["val_entities"].numel()),
        "test_cold_entity_count": int(splits["test_entities"].numel()),
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(train_log, output_dir / "train_log.csv")
    save_predictions(
        output_dir,
        [
            ("train", train_pairs, train_labels, train_scores, train_logits),
            ("valid", val_pairs, val_labels, val_scores, val_logits),
            ("test", test_pairs, test_labels, test_scores, test_logits),
        ],
    )
    save_attr_gate_statistics(output_dir, fold_id, model, train_graph_data, graph_data, splits["train_pairs"], device)
    config = vars(args).copy()
    config.update(
        {
            "model_name": "EGOCL",
            "split_mode_resolved": "strict_tsrna_cold_start",
            "best_epoch": best_epoch,
            "best_val_aupr": best_val_aupr,
            "best_val_threshold": best_val_threshold,
            "best_val_threshold_method": best_threshold_method,
        }
    )
    with (output_dir / "config.json").open("w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
    print(
        f"[run_cold_start] fold {fold_id} test AUC={test_metrics['AUC']:.4f} "
        f"AUPR={test_metrics['AUPR']:.4f} F1={test_selected['selected_threshold_f1']:.4f}",
        flush=True,
    )


def main() -> None:
    args = parse_args()
    if args.quick_test:
        args.output_dir = "results/egocl_cold_start_quick_test"
        args.num_folds = min(args.num_folds, 2)
        args.epochs = min(args.epochs, 2)
        args.patience = min(args.patience, 2)
    output_dir = ensure_dir(args.output_dir)
    for fold_id in range(args.num_folds):
        run_fold(args, fold_id)
    save_cold_summary(output_dir)
    print(f"[run_cold_start] summary written to {output_dir}", flush=True)


if __name__ == "__main__":
    main()
