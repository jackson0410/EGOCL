from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.baselines.adapted_core import (
    append_predictions,
    copy_split_files,
    evaluate_at_threshold,
    evaluate_binary_classification,
    load_fold_data,
    make_labeled,
    pair_rows,
    prediction_rows,
    resolve_device,
    save_predictions,
)
from src.data_utils import build_exclusion_set, load_graph_tensors
from src.utils import ensure_dir, save_csv, set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run DMFCDA-adapted baseline.")
    parser.add_argument("--common_data_dir", default="results/domain_baselines/common_data")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--model_name", default=None)
    parser.add_argument("--negative_sampling", choices=["common", "degree_matched"], default="common")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--latent_dim", type=int, default=32)
    parser.add_argument("--projection_layers", type=int, default=3)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--dropout", type=float, default=0.005)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--weight_decay", type=float, default=0.001)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--quick_test", action="store_true")
    return parser.parse_args()


def degree_matched_negative_sampling(
    pos_pairs: torch.Tensor,
    train_matrix: np.ndarray,
    exclusion_set: set[tuple[int, int]],
    num_tsrna: int,
    num_disease: int,
    seed: int,
    used_pairs: set[tuple[int, int]] | None = None,
    allowed_tsrna_ids: torch.Tensor | np.ndarray | list[int] | None = None,
) -> torch.Tensor:
    rng = np.random.default_rng(seed)
    disease_degrees = np.asarray(train_matrix.sum(axis=0), dtype=np.float32)
    used = set() if used_pairs is None else set(used_pairs)
    sampled: list[tuple[int, int]] = []
    disease_ids = np.arange(num_disease)
    if allowed_tsrna_ids is None:
        tsrna_ids = np.arange(num_tsrna)
    else:
        tsrna_ids = np.asarray(allowed_tsrna_ids, dtype=np.int64)
        if tsrna_ids.size == 0:
            raise ValueError("allowed_tsrna_ids is empty; cannot sample cold-start negatives")

    for _, pos_disease_id in pos_pairs.tolist():
        target_degree = disease_degrees[int(pos_disease_id)]
        tie_noise = rng.random(num_disease) * 1e-6
        order = disease_ids[np.argsort(np.abs(disease_degrees - target_degree) + tie_noise)]
        chosen: tuple[int, int] | None = None
        for candidate_disease in order.tolist():
            shuffled_tsrna = tsrna_ids.copy()
            rng.shuffle(shuffled_tsrna)
            for candidate_tsrna in shuffled_tsrna.tolist():
                pair = (int(candidate_tsrna), int(candidate_disease))
                if pair in exclusion_set or pair in used:
                    continue
                chosen = pair
                break
            if chosen is not None:
                break
        if chosen is None:
            shuffled_disease = disease_ids.copy()
            rng.shuffle(shuffled_disease)
            shuffled_tsrna = tsrna_ids.copy()
            rng.shuffle(shuffled_tsrna)
            for candidate_disease in shuffled_disease.tolist():
                for candidate_tsrna in shuffled_tsrna.tolist():
                    pair = (int(candidate_tsrna), int(candidate_disease))
                    if pair not in exclusion_set and pair not in used:
                        chosen = pair
                        break
                if chosen is not None:
                    break
        if chosen is None:
            raise RuntimeError(f"Could not sample degree-matched negative for disease {pos_disease_id}")
        sampled.append(chosen)
        used.add(chosen)

    return torch.tensor(sampled, dtype=torch.long)


def maybe_replace_negatives(args: argparse.Namespace, fold_id: int, fold_data: dict[str, object]) -> dict[str, object]:
    if args.negative_sampling != "degree_matched":
        return fold_data

    graph_data = load_graph_tensors(args.data_dir)
    exclusion_set = build_exclusion_set(graph_data)
    num_tsrna = int(graph_data["num_tsrna"])
    num_disease = int(graph_data["num_disease"])
    train_matrix = fold_data["train_matrix"]
    used: set[tuple[int, int]] = set()
    train_neg = degree_matched_negative_sampling(
        fold_data["train_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000,
        used,
        fold_data.get("train_entities"),
    )
    used.update(map(tuple, train_neg.tolist()))
    val_neg = degree_matched_negative_sampling(
        fold_data["val_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000 + 1,
        used,
        fold_data.get("val_entities"),
    )
    used.update(map(tuple, val_neg.tolist()))
    test_neg = degree_matched_negative_sampling(
        fold_data["test_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000 + 2,
        used,
        fold_data.get("test_entities"),
    )
    updated = dict(fold_data)
    updated["train_neg"] = train_neg
    updated["val_neg"] = val_neg
    updated["test_neg"] = test_neg
    return updated


class ProjectionTower(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, latent_dim: int, num_layers: int, dropout: float):
        super().__init__()
        if num_layers < 1:
            raise ValueError(f"projection_layers must be >= 1, got {num_layers}")
        dims = [input_dim]
        if num_layers == 1:
            dims.append(latent_dim)
        else:
            dims.extend([hidden_dim] * (num_layers - 1))
            dims.append(latent_dim)

        layers: list[nn.Module] = []
        for in_dim, out_dim in zip(dims[:-1], dims[1:]):
            layers.extend([nn.Linear(in_dim, out_dim), nn.ReLU(), nn.Dropout(dropout)])
        self.net = nn.Sequential(*layers)

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.net(values)


class DMFCDAAdapted(nn.Module):
    def __init__(
        self,
        train_matrix: np.ndarray,
        hidden_dim: int,
        latent_dim: int,
        projection_layers: int,
        dropout: float,
    ):
        super().__init__()
        matrix = torch.tensor(train_matrix, dtype=torch.float32)
        self.register_buffer("train_matrix", matrix)
        num_tsrna, num_disease = matrix.shape
        self.tsrna_tower = ProjectionTower(num_disease, hidden_dim, latent_dim, projection_layers, dropout)
        self.disease_tower = ProjectionTower(num_tsrna, hidden_dim, latent_dim, projection_layers, dropout)
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def raw_profiles(self, pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        tsrna_ids = pairs[:, 0].long()
        disease_ids = pairs[:, 1].long()
        x_t = self.train_matrix[tsrna_ids].clone()
        x_d = self.train_matrix[:, disease_ids].T.clone()
        row_idx = torch.arange(pairs.shape[0], device=pairs.device)
        x_t[row_idx, disease_ids] = 0.0
        x_d[row_idx, tsrna_ids] = 0.0
        return x_t, x_d

    def forward(self, pairs: torch.Tensor) -> torch.Tensor:
        x_t, x_d = self.raw_profiles(pairs)
        h_t = self.tsrna_tower(x_t)
        h_d = self.disease_tower(x_d)
        return self.decoder(torch.cat([h_t, h_d], dim=1)).squeeze(1)


def evaluate_split(
    model: DMFCDAAdapted,
    pairs: torch.Tensor,
    labels: torch.Tensor,
    batch_size: int,
    device: torch.device,
    threshold_search: str,
) -> tuple[dict[str, float], np.ndarray, np.ndarray]:
    model.eval()
    logits = []
    with torch.no_grad():
        for start in range(0, pairs.shape[0], batch_size):
            batch = pairs[start : start + batch_size].to(device)
            logits.append(model(batch).detach().cpu())
    logit_arr = torch.cat(logits).numpy() if logits else np.asarray([], dtype=float)
    score_arr = 1.0 / (1.0 + np.exp(-logit_arr))
    metrics = evaluate_binary_classification(labels.numpy(), score_arr, threshold_search=threshold_search)
    return metrics, logit_arr, score_arr


def write_mask_audit(output_dir: Path, model: DMFCDAAdapted, split_pairs: dict[str, torch.Tensor], device: torch.device) -> None:
    rows = []
    model.eval()
    with torch.no_grad():
        for split_name, pairs in split_pairs.items():
            for start in range(0, pairs.shape[0], 1024):
                batch = pairs[start : start + 1024].to(device)
                tsrna_ids = batch[:, 0].long()
                disease_ids = batch[:, 1].long()
                before = model.train_matrix[tsrna_ids, disease_ids].detach().cpu().numpy()
                x_t, x_d = model.raw_profiles(batch)
                masked_t = x_t[torch.arange(batch.shape[0], device=device), disease_ids].detach().cpu().numpy()
                masked_d = x_d[torch.arange(batch.shape[0], device=device), tsrna_ids].detach().cpu().numpy()
                for pair, b, mt, md in zip(batch.detach().cpu().tolist(), before.tolist(), masked_t.tolist(), masked_d.tolist()):
                    rows.append(
                        {
                            "split": split_name,
                            "tsrna_id": int(pair[0]),
                            "disease_id": int(pair[1]),
                            "train_matrix_value_before_mask": float(b),
                            "masked_t_value": float(mt),
                            "masked_d_value": float(md),
                        }
                    )
    save_csv(
        rows,
        output_dir / "dmfcda_mask_audit.csv",
        ["split", "tsrna_id", "disease_id", "train_matrix_value_before_mask", "masked_t_value", "masked_d_value"],
    )


def write_degree_diagnostics(output_dir: Path, train_matrix: np.ndarray, split_pairs: dict[str, tuple[torch.Tensor, torch.Tensor]]) -> None:
    disease_degrees = np.asarray(train_matrix.sum(axis=0), dtype=np.float32)
    rows = []
    for split_name, (pos_pairs, neg_pairs) in split_pairs.items():
        pos_degrees = disease_degrees[pos_pairs[:, 1].numpy()] if pos_pairs.numel() else np.asarray([], dtype=np.float32)
        neg_degrees = disease_degrees[neg_pairs[:, 1].numpy()] if neg_pairs.numel() else np.asarray([], dtype=np.float32)
        rows.append(
            {
                "split": split_name,
                "positive_disease_degree_mean": float(pos_degrees.mean()) if pos_degrees.size else 0.0,
                "negative_disease_degree_mean": float(neg_degrees.mean()) if neg_degrees.size else 0.0,
                "positive_disease_degree_std": float(pos_degrees.std()) if pos_degrees.size else 0.0,
                "negative_disease_degree_std": float(neg_degrees.std()) if neg_degrees.size else 0.0,
                "mean_abs_gap": float(abs(pos_degrees.mean() - neg_degrees.mean())) if pos_degrees.size and neg_degrees.size else 0.0,
            }
        )
    save_csv(rows, output_dir / "degree_matching_diagnostics.csv")


def train_one_fold(args: argparse.Namespace, fold_id: int) -> None:
    fold_data = load_fold_data(Path(args.common_data_dir), fold_id, args.hidden_dim, "none")
    fold_data = maybe_replace_negatives(args, fold_id, fold_data)
    model_name = args.model_name or ("DMFCDA-adapted-degree-matched" if args.negative_sampling == "degree_matched" else "DMFCDA-adapted")
    output_dir = ensure_dir(Path(args.output_dir) / model_name / f"fold_{fold_id}")
    device = resolve_device(args.device)

    train_pos = fold_data["train_pos"]
    val_pos = fold_data["val_pos"]
    test_pos = fold_data["test_pos"]
    train_neg = fold_data["train_neg"]
    val_neg = fold_data["val_neg"]
    test_neg = fold_data["test_neg"]
    train_pairs, train_labels = make_labeled(train_pos, train_neg)
    val_pairs, val_labels = make_labeled(val_pos, val_neg)
    test_pairs, test_labels = make_labeled(test_pos, test_neg)

    model = DMFCDAAdapted(
        fold_data["train_matrix"],
        args.hidden_dim,
        args.latent_dim,
        args.projection_layers,
        args.dropout,
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.BCEWithLogitsLoss()
    best_val_aupr = -1.0
    best_epoch = 0
    best_threshold = 0.5
    best_state = None
    epochs_without_improvement = 0
    train_log = []
    generator = torch.Generator().manual_seed(args.seed + fold_id)

    for epoch in range(1, args.epochs + 1):
        model.train()
        perm = torch.randperm(train_pairs.shape[0], generator=generator)
        total_loss = 0.0
        for start in range(0, train_pairs.shape[0], args.batch_size):
            idx = perm[start : start + args.batch_size]
            batch_pairs = train_pairs[idx].to(device)
            batch_labels = train_labels[idx].to(device)
            optimizer.zero_grad()
            logits = model(batch_pairs)
            loss = criterion(logits, batch_labels)
            loss.backward()
            optimizer.step()
            total_loss += float(loss.item()) * batch_pairs.shape[0]
        train_loss = total_loss / max(1, train_pairs.shape[0])

        val_metrics, _, _ = evaluate_split(model, val_pairs, val_labels, args.batch_size, device, args.threshold_search)
        row = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_auc": val_metrics["AUC"],
            "val_aupr": val_metrics["AUPR"],
            "val_best_f1": val_metrics["best_f1"],
            "val_best_threshold": val_metrics["best_threshold"],
            "val_best_threshold_method": val_metrics["best_threshold_method"],
        }
        train_log.append(row)
        print(
            f"[{model_name}] fold={fold_id} epoch={epoch:03d} loss={train_loss:.4f} "
            f"val_auc={val_metrics['AUC']:.4f} val_aupr={val_metrics['AUPR']:.4f} val_f1={val_metrics['best_f1']:.4f}",
            flush=True,
        )
        if val_metrics["AUPR"] > best_val_aupr + 1e-12:
            best_val_aupr = float(val_metrics["AUPR"])
            best_epoch = epoch
            best_threshold = float(val_metrics["best_threshold"])
            best_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.patience:
                break

    if best_state is None:
        raise RuntimeError(f"No best state captured for DMFCDA-adapted fold {fold_id}")
    model.load_state_dict(best_state)
    torch.save({"model_state_dict": best_state, "model_name": model_name, "best_epoch": best_epoch}, output_dir / "best_model.pt")

    train_metrics, train_logits, train_scores = evaluate_split(model, train_pairs, train_labels, args.batch_size, device, args.threshold_search)
    val_metrics, val_logits, val_scores = evaluate_split(model, val_pairs, val_labels, args.batch_size, device, args.threshold_search)
    test_metrics, test_logits, test_scores = evaluate_split(model, test_pairs, test_labels, args.batch_size, device, args.threshold_search)
    test_selected = evaluate_at_threshold(test_labels.numpy(), test_scores, best_threshold, "selected")

    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_selected_threshold_f1": test_selected["selected_f1"],
        "test_selected_threshold_precision": test_selected["selected_precision"],
        "test_selected_threshold_recall": test_selected["selected_recall"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "val_selected_threshold": best_threshold,
        "best_val_aupr": best_val_aupr,
        "best_epoch": best_epoch,
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(train_log, output_dir / "train_log.csv")
    save_predictions(output_dir / "predictions.csv", train_pairs, train_labels, train_logits, train_scores, "train")
    append_predictions(output_dir / "predictions.csv", val_pairs, val_labels, val_logits, val_scores, "val")
    append_predictions(output_dir / "predictions.csv", test_pairs, test_labels, test_logits, test_scores, "test")
    copy_split_files(output_dir, fold_data)
    np.save(output_dir / "train_matrix.npy", fold_data["train_matrix"])
    save_csv([], output_dir / "message_graph_edges.csv", ["tsrna_id", "disease_id", "split", "label"])
    write_mask_audit(
        output_dir,
        model,
        {"train": train_pairs, "val": val_pairs, "test": test_pairs},
        device,
    )
    write_degree_diagnostics(
        output_dir,
        fold_data["train_matrix"],
        {"train": (train_pos, train_neg), "val": (val_pos, val_neg), "test": (test_pos, test_neg)},
    )
    (output_dir / "config.json").write_text(
        json.dumps(
            {
                "model_name": model_name,
                "description": "Deep matrix factorization style baseline with pair-masked train-only interaction profiles.",
                "fold_id": fold_id,
                "candidate_pair_masked": True,
                "negative_sampling": args.negative_sampling,
                **vars(args),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    if args.quick_test:
        args.num_folds = min(args.num_folds, 2)
        args.epochs = min(args.epochs, 2)
    for fold_id in range(args.num_folds):
        train_one_fold(args, fold_id)
    model_name = args.model_name or ("DMFCDA-adapted-degree-matched" if args.negative_sampling == "degree_matched" else "DMFCDA-adapted")
    summarize_cv(Path(args.output_dir) / model_name)


if __name__ == "__main__":
    main()
