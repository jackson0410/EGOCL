from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict, deque
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data_utils import build_exclusion_set, build_positive_pairs, load_graph_tensors, random_negative_sampling, split_edges_kfold
from src.utils import ensure_dir, load_csv, save_csv


PAIR_FIELDS = ["tsrna_id", "disease_id", "split", "label"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build train-only common fold data for adapted domain baselines.")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--processed_dir", default="data/processed")
    parser.add_argument("--split_source_dir", default="results/final_tuning/focal_alpha_0.85_gamma_1.5")
    parser.add_argument("--output_dir", default="results/domain_baselines/common_data")
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--negative_sampling", choices=["source", "random", "degree_matched"], default="source")
    parser.add_argument("--quick_test", action="store_true")
    return parser.parse_args()


def read_pairs(path: Path, split_name: str | None = None, label: int | None = None) -> torch.Tensor:
    rows = load_csv(path)
    pairs = [(int(row["tsrna_id"]), int(row["disease_id"])) for row in rows]
    return torch.tensor(pairs, dtype=torch.long) if pairs else torch.empty((0, 2), dtype=torch.long)


def pair_rows(pairs: torch.Tensor, split_name: str, label: int) -> list[dict[str, object]]:
    return [
        {"tsrna_id": int(tsrna_id), "disease_id": int(disease_id), "split": split_name, "label": label}
        for tsrna_id, disease_id in pairs.tolist()
    ]


def build_train_matrix(num_tsrna: int, num_disease: int, train_pos: torch.Tensor) -> np.ndarray:
    matrix = np.zeros((num_tsrna, num_disease), dtype=np.float32)
    if train_pos.numel() > 0:
        matrix[train_pos[:, 0].numpy(), train_pos[:, 1].numpy()] = 1.0
    return matrix


def degree_matched_negative_sampling(
    pos_pairs: torch.Tensor,
    train_matrix: np.ndarray,
    exclusion_set: set[tuple[int, int]],
    num_tsrna: int,
    num_disease: int,
    seed: int,
    used_pairs: set[tuple[int, int]] | None = None,
    allowed_tsrna_ids: torch.Tensor | None = None,
) -> torch.Tensor:
    rng = np.random.default_rng(seed)
    disease_degrees = np.asarray(train_matrix.sum(axis=0), dtype=np.float32)
    disease_ids = np.arange(num_disease)
    if allowed_tsrna_ids is None:
        tsrna_ids = np.arange(num_tsrna)
    else:
        tsrna_ids = np.asarray(sorted({int(x) for x in allowed_tsrna_ids.tolist()}), dtype=int)
        if tsrna_ids.size == 0:
            raise ValueError("allowed_tsrna_ids is empty")
    used = set() if used_pairs is None else set(used_pairs)
    sampled: list[tuple[int, int]] = []

    for _, pos_disease_id in pos_pairs.tolist():
        target_degree = disease_degrees[int(pos_disease_id)]
        tie_noise = rng.random(num_disease) * 1e-6
        ordered_diseases = disease_ids[np.argsort(np.abs(disease_degrees - target_degree) + tie_noise)]
        chosen: tuple[int, int] | None = None
        for candidate_disease in ordered_diseases.tolist():
            shuffled_tsrna = tsrna_ids.copy()
            rng.shuffle(shuffled_tsrna)
            for candidate_tsrna in shuffled_tsrna.tolist():
                pair = (int(candidate_tsrna), int(candidate_disease))
                if pair in exclusion_set or pair in used:
                    continue
                chosen = pair
                break
            if chosen is not None:
                break
        if chosen is None:
            raise RuntimeError(f"Could not sample degree-matched negative for disease {pos_disease_id}")
        sampled.append(chosen)
        used.add(chosen)
    return torch.tensor(sampled, dtype=torch.long)


def build_heterogeneous_adjacency(tsrna_similarity: np.ndarray, train_matrix: np.ndarray, disease_similarity: np.ndarray) -> np.ndarray:
    top = np.concatenate([tsrna_similarity, train_matrix], axis=1)
    bottom = np.concatenate([train_matrix.T, disease_similarity], axis=1)
    return np.concatenate([top, bottom], axis=0).astype(np.float32)


def gip_similarity(matrix: np.ndarray, axis_name: str) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.sum(matrix * matrix, axis=1)
    mean_norm = float(np.mean(norms[norms > 0])) if np.any(norms > 0) else 1.0
    gamma = 1.0 / max(mean_norm, 1e-8)
    gram = matrix @ matrix.T
    dist2 = norms[:, None] + norms[None, :] - 2.0 * gram
    sim = np.exp(-gamma * np.maximum(dist2, 0.0)).astype(np.float32)
    np.fill_diagonal(sim, 1.0)
    print(f"[common_adapter] {axis_name} GIP similarity shape: {sim.shape}", flush=True)
    return sim


def doid_ancestors(edges: list[dict[str, str]]) -> dict[str, set[str]]:
    parents: dict[str, set[str]] = defaultdict(set)
    nodes: set[str] = set()
    for row in edges:
        child = row.get("child_doid_id", "")
        parent = row.get("parent_doid_id", "")
        if child and parent:
            parents[child].add(parent)
            nodes.add(child)
            nodes.add(parent)

    ancestors: dict[str, set[str]] = {}
    for node in nodes:
        seen = {node}
        queue = deque([node])
        while queue:
            current = queue.popleft()
            for parent in parents.get(current, set()):
                if parent not in seen:
                    seen.add(parent)
                    queue.append(parent)
        ancestors[node] = seen
    return ancestors


def disease_semantic_similarity(processed_dir: Path, num_disease: int, disease_gip: np.ndarray) -> tuple[np.ndarray, dict[str, object]]:
    map_path = processed_dir / "disease_doid_map.csv"
    edge_path = processed_dir / "doid_edges.csv"
    semantic = np.eye(num_disease, dtype=np.float32)
    if not map_path.exists() or not edge_path.exists():
        return disease_gip.copy(), {"semantic_source": "disease_gip_fallback", "mapped_disease_count": 0}

    disease_to_doid = {int(row["disease_id"]): row["doid_id"] for row in load_csv(map_path)}
    ancestors = doid_ancestors(load_csv(edge_path))
    mapped = sorted(disease_to_doid)
    missing_count = num_disease - len(mapped)

    for i in range(num_disease):
        doid_i = disease_to_doid.get(i)
        set_i = ancestors.get(doid_i, {doid_i} if doid_i else set())
        for j in range(i, num_disease):
            doid_j = disease_to_doid.get(j)
            set_j = ancestors.get(doid_j, {doid_j} if doid_j else set())
            if not set_i or not set_j:
                value = float(disease_gip[i, j])
            else:
                union = set_i | set_j
                value = float(len(set_i & set_j) / len(union)) if union else 0.0
            semantic[i, j] = value
            semantic[j, i] = value
    np.fill_diagonal(semantic, 1.0)
    return semantic.astype(np.float32), {
        "semantic_source": "doid_ancestor_jaccard_with_gip_fallback",
        "mapped_disease_count": len(mapped),
        "unmapped_disease_count": missing_count,
    }


def generate_negatives(
    args: argparse.Namespace,
    fold_id: int,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    exclusion_set: set[tuple[int, int]],
    train_pos: torch.Tensor,
    val_pos: torch.Tensor,
    test_pos: torch.Tensor,
    train_entities: torch.Tensor | None = None,
    val_entities: torch.Tensor | None = None,
    test_entities: torch.Tensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    num_tsrna = int(graph_data["num_tsrna"])
    num_disease = int(graph_data["num_disease"])
    if args.negative_sampling == "degree_matched":
        train_matrix = build_train_matrix(num_tsrna, num_disease, train_pos)
        used: set[tuple[int, int]] = set()
        train_neg = degree_matched_negative_sampling(
            train_pos,
            train_matrix,
            exclusion_set,
            num_tsrna,
            num_disease,
            args.seed + fold_id * 1000,
            used,
            allowed_tsrna_ids=train_entities,
        )
        used.update(map(tuple, train_neg.tolist()))
        val_neg = degree_matched_negative_sampling(
            val_pos,
            train_matrix,
            exclusion_set,
            num_tsrna,
            num_disease,
            args.seed + fold_id * 1000 + 1,
            used,
            allowed_tsrna_ids=val_entities,
        )
        used.update(map(tuple, val_neg.tolist()))
        test_neg = degree_matched_negative_sampling(
            test_pos,
            train_matrix,
            exclusion_set,
            num_tsrna,
            num_disease,
            args.seed + fold_id * 1000 + 2,
            used,
            allowed_tsrna_ids=test_entities,
        )
        return train_neg, val_neg, test_neg

    train_neg = random_negative_sampling(num_tsrna, num_disease, train_pos.shape[0], exclusion_set, args.seed + fold_id * 1000)
    val_neg = random_negative_sampling(
        num_tsrna,
        num_disease,
        val_pos.shape[0],
        exclusion_set | set(map(tuple, train_neg.tolist())),
        args.seed + fold_id * 1000 + 1,
    )
    test_neg = random_negative_sampling(
        num_tsrna,
        num_disease,
        test_pos.shape[0],
        exclusion_set | set(map(tuple, train_neg.tolist())) | set(map(tuple, val_neg.tolist())),
        args.seed + fold_id * 1000 + 2,
    )
    return train_neg, val_neg, test_neg


def read_entity_ids(path: Path) -> torch.Tensor | None:
    if not path.exists():
        return None
    rows = load_csv(path)
    values = [int(row["tsrna_id"]) for row in rows]
    return torch.tensor(values, dtype=torch.long) if values else torch.empty((0,), dtype=torch.long)


def load_or_create_split(
    fold_id: int,
    args: argparse.Namespace,
    graph_data: dict[str, torch.Tensor | int | list[str]],
    exclusion_set: set[tuple[int, int]],
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, str]:
    source_fold = Path(args.split_source_dir) / f"fold_{fold_id}"
    required = [
        "train_pos_pairs.csv",
        "val_pos_pairs.csv",
        "test_pos_pairs.csv",
        "train_neg_pairs.csv",
        "val_neg_pairs.csv",
        "test_neg_pairs.csv",
    ]
    if all((source_fold / name).exists() for name in required):
        train_pos = read_pairs(source_fold / "train_pos_pairs.csv")
        val_pos = read_pairs(source_fold / "val_pos_pairs.csv")
        test_pos = read_pairs(source_fold / "test_pos_pairs.csv")
        train_entities = read_entity_ids(source_fold / "train_cold_tsrna_ids.csv")
        val_entities = read_entity_ids(source_fold / "val_cold_tsrna_ids.csv")
        test_entities = read_entity_ids(source_fold / "test_cold_tsrna_ids.csv")
        if args.negative_sampling == "source":
            train_neg = read_pairs(source_fold / "train_neg_pairs.csv")
            val_neg = read_pairs(source_fold / "val_neg_pairs.csv")
            test_neg = read_pairs(source_fold / "test_neg_pairs.csv")
        else:
            train_neg, val_neg, test_neg = generate_negatives(
                args,
                fold_id,
                graph_data,
                exclusion_set,
                train_pos,
                val_pos,
                test_pos,
                train_entities=train_entities,
                val_entities=val_entities,
                test_entities=test_entities,
            )
        return (train_pos, val_pos, test_pos, train_neg, val_neg, test_neg, str(source_fold))

    pos_pairs = build_positive_pairs(graph_data)
    split = split_edges_kfold(pos_pairs, args.seed, fold_id, args.num_folds)
    train_pos = split["train_pairs"]
    val_pos = split["val_pairs"]
    test_pos = split["test_pairs"]
    train_neg, val_neg, test_neg = generate_negatives(args, fold_id, graph_data, exclusion_set, train_pos, val_pos, test_pos)
    return train_pos, val_pos, test_pos, train_neg, val_neg, test_neg, "generated_by_common_adapter"


def write_fold(args: argparse.Namespace, fold_id: int, graph_data: dict[str, torch.Tensor | int | list[str]], exclusion_set: set[tuple[int, int]]) -> None:
    fold_dir = ensure_dir(Path(args.output_dir) / f"fold_{fold_id}")
    num_tsrna = int(graph_data["num_tsrna"])
    num_disease = int(graph_data["num_disease"])
    train_pos, val_pos, test_pos, train_neg, val_neg, test_neg, split_source = load_or_create_split(fold_id, args, graph_data, exclusion_set)

    train_matrix = build_train_matrix(num_tsrna, num_disease, train_pos)
    tsrna_gip = gip_similarity(train_matrix, "tsRNA")
    disease_gip = gip_similarity(train_matrix.T, "disease")
    semantic, semantic_meta = disease_semantic_similarity(Path(args.processed_dir), num_disease, disease_gip)
    disease_similarity = ((disease_gip + semantic) / 2.0).astype(np.float32)
    heterogeneous_adjacency = build_heterogeneous_adjacency(tsrna_gip, train_matrix, disease_similarity)

    np.save(fold_dir / "train_matrix.npy", train_matrix)
    pd.DataFrame(train_matrix).to_csv(fold_dir / "train_matrix.csv", index=False)
    np.save(fold_dir / "association_matrix_train_only.npy", train_matrix)
    np.save(fold_dir / "tsrna_gip_similarity.npy", tsrna_gip)
    np.save(fold_dir / "disease_gip_similarity.npy", disease_gip)
    np.save(fold_dir / "disease_semantic_similarity.npy", semantic)
    np.save(fold_dir / "tsrna_similarity.npy", tsrna_gip)
    np.save(fold_dir / "disease_similarity.npy", disease_similarity)
    np.save(fold_dir / "heterogeneous_adjacency.npy", heterogeneous_adjacency)

    save_csv(pair_rows(train_pos, "train", 1), fold_dir / "train_pos_pairs.csv", PAIR_FIELDS)
    save_csv(pair_rows(val_pos, "val", 1), fold_dir / "val_pos_pairs.csv", PAIR_FIELDS)
    save_csv(pair_rows(test_pos, "test", 1), fold_dir / "test_pos_pairs.csv", PAIR_FIELDS)
    save_csv(pair_rows(train_neg, "train", 0), fold_dir / "train_neg_pairs.csv", PAIR_FIELDS)
    save_csv(pair_rows(val_neg, "val", 0), fold_dir / "val_neg_pairs.csv", PAIR_FIELDS)
    save_csv(pair_rows(test_neg, "test", 0), fold_dir / "test_neg_pairs.csv", PAIR_FIELDS)

    source_fold = Path(split_source)
    for split_name in ["train", "val", "test"]:
        entity_path = source_fold / f"{split_name}_cold_tsrna_ids.csv"
        entity_ids = read_entity_ids(entity_path)
        if entity_ids is not None:
            save_csv(
                [{"tsrna_id": int(tsrna_id)} for tsrna_id in entity_ids.tolist()],
                fold_dir / f"{split_name}_cold_tsrna_ids.csv",
                ["tsrna_id"],
            )

    manifest = {
        "fold_id": fold_id,
        "split_source": split_source,
        "num_tsrna": num_tsrna,
        "num_disease": num_disease,
        "train_positive_count": int(train_pos.shape[0]),
        "val_positive_count": int(val_pos.shape[0]),
        "test_positive_count": int(test_pos.shape[0]),
        "train_negative_count": int(train_neg.shape[0]),
        "val_negative_count": int(val_neg.shape[0]),
        "test_negative_count": int(test_neg.shape[0]),
        "negative_sampling": args.negative_sampling,
        "tsrna_similarity_note": "because tsRNA sequence/function similarity is unavailable, train-only GIP similarity was used as the tsRNA similarity input.",
        **semantic_meta,
    }
    (fold_dir / "common_data_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"[common_adapter] wrote fold {fold_id}: {fold_dir}", flush=True)


def main() -> None:
    args = parse_args()
    if args.quick_test:
        args.num_folds = min(args.num_folds, 2)
    ensure_dir(args.output_dir)
    graph_data = load_graph_tensors(args.data_dir)
    exclusion_set = build_exclusion_set(graph_data)
    for fold_id in range(args.num_folds):
        write_fold(args, fold_id, graph_data, exclusion_set)


if __name__ == "__main__":
    main()
