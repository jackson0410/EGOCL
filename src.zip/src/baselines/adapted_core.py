from __future__ import annotations

import argparse
import json
import math
import random
import shutil
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.data_utils import build_exclusion_set, load_graph_tensors
from src.metrics import evaluate_at_threshold, evaluate_binary_classification
from src.utils import ensure_dir, load_csv, save_csv, set_seed


MODEL_CONFIGS = {
    "AGCLNDA-adapted": {
        "encoder": "lightgcn",
        "decoder": "inner",
        "use_contrastive": True,
        "use_bpr": True,
        "feature_mode": "none",
        "description": "LightGCN, adaptive edge-drop views, denoising edge weighting, contrastive learning, and inner-product prediction.",
    },
    "MSMCDA-adapted": {
        "encoder": "attention",
        "decoder": "mlp",
        "use_contrastive": True,
        "use_bpr": False,
        "feature_mode": "svd_similarity",
        "description": "Similarity/meta-path views, shared transformations, multichannel attention, contrastive alignment, and MLP prediction.",
    },
    "HybridGNN-adapted": {
        "encoder": "hybrid_gcn_gat",
        "decoder": "mlp",
        "use_contrastive": False,
        "use_bpr": False,
        "feature_mode": "svd_matrix",
        "description": "Train-only matrix-decomposition features with GCN/GAT-style association propagation and fully connected prediction.",
    },
    "HybridGNN-adapted-degree-matched": {
        "encoder": "hybrid_gcn_gat",
        "decoder": "mlp",
        "use_contrastive": False,
        "use_bpr": False,
        "feature_mode": "svd_matrix",
        "description": "HybridGNN-adapted with disease-degree-matched negative sampling to reduce disease popularity bias.",
    },
    "DualVGAE-adapted": {
        "encoder": "dual_vgae",
        "decoder": "inner",
        "use_contrastive": False,
        "use_bpr": True,
        "feature_mode": "rwr_svd",
        "description": "Train-only RWR/SVD features, two collaborative subnetworks, VGAE-style latent encoders, and score fusion.",
    },
}


def parse_base_args(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--common_data_dir", default="results/domain_baselines/common_data")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--latent_dim", type=int, default=32)
    parser.add_argument("--pca_dim", type=int, default=32)
    parser.add_argument("--gat_heads", type=int, default=4)
    parser.add_argument("--lambda_reg", type=float, default=0.0121)
    parser.add_argument("--projection_layers", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--quick_test", action="store_true")
    return parser


def resolve_device(device_arg: str) -> torch.device:
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_arg)


def load_pairs(path: Path) -> torch.Tensor:
    rows = load_csv(path)
    pairs = [(int(row["tsrna_id"]), int(row["disease_id"])) for row in rows]
    return torch.tensor(pairs, dtype=torch.long) if pairs else torch.empty((0, 2), dtype=torch.long)


def load_entity_ids(path: Path) -> torch.Tensor | None:
    if not path.exists():
        return None
    rows = load_csv(path)
    ids = []
    for row in rows:
        if "tsrna_id" in row:
            ids.append(int(row["tsrna_id"]))
        elif "id" in row:
            ids.append(int(row["id"]))
    return torch.tensor(ids, dtype=torch.long) if ids else torch.empty((0,), dtype=torch.long)


def make_labeled(pos_pairs: torch.Tensor, neg_pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    pairs = torch.cat([pos_pairs.long(), neg_pairs.long()], dim=0)
    labels = torch.cat([torch.ones(pos_pairs.shape[0]), torch.zeros(neg_pairs.shape[0])], dim=0).float()
    return pairs, labels


def scipy_like_svd_features(matrix: np.ndarray, dim: int) -> tuple[np.ndarray, np.ndarray]:
    u, s, vt = np.linalg.svd(matrix.astype(np.float32), full_matrices=False)
    dim = min(dim, s.shape[0])
    sqrt_s = np.sqrt(s[:dim] + 1e-8)
    left = u[:, :dim] * sqrt_s[None, :]
    right = vt[:dim, :].T * sqrt_s[None, :]
    return left.astype(np.float32), right.astype(np.float32)


def rwr(sim: np.ndarray, restart_prob: float = 0.5, steps: int = 20) -> np.ndarray:
    sim = np.asarray(sim, dtype=np.float32)
    row_sum = sim.sum(axis=1, keepdims=True)
    transition = sim / np.maximum(row_sum, 1e-8)
    identity = np.eye(sim.shape[0], dtype=np.float32)
    state = identity.copy()
    for _ in range(steps):
        state = (1.0 - restart_prob) * transition @ state + restart_prob * identity
    return state.astype(np.float32)


def top_svd_square_features(matrix: np.ndarray, dim: int) -> np.ndarray:
    u, s, _ = np.linalg.svd(matrix.astype(np.float32), full_matrices=False)
    dim = min(dim, s.shape[0])
    return (u[:, :dim] * np.sqrt(s[:dim] + 1e-8)[None, :]).astype(np.float32)


def load_fold_data(common_data_dir: Path, fold_id: int, hidden_dim: int, feature_mode: str) -> dict[str, object]:
    fold_dir = common_data_dir / f"fold_{fold_id}"
    if not fold_dir.exists():
        raise FileNotFoundError(f"Missing common fold data: {fold_dir}")
    train_matrix = np.load(fold_dir / "train_matrix.npy")
    train_pos = load_pairs(fold_dir / "train_pos_pairs.csv")
    val_pos = load_pairs(fold_dir / "val_pos_pairs.csv")
    test_pos = load_pairs(fold_dir / "test_pos_pairs.csv")
    train_neg = load_pairs(fold_dir / "train_neg_pairs.csv")
    val_neg = load_pairs(fold_dir / "val_neg_pairs.csv")
    test_neg = load_pairs(fold_dir / "test_neg_pairs.csv")
    train_entities = load_entity_ids(fold_dir / "train_cold_tsrna_ids.csv")
    val_entities = load_entity_ids(fold_dir / "val_cold_tsrna_ids.csv")
    test_entities = load_entity_ids(fold_dir / "test_cold_tsrna_ids.csv")

    tsrna_features = None
    disease_features = None
    if feature_mode in {"svd_similarity", "svd_matrix"}:
        tsrna_features, disease_features = scipy_like_svd_features(train_matrix, hidden_dim)
    elif feature_mode == "rwr_svd":
        # The tsRNA similarity matrix is 4759 x 4759 in the current dataset; full
        # RWR followed by dense SVD on that matrix is unnecessarily expensive for
        # this adapted baseline. Use train-matrix SVD for the tsRNA side and RWR
        # on the much smaller disease similarity matrix.
        tsrna_features, disease_features = scipy_like_svd_features(train_matrix, hidden_dim)
        disease_rwr = rwr(np.load(fold_dir / "disease_similarity.npy"))
        disease_rwr_features = top_svd_square_features(disease_rwr, hidden_dim)
        common_dim = min(disease_features.shape[1], disease_rwr_features.shape[1])
        disease_features[:, :common_dim] = (disease_features[:, :common_dim] + disease_rwr_features[:, :common_dim]) / 2.0

    return {
        "fold_dir": fold_dir,
        "train_matrix": train_matrix,
        "num_tsrna": train_matrix.shape[0],
        "num_disease": train_matrix.shape[1],
        "train_pos": train_pos,
        "val_pos": val_pos,
        "test_pos": test_pos,
        "train_neg": train_neg,
        "val_neg": val_neg,
        "test_neg": test_neg,
        "train_entities": train_entities,
        "val_entities": val_entities,
        "test_entities": test_entities,
        "tsrna_features": tsrna_features,
        "disease_features": disease_features,
    }


def degree_matched_negative_sampling(
    pos_pairs: torch.Tensor,
    train_matrix: np.ndarray,
    exclusion_set: set[tuple[int, int]],
    num_tsrna: int,
    num_disease: int,
    seed: int,
    used_pairs: set[tuple[int, int]] | None = None,
    allowed_tsrna_ids: torch.Tensor | np.ndarray | list[int] | None = None,
) -> torch.Tensor:
    rng = np.random.default_rng(seed)
    disease_degrees = np.asarray(train_matrix.sum(axis=0), dtype=np.float32)
    disease_ids = np.arange(num_disease)
    if allowed_tsrna_ids is None:
        tsrna_ids = np.arange(num_tsrna)
    else:
        tsrna_ids = np.asarray(allowed_tsrna_ids, dtype=np.int64)
        if tsrna_ids.size == 0:
            raise ValueError("allowed_tsrna_ids is empty; cannot sample cold-start negatives")
    used = set() if used_pairs is None else set(used_pairs)
    sampled: list[tuple[int, int]] = []

    for _, pos_disease_id in pos_pairs.tolist():
        target_degree = disease_degrees[int(pos_disease_id)]
        tie_noise = rng.random(num_disease) * 1e-6
        ordered_diseases = disease_ids[np.argsort(np.abs(disease_degrees - target_degree) + tie_noise)]
        chosen: tuple[int, int] | None = None
        for candidate_disease in ordered_diseases.tolist():
            shuffled_tsrna = tsrna_ids.copy()
            rng.shuffle(shuffled_tsrna)
            for candidate_tsrna in shuffled_tsrna.tolist():
                pair = (int(candidate_tsrna), int(candidate_disease))
                if pair in exclusion_set or pair in used:
                    continue
                chosen = pair
                break
            if chosen is not None:
                break
        if chosen is None:
            raise RuntimeError(f"Could not sample degree-matched negative for disease {pos_disease_id}")
        sampled.append(chosen)
        used.add(chosen)
    return torch.tensor(sampled, dtype=torch.long)


def maybe_replace_with_degree_matched_negatives(model_name: str, args: argparse.Namespace, fold_id: int, fold_data: dict[str, object]) -> dict[str, object]:
    if model_name != "HybridGNN-adapted-degree-matched":
        return fold_data
    graph_data = load_graph_tensors(args.data_dir)
    exclusion_set = build_exclusion_set(graph_data)
    num_tsrna = int(graph_data["num_tsrna"])
    num_disease = int(graph_data["num_disease"])
    train_matrix = fold_data["train_matrix"]
    used: set[tuple[int, int]] = set()
    train_neg = degree_matched_negative_sampling(
        fold_data["train_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000,
        used,
        fold_data.get("train_entities"),
    )
    used.update(map(tuple, train_neg.tolist()))
    val_neg = degree_matched_negative_sampling(
        fold_data["val_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000 + 1,
        used,
        fold_data.get("val_entities"),
    )
    used.update(map(tuple, val_neg.tolist()))
    test_neg = degree_matched_negative_sampling(
        fold_data["test_pos"],
        train_matrix,
        exclusion_set,
        num_tsrna,
        num_disease,
        args.seed + fold_id * 1000 + 2,
        used,
        fold_data.get("test_entities"),
    )
    updated = dict(fold_data)
    updated["train_neg"] = train_neg
    updated["val_neg"] = val_neg
    updated["test_neg"] = test_neg
    return updated


class AdaptedBaselineModel(nn.Module):
    def __init__(
        self,
        num_tsrna: int,
        num_disease: int,
        hidden_dim: int,
        dropout: float,
        config: dict[str, object],
        tsrna_features: np.ndarray | None = None,
        disease_features: np.ndarray | None = None,
    ):
        super().__init__()
        self.num_tsrna = num_tsrna
        self.num_disease = num_disease
        self.hidden_dim = hidden_dim
        self.encoder = str(config["encoder"])
        self.decoder = str(config["decoder"])
        self.dropout = nn.Dropout(dropout)
        self.tsrna_emb = nn.Embedding(num_tsrna, hidden_dim)
        self.disease_emb = nn.Embedding(num_disease, hidden_dim)
        nn.init.xavier_uniform_(self.tsrna_emb.weight)
        nn.init.xavier_uniform_(self.disease_emb.weight)

        self.has_features = tsrna_features is not None and disease_features is not None
        if self.has_features:
            self.register_buffer("tsrna_features", torch.tensor(tsrna_features, dtype=torch.float32))
            self.register_buffer("disease_features", torch.tensor(disease_features, dtype=torch.float32))
            self.tsrna_feature_proj = nn.Linear(tsrna_features.shape[1], hidden_dim)
            self.disease_feature_proj = nn.Linear(disease_features.shape[1], hidden_dim)

        self.gat_score = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, 1))
        self.channel_attention = nn.Sequential(nn.Linear(hidden_dim, hidden_dim), nn.Tanh(), nn.Linear(hidden_dim, 1))
        self.denoise_gate = nn.Sequential(nn.Linear(hidden_dim * 2, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, 1), nn.Sigmoid())
        self.mu_proj = nn.Linear(hidden_dim, hidden_dim)
        self.logstd_proj = nn.Linear(hidden_dim, hidden_dim)
        self.decoder_mlp = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )
        self.norm_t = nn.LayerNorm(hidden_dim)
        self.norm_d = nn.LayerNorm(hidden_dim)

    def initial_embeddings(self) -> tuple[torch.Tensor, torch.Tensor]:
        t = self.tsrna_emb.weight
        d = self.disease_emb.weight
        if self.has_features:
            t = t + self.tsrna_feature_proj(self.tsrna_features)
            d = d + self.disease_feature_proj(self.disease_features)
        return self.norm_t(t), self.norm_d(d)

    def gcn_propagate(self, t: torch.Tensor, d: torch.Tensor, edge_t: torch.Tensor, edge_d: torch.Tensor, weights: torch.Tensor | None = None) -> tuple[torch.Tensor, torch.Tensor]:
        if weights is None:
            weights = torch.ones(edge_t.shape[0], device=t.device)
        msg_d = t[edge_t] * weights[:, None]
        msg_t = d[edge_d] * weights[:, None]
        agg_d = torch.zeros_like(d).index_add(0, edge_d, msg_d)
        agg_t = torch.zeros_like(t).index_add(0, edge_t, msg_t)
        deg_d = torch.zeros(d.shape[0], device=d.device).index_add(0, edge_d, weights).clamp_min(1.0)
        deg_t = torch.zeros(t.shape[0], device=t.device).index_add(0, edge_t, weights).clamp_min(1.0)
        return agg_t / deg_t[:, None], agg_d / deg_d[:, None]

    def gat_propagate(self, t: torch.Tensor, d: torch.Tensor, edge_t: torch.Tensor, edge_d: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        score = torch.sigmoid(self.gat_score(torch.cat([t[edge_t], d[edge_d]], dim=1))).squeeze(1)
        return self.gcn_propagate(t, d, edge_t, edge_d, score)

    def encode(self, edge_t: torch.Tensor, edge_d: torch.Tensor, edge_keep_prob: float = 1.0) -> tuple[torch.Tensor, torch.Tensor]:
        if self.training and edge_keep_prob < 1.0:
            keep = torch.rand(edge_t.shape[0], device=edge_t.device) < edge_keep_prob
            edge_t = edge_t[keep]
            edge_d = edge_d[keep]
        t0, d0 = self.initial_embeddings()
        if edge_t.numel() == 0:
            return t0, d0

        if self.encoder == "lightgcn":
            gate = self.denoise_gate(torch.cat([t0[edge_t], d0[edge_d]], dim=1)).squeeze(1)
            t1, d1 = self.gcn_propagate(t0, d0, edge_t, edge_d, gate)
            return (t0 + t1) / 2.0, (d0 + d1) / 2.0

        if self.encoder == "hybrid_gcn_gat":
            tg, dg = self.gcn_propagate(t0, d0, edge_t, edge_d)
            ta, da = self.gat_propagate(t0, d0, edge_t, edge_d)
            return self.norm_t(t0 + self.dropout((tg + ta) / 2.0)), self.norm_d(d0 + self.dropout((dg + da) / 2.0))

        if self.encoder == "attention":
            tg, dg = self.gcn_propagate(t0, d0, edge_t, edge_d)
            ta, da = self.gat_propagate(t0, d0, edge_t, edge_d)
            t_stack = torch.stack([t0, tg, ta], dim=1)
            d_stack = torch.stack([d0, dg, da], dim=1)
            t_w = torch.softmax(self.channel_attention(t_stack).squeeze(-1), dim=1)
            d_w = torch.softmax(self.channel_attention(d_stack).squeeze(-1), dim=1)
            return (t_stack * t_w[:, :, None]).sum(dim=1), (d_stack * d_w[:, :, None]).sum(dim=1)

        if self.encoder == "dual_vgae":
            tg, dg = self.gcn_propagate(t0, d0, edge_t, edge_d)
            t_mu = self.mu_proj(t0 + tg)
            d_mu = self.mu_proj(d0 + dg)
            if self.training:
                t_std = torch.exp(torch.clamp(self.logstd_proj(t0 + tg), -5.0, 2.0))
                d_std = torch.exp(torch.clamp(self.logstd_proj(d0 + dg), -5.0, 2.0))
                t_mu = t_mu + torch.randn_like(t_mu) * t_std * 0.05
                d_mu = d_mu + torch.randn_like(d_mu) * d_std * 0.05
            return t_mu, d_mu

        raise ValueError(f"Unknown encoder: {self.encoder}")

    def score_pairs_from_embeddings(self, pairs: torch.Tensor, t: torch.Tensor, d: torch.Tensor) -> torch.Tensor:
        ht = t[pairs[:, 0]]
        hd = d[pairs[:, 1]]
        if self.decoder == "inner":
            return (ht * hd).sum(dim=1)
        z = torch.cat([ht, hd, ht * hd, torch.abs(ht - hd)], dim=1)
        return self.decoder_mlp(z).squeeze(1)

    def forward(self, pairs: torch.Tensor, edge_t: torch.Tensor, edge_d: torch.Tensor) -> torch.Tensor:
        t, d = self.encode(edge_t, edge_d)
        return self.score_pairs_from_embeddings(pairs, t, d)

    def contrastive_loss(self, batch_pairs: torch.Tensor, edge_t: torch.Tensor, edge_d: torch.Tensor, temperature: float = 0.2) -> torch.Tensor:
        t1, d1 = self.encode(edge_t, edge_d, edge_keep_prob=0.85)
        t2, d2 = self.encode(edge_t, edge_d, edge_keep_prob=0.85)
        node_t = torch.unique(batch_pairs[:, 0])
        node_d = torch.unique(batch_pairs[:, 1])
        if node_t.numel() > 1024:
            node_t = node_t[torch.randperm(node_t.numel(), device=node_t.device)[:1024]]
        if node_d.numel() > 512:
            node_d = node_d[torch.randperm(node_d.numel(), device=node_d.device)[:512]]
        losses = []
        if node_t.numel() > 1:
            losses.append(info_nce(t1[node_t], t2[node_t], temperature))
        if node_d.numel() > 1:
            losses.append(info_nce(d1[node_d], d2[node_d], temperature))
        return torch.stack(losses).mean() if losses else torch.tensor(0.0, device=edge_t.device)


def info_nce(x1: torch.Tensor, x2: torch.Tensor, temperature: float) -> torch.Tensor:
    x1 = F.normalize(x1, dim=1)
    x2 = F.normalize(x2, dim=1)
    logits = x1 @ x2.T / temperature
    labels = torch.arange(x1.shape[0], device=x1.device)
    return F.cross_entropy(logits, labels)


def bpr_loss(pos_logits: torch.Tensor, neg_logits: torch.Tensor) -> torch.Tensor:
    count = min(pos_logits.shape[0], neg_logits.shape[0])
    if count == 0:
        return torch.tensor(0.0, device=pos_logits.device)
    return -F.logsigmoid(pos_logits[:count] - neg_logits[:count]).mean()


def evaluate_split(
    model: AdaptedBaselineModel,
    pairs: torch.Tensor,
    labels: torch.Tensor,
    edge_t: torch.Tensor,
    edge_d: torch.Tensor,
    batch_size: int,
    device: torch.device,
    threshold_search: str,
) -> tuple[dict[str, float], np.ndarray, np.ndarray]:
    model.eval()
    logits = []
    with torch.no_grad():
        for start in range(0, pairs.shape[0], batch_size):
            batch = pairs[start : start + batch_size].to(device)
            logits.append(model(batch, edge_t, edge_d).detach().cpu())
    logit_arr = torch.cat(logits).numpy() if logits else np.asarray([], dtype=float)
    score_arr = 1.0 / (1.0 + np.exp(-logit_arr))
    metrics = evaluate_binary_classification(labels.numpy(), score_arr, threshold_search=threshold_search)
    return metrics, logit_arr, score_arr


def train_one_fold(model_name: str, args: argparse.Namespace, fold_id: int) -> None:
    config = MODEL_CONFIGS[model_name]
    fold_data = load_fold_data(Path(args.common_data_dir), fold_id, args.hidden_dim, str(config["feature_mode"]))
    fold_data = maybe_replace_with_degree_matched_negatives(model_name, args, fold_id, fold_data)
    output_dir = ensure_dir(Path(args.output_dir) / model_name / f"fold_{fold_id}")
    device = resolve_device(args.device)

    train_pos = fold_data["train_pos"]
    val_pos = fold_data["val_pos"]
    test_pos = fold_data["test_pos"]
    train_neg = fold_data["train_neg"]
    val_neg = fold_data["val_neg"]
    test_neg = fold_data["test_neg"]
    train_pairs, train_labels = make_labeled(train_pos, train_neg)
    val_pairs, val_labels = make_labeled(val_pos, val_neg)
    test_pairs, test_labels = make_labeled(test_pos, test_neg)

    edge_t = train_pos[:, 0].long().to(device)
    edge_d = train_pos[:, 1].long().to(device)
    model = AdaptedBaselineModel(
        int(fold_data["num_tsrna"]),
        int(fold_data["num_disease"]),
        args.hidden_dim,
        args.dropout,
        config,
        fold_data["tsrna_features"],
        fold_data["disease_features"],
    ).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.BCEWithLogitsLoss()
    best_val_aupr = -1.0
    best_epoch = 0
    best_threshold = 0.5
    best_state = None
    epochs_without_improvement = 0
    train_log = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        batch_pairs = train_pairs.to(device)
        batch_labels = train_labels.to(device)
        optimizer.zero_grad()
        logits = model(batch_pairs, edge_t, edge_d)
        loss = criterion(logits, batch_labels)
        if config["use_contrastive"]:
            loss = loss + 0.1 * model.contrastive_loss(batch_pairs, edge_t, edge_d)
        if config["use_bpr"]:
            pos_logits = logits[batch_labels == 1]
            neg_logits = logits[batch_labels == 0]
            loss = loss + 0.05 * bpr_loss(pos_logits, neg_logits)
        loss.backward()
        optimizer.step()

        train_loss = float(loss.item())
        val_metrics, _, _ = evaluate_split(model, val_pairs, val_labels, edge_t, edge_d, args.batch_size, device, args.threshold_search)
        row = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_auc": val_metrics["AUC"],
            "val_aupr": val_metrics["AUPR"],
            "val_best_f1": val_metrics["best_f1"],
            "val_best_threshold": val_metrics["best_threshold"],
            "val_best_threshold_method": val_metrics["best_threshold_method"],
        }
        train_log.append(row)
        print(
            f"[{model_name}] fold={fold_id} epoch={epoch:03d} loss={train_loss:.4f} "
            f"val_auc={val_metrics['AUC']:.4f} val_aupr={val_metrics['AUPR']:.4f} val_f1={val_metrics['best_f1']:.4f}",
            flush=True,
        )
        if val_metrics["AUPR"] > best_val_aupr + 1e-12:
            best_val_aupr = float(val_metrics["AUPR"])
            best_epoch = epoch
            best_threshold = float(val_metrics["best_threshold"])
            best_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= args.patience:
                break

    if best_state is None:
        raise RuntimeError(f"No best state captured for {model_name} fold {fold_id}")
    model.load_state_dict(best_state)
    torch.save({"model_state_dict": best_state, "model_name": model_name, "best_epoch": best_epoch}, output_dir / "best_model.pt")

    train_metrics, train_logits, train_scores = evaluate_split(model, train_pairs, train_labels, edge_t, edge_d, args.batch_size, device, args.threshold_search)
    val_metrics, val_logits, val_scores = evaluate_split(model, val_pairs, val_labels, edge_t, edge_d, args.batch_size, device, args.threshold_search)
    test_metrics, test_logits, test_scores = evaluate_split(model, test_pairs, test_labels, edge_t, edge_d, args.batch_size, device, args.threshold_search)
    test_selected = evaluate_at_threshold(test_labels.numpy(), test_scores, best_threshold, "selected")

    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_fixed_accuracy": test_metrics["fixed_accuracy"],
        "test_fixed_precision": test_metrics["fixed_precision"],
        "test_fixed_recall": test_metrics["fixed_recall"],
        "test_fixed_f1": test_metrics["fixed_f1"],
        "val_selected_threshold": best_threshold,
        "test_selected_threshold_accuracy": test_selected["selected_accuracy"],
        "test_selected_threshold_precision": test_selected["selected_precision"],
        "test_selected_threshold_recall": test_selected["selected_recall"],
        "test_selected_threshold_f1": test_selected["selected_f1"],
        "test_oracle_best_threshold": test_metrics["best_threshold"],
        "test_oracle_best_accuracy": test_metrics["best_accuracy"],
        "test_oracle_best_precision": test_metrics["best_precision"],
        "test_oracle_best_recall": test_metrics["best_recall"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "test_best_threshold": test_metrics["best_threshold"],
        "test_best_threshold_method": test_metrics["best_threshold_method"],
        "best_epoch": best_epoch,
        "best_val_aupr": best_val_aupr,
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(train_log, output_dir / "train_log.csv")
    save_predictions(output_dir / "predictions.csv", train_pairs, train_labels, train_logits, train_scores, "train")
    append_predictions(output_dir / "predictions.csv", val_pairs, val_labels, val_logits, val_scores, "val")
    append_predictions(output_dir / "predictions.csv", test_pairs, test_labels, test_logits, test_scores, "test")
    copy_split_files(output_dir, fold_data)
    if model_name.startswith("HybridGNN-adapted"):
        copy_common_artifacts(
            output_dir,
            fold_data,
            [
                "train_matrix.npy",
                "tsrna_similarity.npy",
                "disease_similarity.npy",
                "tsrna_gip_similarity.npy",
                "disease_gip_similarity.npy",
                "disease_semantic_similarity.npy",
                "heterogeneous_adjacency.npy",
            ],
        )
        if model_name == "HybridGNN-adapted-degree-matched":
            write_degree_diagnostics(
                output_dir,
                fold_data["train_matrix"],
                {"train": (train_pos, train_neg), "val": (val_pos, val_neg), "test": (test_pos, test_neg)},
            )
    save_csv(pair_rows(train_pos, "train", 1), output_dir / "message_graph_edges.csv", ["tsrna_id", "disease_id", "split", "label"])
    (output_dir / "config.json").write_text(
        json.dumps({"model_name": model_name, "description": config["description"], "fold_id": fold_id, **vars(args)}, indent=2),
        encoding="utf-8",
    )


def pair_rows(pairs: torch.Tensor, split_name: str, label: int) -> list[dict[str, object]]:
    return [{"tsrna_id": int(t), "disease_id": int(d), "split": split_name, "label": label} for t, d in pairs.tolist()]


def prediction_rows(pairs: torch.Tensor, labels: torch.Tensor, logits: np.ndarray, scores: np.ndarray, split_name: str) -> list[dict[str, object]]:
    return [
        {
            "tsrna_id": int(pair[0]),
            "disease_id": int(pair[1]),
            "label": int(label),
            "logit": float(logit),
            "score": float(score),
            "split": split_name,
        }
        for pair, label, logit, score in zip(pairs.tolist(), labels.tolist(), logits.tolist(), scores.tolist())
    ]


def save_predictions(path: Path, pairs: torch.Tensor, labels: torch.Tensor, logits: np.ndarray, scores: np.ndarray, split_name: str) -> None:
    save_csv(prediction_rows(pairs, labels, logits, scores, split_name), path, ["tsrna_id", "disease_id", "label", "logit", "score", "split"])


def append_predictions(path: Path, pairs: torch.Tensor, labels: torch.Tensor, logits: np.ndarray, scores: np.ndarray, split_name: str) -> None:
    existing = load_csv(path)
    rows = existing + prediction_rows(pairs, labels, logits, scores, split_name)
    save_csv(rows, path, ["tsrna_id", "disease_id", "label", "logit", "score", "split"])


def copy_split_files(output_dir: Path, fold_data: dict[str, object]) -> None:
    save_csv(pair_rows(fold_data["train_pos"], "train", 1), output_dir / "train_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["val_pos"], "val", 1), output_dir / "val_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["test_pos"], "test", 1), output_dir / "test_pos_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["train_neg"], "train", 0), output_dir / "train_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["val_neg"], "val", 0), output_dir / "val_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["test_neg"], "test", 0), output_dir / "test_neg_pairs.csv", ["tsrna_id", "disease_id", "split", "label"])
    for split_name, key in (("train", "train_entities"), ("val", "val_entities"), ("test", "test_entities")):
        ids = fold_data.get(key)
        if ids is None:
            continue
        rows = [{"tsrna_id": int(tsrna_id), "split": split_name} for tsrna_id in torch.as_tensor(ids).tolist()]
        save_csv(rows, output_dir / f"{split_name}_cold_tsrna_ids.csv", ["tsrna_id", "split"])


def copy_common_artifacts(output_dir: Path, fold_data: dict[str, object], names: list[str]) -> None:
    source_dir = Path(fold_data["fold_dir"])
    for name in names:
        source = source_dir / name
        if not source.exists():
            raise FileNotFoundError(f"Missing common artifact required by baseline: {source}")
        shutil.copyfile(source, output_dir / name)


def write_degree_diagnostics(output_dir: Path, train_matrix: np.ndarray, split_pairs: dict[str, tuple[torch.Tensor, torch.Tensor]]) -> None:
    disease_degrees = np.asarray(train_matrix.sum(axis=0), dtype=np.float32)
    rows = []
    for split_name, (pos_pairs, neg_pairs) in split_pairs.items():
        pos_degrees = disease_degrees[pos_pairs[:, 1].numpy()] if pos_pairs.numel() else np.asarray([], dtype=np.float32)
        neg_degrees = disease_degrees[neg_pairs[:, 1].numpy()] if neg_pairs.numel() else np.asarray([], dtype=np.float32)
        rows.append(
            {
                "split": split_name,
                "positive_disease_degree_mean": float(pos_degrees.mean()) if pos_degrees.size else 0.0,
                "negative_disease_degree_mean": float(neg_degrees.mean()) if neg_degrees.size else 0.0,
                "positive_disease_degree_std": float(pos_degrees.std()) if pos_degrees.size else 0.0,
                "negative_disease_degree_std": float(neg_degrees.std()) if neg_degrees.size else 0.0,
                "mean_abs_gap": float(abs(pos_degrees.mean() - neg_degrees.mean())) if pos_degrees.size and neg_degrees.size else 0.0,
            }
        )
    save_csv(rows, output_dir / "degree_matching_diagnostics.csv")


def run_model_cv(model_name: str, args: argparse.Namespace) -> None:
    set_seed(args.seed)
    ensure_dir(Path(args.output_dir) / model_name)
    if args.quick_test:
        args.num_folds = min(args.num_folds, 2)
        args.epochs = min(args.epochs, 2)
    for fold_id in range(args.num_folds):
        train_one_fold(model_name, args, fold_id)
    summarize_cv(Path(args.output_dir) / model_name)


def main_for_model(model_name: str, description: str) -> None:
    parser = parse_base_args(description)
    args = parser.parse_args()
    run_model_cv(model_name, args)
