from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.baselines.adapted_core import main_for_model


if __name__ == "__main__":
    main_for_model("DualVGAE-adapted", "Run DualVGAE-adapted baseline.")
