from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.summarize_cv import summarize_cv
from src.baselines.adapted_core import load_pairs, pair_rows, prediction_rows
from src.metrics import evaluate_at_threshold, evaluate_binary_classification
from src.utils import ensure_dir, save_csv, set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run iCircDA-MF-adapted baseline.")
    parser.add_argument("--common_data_dir", default="results/domain_baselines/common_data")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--num_folds", type=int, default=5)
    parser.add_argument("--neighbor_k", type=int, default=2)
    parser.add_argument("--mf_rank", type=int, default=70)
    parser.add_argument("--alpha", type=float, default=2e-3)
    parser.add_argument("--beta", type=float, default=1e-3)
    parser.add_argument("--max_iter", type=int, default=300)
    parser.add_argument("--tol", type=float, default=1e-5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--threshold_search", choices=["linear", "log", "quantile", "all"], default="all")
    parser.add_argument("--quick_test", action="store_true")
    # Accepted for compatibility with the shared domain-baseline runner.
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--latent_dim", type=int, default=32)
    parser.add_argument("--pca_dim", type=int, default=32)
    parser.add_argument("--gat_heads", type=int, default=4)
    parser.add_argument("--lambda_reg", type=float, default=0.0121)
    parser.add_argument("--projection_layers", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=0.001)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--weight_decay", type=float, default=1e-5)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--device", default="cpu")
    return parser.parse_args()


def load_fold(common_data_dir: Path, fold_id: int) -> dict[str, object]:
    fold_dir = common_data_dir / f"fold_{fold_id}"
    if not fold_dir.exists():
        raise FileNotFoundError(f"Missing common fold data: {fold_dir}")
    return {
        "fold_dir": fold_dir,
        "train_matrix": np.load(fold_dir / "train_matrix.npy").astype(np.float32),
        "tsrna_similarity": np.load(fold_dir / "tsrna_similarity.npy").astype(np.float32),
        "disease_similarity": np.load(fold_dir / "disease_similarity.npy").astype(np.float32),
        "disease_gip_similarity": np.load(fold_dir / "disease_gip_similarity.npy").astype(np.float32),
        "disease_semantic_similarity": np.load(fold_dir / "disease_semantic_similarity.npy").astype(np.float32),
        "train_pos": load_pairs(fold_dir / "train_pos_pairs.csv"),
        "val_pos": load_pairs(fold_dir / "val_pos_pairs.csv"),
        "test_pos": load_pairs(fold_dir / "test_pos_pairs.csv"),
        "train_neg": load_pairs(fold_dir / "train_neg_pairs.csv"),
        "val_neg": load_pairs(fold_dir / "val_neg_pairs.csv"),
        "test_neg": load_pairs(fold_dir / "test_neg_pairs.csv"),
    }


def topk_indices_weights(similarity: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray]:
    n = similarity.shape[0]
    k = max(1, min(k, max(1, n - 1)))
    indices = np.zeros((n, k), dtype=np.int64)
    weights = np.zeros((n, k), dtype=np.float32)
    for i in range(n):
        row = similarity[i]
        candidate_count = min(k + 1, n)
        candidates = np.argpartition(-row, candidate_count - 1)[:candidate_count]
        candidates = candidates[candidates != i]
        if candidates.size < k:
            extra = np.argsort(-row)
            candidates = np.asarray([idx for idx in extra if idx != i], dtype=np.int64)
        selected = candidates[np.argsort(-row[candidates])[:k]]
        indices[i, : selected.size] = selected
        weights[i, : selected.size] = row[selected]
    return indices, weights


def weighted_neighbor_profiles(matrix: np.ndarray, similarity: np.ndarray, axis: str, k: int) -> np.ndarray:
    indices, weights = topk_indices_weights(similarity, k)
    denom = np.maximum(weights.sum(axis=1), 1e-8)
    if axis == "rows":
        return ((weights[:, :, None] * matrix[indices]).sum(axis=1) / denom[:, None]).astype(np.float32)
    if axis == "columns":
        out = np.zeros_like(matrix, dtype=np.float32)
        for j in range(matrix.shape[1]):
            out[:, j] = (matrix[:, indices[j]] * weights[j][None, :]).sum(axis=1) / denom[j]
        return out
    raise ValueError(f"Unknown axis: {axis}")


def reformulate_matrix(train_matrix: np.ndarray, tsrna_similarity: np.ndarray, disease_similarity: np.ndarray, neighbor_k: int) -> np.ndarray:
    a_t = weighted_neighbor_profiles(train_matrix, tsrna_similarity, "rows", neighbor_k)
    a_d = weighted_neighbor_profiles(train_matrix, disease_similarity, "columns", neighbor_k)
    return np.maximum(train_matrix, (a_t + a_d) / 2.0).astype(np.float32)


def sparse_similarity_product(values: np.ndarray, indices: np.ndarray, weights: np.ndarray) -> np.ndarray:
    return (weights[:, :, None] * values[indices]).sum(axis=1).astype(np.float32)


def graph_regularized_nmf(
    matrix: np.ndarray,
    tsrna_similarity: np.ndarray,
    disease_similarity: np.ndarray,
    rank: int,
    alpha: float,
    beta: float,
    max_iter: int,
    tol: float,
    graph_k: int,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, list[dict[str, float]]]:
    rng = np.random.default_rng(seed)
    n_tsrna, n_disease = matrix.shape
    rank = min(rank, min(n_tsrna, n_disease))
    c = rng.random((n_tsrna, rank), dtype=np.float32) + 1e-4
    d = rng.random((n_disease, rank), dtype=np.float32) + 1e-4
    t_idx, t_w = topk_indices_weights(tsrna_similarity, graph_k)
    d_idx, d_w = topk_indices_weights(disease_similarity, graph_k)
    t_deg = np.maximum(t_w.sum(axis=1), 1e-8).astype(np.float32)
    d_deg = np.maximum(d_w.sum(axis=1), 1e-8).astype(np.float32)
    eps = 1e-8
    log_rows: list[dict[str, float]] = []
    prev_loss: float | None = None

    for iteration in range(1, max_iter + 1):
        dt_d = d.T @ d
        numerator_c = matrix @ d + beta * sparse_similarity_product(c, t_idx, t_w)
        denominator_c = (1.0 + alpha) * (c @ dt_d) + beta * t_deg[:, None] * c + eps
        c *= numerator_c / denominator_c
        c = np.maximum(c, eps)

        ct_c = c.T @ c
        numerator_d = matrix.T @ c + beta * sparse_similarity_product(d, d_idx, d_w)
        denominator_d = (1.0 + alpha) * (d @ ct_c) + beta * d_deg[:, None] * d + eps
        d *= numerator_d / denominator_d
        d = np.maximum(d, eps)

        if iteration == 1 or iteration % 10 == 0 or iteration == max_iter:
            reconstruction = c @ d.T
            recon_loss = float(np.mean((matrix - reconstruction) ** 2))
            log_rows.append({"iteration": iteration, "reconstruction_mse": recon_loss})
            if prev_loss is not None and abs(prev_loss - recon_loss) < tol:
                break
            prev_loss = recon_loss

    return c.astype(np.float32), d.astype(np.float32), log_rows


def minmax_scores(score_matrix: np.ndarray) -> np.ndarray:
    score_matrix = np.asarray(score_matrix, dtype=np.float32)
    min_value = float(np.min(score_matrix))
    max_value = float(np.max(score_matrix))
    if max_value - min_value < 1e-12:
        return np.zeros_like(score_matrix, dtype=np.float32)
    return ((score_matrix - min_value) / (max_value - min_value)).astype(np.float32)


def make_labeled(pos_pairs: torch.Tensor, neg_pairs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    pairs = torch.cat([pos_pairs.long(), neg_pairs.long()], dim=0)
    labels = torch.cat([torch.ones(pos_pairs.shape[0]), torch.zeros(neg_pairs.shape[0])], dim=0).long()
    return pairs, labels


def scores_for_pairs(score_matrix: np.ndarray, pairs: torch.Tensor) -> np.ndarray:
    if pairs.numel() == 0:
        return np.asarray([], dtype=np.float32)
    rows = pairs[:, 0].numpy()
    cols = pairs[:, 1].numpy()
    return score_matrix[rows, cols].astype(np.float32)


def logits_from_scores(scores: np.ndarray) -> np.ndarray:
    clipped = np.clip(scores.astype(float), 1e-6, 1.0 - 1e-6)
    return np.log(clipped / (1.0 - clipped))


def save_predictions(path: Path, pairs: torch.Tensor, labels: torch.Tensor, scores: np.ndarray, split_name: str, append: bool = False) -> None:
    rows = prediction_rows(pairs, labels.float(), logits_from_scores(scores), scores, split_name)
    if append and path.exists():
        from src.utils import load_csv

        rows = load_csv(path) + rows
    save_csv(rows, path, ["tsrna_id", "disease_id", "label", "logit", "score", "split"])


def train_one_fold(args: argparse.Namespace, fold_id: int) -> None:
    fold_data = load_fold(Path(args.common_data_dir), fold_id)
    output_dir = ensure_dir(Path(args.output_dir) / "iCircDA-MF-adapted" / f"fold_{fold_id}")
    train_matrix = fold_data["train_matrix"]
    tsrna_similarity = fold_data["tsrna_similarity"]
    disease_similarity = fold_data["disease_similarity"]
    reformulated = reformulate_matrix(train_matrix, tsrna_similarity, disease_similarity, args.neighbor_k)
    c, d, train_log = graph_regularized_nmf(
        reformulated,
        tsrna_similarity,
        disease_similarity,
        args.mf_rank,
        args.alpha,
        args.beta,
        args.max_iter,
        args.tol,
        max(args.neighbor_k, 2),
        args.seed + fold_id,
    )
    score_matrix = minmax_scores(c @ d.T)

    train_pairs, train_labels = make_labeled(fold_data["train_pos"], fold_data["train_neg"])
    val_pairs, val_labels = make_labeled(fold_data["val_pos"], fold_data["val_neg"])
    test_pairs, test_labels = make_labeled(fold_data["test_pos"], fold_data["test_neg"])
    train_scores = scores_for_pairs(score_matrix, train_pairs)
    val_scores = scores_for_pairs(score_matrix, val_pairs)
    test_scores = scores_for_pairs(score_matrix, test_pairs)
    val_metrics = evaluate_binary_classification(val_labels.numpy(), val_scores, threshold_search=args.threshold_search)
    test_metrics = evaluate_binary_classification(test_labels.numpy(), test_scores, threshold_search=args.threshold_search)
    test_selected = evaluate_at_threshold(test_labels.numpy(), test_scores, float(val_metrics["best_threshold"]), "selected")

    metrics_row = {
        "test_auc": test_metrics["AUC"],
        "test_aupr": test_metrics["AUPR"],
        "test_selected_threshold_accuracy": test_selected["selected_accuracy"],
        "test_selected_threshold_precision": test_selected["selected_precision"],
        "test_selected_threshold_recall": test_selected["selected_recall"],
        "test_selected_threshold_f1": test_selected["selected_f1"],
        "test_oracle_best_f1": test_metrics["best_f1"],
        "test_best_precision": test_metrics["best_precision"],
        "test_best_recall": test_metrics["best_recall"],
        "test_best_f1": test_metrics["best_f1"],
        "test_best_threshold": test_metrics["best_threshold"],
        "test_best_threshold_method": test_metrics["best_threshold_method"],
        "val_selected_threshold": val_metrics["best_threshold"],
        "best_val_aupr": val_metrics["AUPR"],
        "best_epoch": len(train_log),
    }
    save_csv([metrics_row], output_dir / "metrics.csv")
    save_csv(train_log, output_dir / "train_log.csv")
    save_predictions(output_dir / "predictions.csv", train_pairs, train_labels, train_scores, "train")
    save_predictions(output_dir / "predictions.csv", val_pairs, val_labels, val_scores, "val", append=True)
    save_predictions(output_dir / "predictions.csv", test_pairs, test_labels, test_scores, "test", append=True)

    for split_name, label, pairs in [
        ("train", 1, fold_data["train_pos"]),
        ("val", 1, fold_data["val_pos"]),
        ("test", 1, fold_data["test_pos"]),
        ("train", 0, fold_data["train_neg"]),
        ("val", 0, fold_data["val_neg"]),
        ("test", 0, fold_data["test_neg"]),
    ]:
        filename = f"{split_name}_{'pos' if label == 1 else 'neg'}_pairs.csv"
        save_csv(pair_rows(pairs, split_name, label), output_dir / filename, ["tsrna_id", "disease_id", "split", "label"])
    save_csv(pair_rows(fold_data["train_pos"], "train", 1), output_dir / "message_graph_edges.csv", ["tsrna_id", "disease_id", "split", "label"])

    np.save(output_dir / "train_matrix.npy", train_matrix)
    np.save(output_dir / "tsrna_similarity.npy", tsrna_similarity)
    np.save(output_dir / "disease_similarity.npy", disease_similarity)
    np.save(output_dir / "disease_gip_similarity.npy", fold_data["disease_gip_similarity"])
    np.save(output_dir / "disease_semantic_similarity.npy", fold_data["disease_semantic_similarity"])
    np.save(output_dir / "reformulated_matrix.npy", reformulated)
    np.save(output_dir / "score_matrix.npy", score_matrix)
    (output_dir / "config.json").write_text(
        json.dumps(
            {
                "model_name": "iCircDA-MF-adapted",
                "description": "Train-only GIP/DOID similarity, neighbour profile reformulation, and graph-regularized non-negative matrix factorization.",
                "fold_id": fold_id,
                **vars(args),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(
        f"[iCircDA-MF-adapted] fold={fold_id} test_auc={test_metrics['AUC']:.4f} "
        f"test_aupr={test_metrics['AUPR']:.4f} test_f1={test_selected['selected_f1']:.4f}",
        flush=True,
    )


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    if args.quick_test:
        args.num_folds = min(args.num_folds, 2)
        args.max_iter = min(args.max_iter, 30)
    for fold_id in range(args.num_folds):
        train_one_fold(args, fold_id)
    summarize_cv(Path(args.output_dir) / "iCircDA-MF-adapted")


if __name__ == "__main__":
    main()
