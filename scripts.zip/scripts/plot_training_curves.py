from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot single-run training curves.")
    parser.add_argument("--run_dir", default="results/single_run")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir)
    log_path = run_dir / "train_log.csv"
    if not log_path.exists():
        raise FileNotFoundError(f"Missing train log: {log_path}")

    log_df = pd.read_csv(log_path)
    required = {"epoch", "train_loss", "val_loss", "val_auc", "val_aupr"}
    missing = required - set(log_df.columns)
    if missing:
        raise ValueError(f"train_log.csv is missing required columns: {sorted(missing)}")

    fig, axes = plt.subplots(3, 1, figsize=(8, 12), constrained_layout=True)

    axes[0].plot(log_df["epoch"], log_df["train_loss"], label="train_loss", linewidth=2)
    axes[0].plot(log_df["epoch"], log_df["val_loss"], label="val_loss", linewidth=2)
    axes[0].set_title("Loss")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("BCE loss")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(log_df["epoch"], log_df["val_auc"], label="val_auc", color="tab:green", linewidth=2)
    axes[1].set_title("Validation AUC")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("AUC")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(log_df["epoch"], log_df["val_aupr"], label="val_aupr", color="tab:orange", linewidth=2)
    axes[2].set_title("Validation AUPR")
    axes[2].set_xlabel("Epoch")
    axes[2].set_ylabel("AUPR")
    axes[2].legend()
    axes[2].grid(True, alpha=0.3)

    output_path = run_dir / "training_curves.png"
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    print(f"[plot_training_curves] output written to: {output_path}")


if __name__ == "__main__":
    main()
