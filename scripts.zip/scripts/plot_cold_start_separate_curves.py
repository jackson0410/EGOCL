from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import auc, average_precision_score, precision_recall_curve, roc_curve


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot cold-start ROC and PR curves as separate paper-style figures.")
    parser.add_argument("--result_dir", default="results/egocl_cold_start")
    parser.add_argument("--output_dir", default="results/egocl_cold_start/figures")
    parser.add_argument("--split", default="test")
    parser.add_argument("--roc_prefix", default="egocl_cold_start_roc_curve")
    parser.add_argument("--pr_prefix", default="egocl_cold_start_pr_curve")
    return parser.parse_args()


def read_predictions(path: Path, split: str) -> tuple[np.ndarray, np.ndarray]:
    labels: list[int] = []
    scores: list[float] = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("split") != split:
                continue
            labels.append(int(float(row["label"])))
            scores.append(float(row["score"]))
    if not labels:
        raise ValueError(f"No predictions for split={split!r} in {path}")
    return np.asarray(labels, dtype=int), np.asarray(scores, dtype=float)


def save_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def configure_matplotlib() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 20,
            "axes.labelsize": 28,
            "axes.linewidth": 2.2,
            "legend.fontsize": 18,
            "legend.frameon": False,
            "xtick.labelsize": 21,
            "ytick.labelsize": 21,
            "xtick.major.width": 2.0,
            "ytick.major.width": 2.0,
            "xtick.major.size": 7,
            "ytick.major.size": 7,
            "lines.solid_capstyle": "round",
        }
    )


def style_axis(ax: plt.Axes) -> None:
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.set_xticks(np.linspace(0.0, 1.0, 6))
    ax.set_yticks(np.linspace(0.0, 1.0, 6))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(2.2)
    ax.spines["bottom"].set_linewidth(2.2)
    ax.tick_params(axis="both", which="major", width=2.0, length=7)


def save_figure(fig: plt.Figure, out_base: Path) -> None:
    fig.savefig(f"{out_base}.svg", bbox_inches="tight")
    fig.savefig(f"{out_base}.pdf", bbox_inches="tight")
    fig.savefig(f"{out_base}.png", dpi=600, bbox_inches="tight")
    fig.savefig(f"{out_base}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    result_dir = Path(args.result_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    configure_matplotlib()

    fold_dirs = sorted(path for path in result_dir.glob("fold_*") if (path / "predictions.csv").exists())
    if not fold_dirs:
        raise FileNotFoundError(f"No fold_*/predictions.csv files found under {result_dir}")

    colors = ["#0072B2", "#E69F00", "#6A3D9A", "#D55E00", "#F0E442"]
    mean_fpr = np.linspace(0.0, 1.0, 501)
    mean_recall = np.linspace(0.0, 1.0, 501)

    roc_curves: list[tuple[np.ndarray, np.ndarray, float]] = []
    pr_curves: list[tuple[np.ndarray, np.ndarray, float]] = []
    roc_interp: list[np.ndarray] = []
    pr_interp: list[np.ndarray] = []
    all_labels: list[np.ndarray] = []
    fold_rows: list[dict[str, object]] = []

    for fold_idx, fold_dir in enumerate(fold_dirs, start=1):
        labels, scores = read_predictions(fold_dir / "predictions.csv", args.split)
        all_labels.append(labels)

        fpr, tpr, roc_thresholds = roc_curve(labels, scores)
        roc_auc = float(auc(fpr, tpr))
        interp_tpr = np.interp(mean_fpr, fpr, tpr)
        interp_tpr[0] = 0.0
        interp_tpr[-1] = 1.0
        roc_interp.append(interp_tpr)
        roc_curves.append((fpr, tpr, roc_auc))

        precision, recall, pr_thresholds = precision_recall_curve(labels, scores)
        ap = float(average_precision_score(labels, scores))
        order = np.argsort(recall)
        sorted_recall = recall[order]
        sorted_precision = precision[order]
        interp_precision = np.interp(mean_recall, sorted_recall, sorted_precision)
        pr_interp.append(interp_precision)
        pr_curves.append((sorted_recall, sorted_precision, ap))

        max_len = max(len(fpr), len(recall))
        for i in range(max_len):
            fold_rows.append(
                {
                    "fold": fold_dir.name,
                    "roc_fpr": float(fpr[i]) if i < len(fpr) else "",
                    "roc_tpr": float(tpr[i]) if i < len(tpr) else "",
                    "roc_threshold": float(roc_thresholds[i]) if i < len(roc_thresholds) else "",
                    "roc_auc": roc_auc,
                    "pr_recall": float(sorted_recall[i]) if i < len(sorted_recall) else "",
                    "pr_precision": float(sorted_precision[i]) if i < len(sorted_precision) else "",
                    "pr_threshold": float(pr_thresholds[i]) if i < len(pr_thresholds) else "",
                    "aupr": ap,
                }
            )

    mean_tpr = np.mean(roc_interp, axis=0)
    mean_tpr[0] = 0.0
    mean_tpr[-1] = 1.0
    mean_auc = float(np.mean([curve[2] for curve in roc_curves]))
    std_auc = float(np.std([curve[2] for curve in roc_curves], ddof=1))

    mean_precision = np.clip(np.mean(pr_interp, axis=0), 0.0, 1.0)
    mean_aupr = float(np.mean([curve[2] for curve in pr_curves]))
    std_aupr = float(np.std([curve[2] for curve in pr_curves], ddof=1))
    prevalence = float(np.mean(np.concatenate(all_labels)))

    fig_roc, ax_roc = plt.subplots(figsize=(7.4, 7.2))
    style_axis(ax_roc)
    for i, (fpr, tpr, roc_auc) in enumerate(roc_curves):
        ax_roc.plot(fpr, tpr, color=colors[i % len(colors)], lw=4.0, label=f"Fold {i + 1} AUC = {roc_auc:.4f}")
    ax_roc.plot(mean_fpr, mean_tpr, color="black", lw=4.6, label=f"Mean AUC = {mean_auc:.4f}")
    ax_roc.plot([0, 1], [0, 1], color="#BDBDBD", lw=2.2, ls=(0, (5, 5)), zorder=0)
    ax_roc.set_xlabel("False positive rate")
    ax_roc.set_ylabel("True positive rate")
    ax_roc.legend(loc="lower center", bbox_to_anchor=(0.60, 0.08), handlelength=1.35, borderaxespad=0.0)
    fig_roc.tight_layout()
    save_figure(fig_roc, output_dir / args.roc_prefix)

    fig_pr, ax_pr = plt.subplots(figsize=(7.4, 7.2))
    style_axis(ax_pr)
    for i, (recall, precision, ap) in enumerate(pr_curves):
        ax_pr.plot(recall, precision, color=colors[i % len(colors)], lw=4.0, label=f"Fold {i + 1} AUPR = {ap:.4f}")
    ax_pr.plot(mean_recall, mean_precision, color="black", lw=4.6, label=f"Mean AUPR = {mean_aupr:.4f}")
    ax_pr.axhline(prevalence, color="#BDBDBD", lw=2.2, ls=(0, (5, 5)), zorder=0)
    ax_pr.set_xlabel("Recall")
    ax_pr.set_ylabel("Precision")
    ax_pr.legend(loc="lower center", bbox_to_anchor=(0.60, 0.05), handlelength=1.35, borderaxespad=0.0)
    fig_pr.tight_layout()
    save_figure(fig_pr, output_dir / args.pr_prefix)

    mean_rows = [
        {
            "fpr": float(fpr),
            "mean_tpr": float(tpr),
            "recall": float(recall),
            "mean_precision": float(precision),
            "mean_auc": mean_auc,
            "std_auc": std_auc,
            "mean_aupr": mean_aupr,
            "std_aupr": std_aupr,
            "prevalence": prevalence,
        }
        for fpr, tpr, recall, precision in zip(mean_fpr, mean_tpr, mean_recall, mean_precision)
    ]
    save_csv(output_dir / f"{args.roc_prefix}_and_{args.pr_prefix}_mean_source.csv", mean_rows, list(mean_rows[0]))
    save_csv(
        output_dir / f"{args.roc_prefix}_and_{args.pr_prefix}_fold_source.csv",
        fold_rows,
        ["fold", "roc_fpr", "roc_tpr", "roc_threshold", "roc_auc", "pr_recall", "pr_precision", "pr_threshold", "aupr"],
    )

    print(f"[plot_cold_start_separate_curves] mean AUC={mean_auc:.4f} +/- {std_auc:.4f}")
    print(f"[plot_cold_start_separate_curves] mean AUPR={mean_aupr:.4f} +/- {std_aupr:.4f}")
    print(f"[plot_cold_start_separate_curves] wrote {output_dir / args.roc_prefix}.*")
    print(f"[plot_cold_start_separate_curves] wrote {output_dir / args.pr_prefix}.*")


if __name__ == "__main__":
    main()
