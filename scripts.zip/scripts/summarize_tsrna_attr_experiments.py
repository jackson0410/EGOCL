from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv, save_csv


EXPERIMENTS = [
    ("EGOCL", "egocl_tsrna_attr"),
    ("EGOCL w/o tsRNA Attributes", "egocl_no_tsrna_attr"),
    ("EGOCL w/o Attribute Contrastive Loss", "egocl_tsrna_attr_no_attrcl"),
    ("EGOCL w/o Attribute Gate", "egocl_tsrna_attr_no_gate"),
]


def metric_map(path: Path) -> dict[str, tuple[float, float]]:
    rows = load_csv(path)
    return {row["metric"]: (float(row["mean"]), float(row["std"])) for row in rows}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize formal tsRNA attribute experiments.")
    parser.add_argument("--results_dir", default="results")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    results_dir = Path(args.results_dir)
    rows = []
    baseline_aupr = None
    baseline_f1 = None

    for model, dirname in EXPERIMENTS:
        mean_std_path = results_dir / dirname / "cv_mean_std.csv"
        if not mean_std_path.exists():
            rows.append(
                {
                    "Model": model,
                    "AUC_mean": "NA",
                    "AUC_std": "NA",
                    "AUPR_mean": "NA",
                    "AUPR_std": "NA",
                    "F1_mean": "NA",
                    "F1_std": "NA",
                    "Precision_mean": "NA",
                    "Recall_mean": "NA",
                    "Delta_AUPR_vs_EGOCL": "NA",
                    "Delta_F1_vs_EGOCL": "NA",
                }
            )
            continue

        metrics = metric_map(mean_std_path)
        aupr = metrics["test_aupr"][0]
        f1 = metrics["test_selected_threshold_f1"][0]
        if model == "EGOCL":
            baseline_aupr = aupr
            baseline_f1 = f1
        delta_aupr = "NA" if baseline_aupr is None else aupr - baseline_aupr
        delta_f1 = "NA" if baseline_f1 is None else f1 - baseline_f1
        rows.append(
            {
                "Model": model,
                "AUC_mean": metrics["test_auc"][0],
                "AUC_std": metrics["test_auc"][1],
                "AUPR_mean": aupr,
                "AUPR_std": metrics["test_aupr"][1],
                "F1_mean": f1,
                "F1_std": metrics["test_selected_threshold_f1"][1],
                "Precision_mean": metrics.get("test_selected_threshold_precision", (0.0, 0.0))[0],
                "Recall_mean": metrics.get("test_selected_threshold_recall", (0.0, 0.0))[0],
                "Delta_AUPR_vs_EGOCL": delta_aupr,
                "Delta_F1_vs_EGOCL": delta_f1,
            }
        )

    fields = [
        "Model",
        "AUC_mean",
        "AUC_std",
        "AUPR_mean",
        "AUPR_std",
        "F1_mean",
        "F1_std",
        "Precision_mean",
        "Recall_mean",
        "Delta_AUPR_vs_EGOCL",
        "Delta_F1_vs_EGOCL",
    ]
    csv_path = results_dir / "tsrna_attr_formal_experiment_summary.csv"
    save_csv(rows, csv_path, fields)

    lines = [
        "# Formal tsRNA Attribute Experiment Summary",
        "",
        "| Model | AUC | AUPR | Selected F1 | Precision | Recall | Delta AUPR vs EGOCL | Delta F1 vs EGOCL |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        def fmt(value: object) -> str:
            if value == "NA":
                return "NA"
            return f"{float(value):.4f}"

        auc = "NA" if row["AUC_mean"] == "NA" else f"{float(row['AUC_mean']):.4f} +/- {float(row['AUC_std']):.4f}"
        aupr_text = "NA" if row["AUPR_mean"] == "NA" else f"{float(row['AUPR_mean']):.4f} +/- {float(row['AUPR_std']):.4f}"
        f1_text = "NA" if row["F1_mean"] == "NA" else f"{float(row['F1_mean']):.4f} +/- {float(row['F1_std']):.4f}"
        lines.append(
            f"| {row['Model']} | {auc} | {aupr_text} | {f1_text} | "
            f"{fmt(row['Precision_mean'])} | {fmt(row['Recall_mean'])} | "
            f"{fmt(row['Delta_AUPR_vs_EGOCL'])} | {fmt(row['Delta_F1_vs_EGOCL'])} |"
        )
    md_path = results_dir / "tsrna_attr_formal_experiment_summary.md"
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[summarize_tsrna_attr_experiments] wrote {csv_path}")
    print(f"[summarize_tsrna_attr_experiments] wrote {md_path}")


if __name__ == "__main__":
    main()
