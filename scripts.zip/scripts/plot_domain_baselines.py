from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv


DISPLAY_NAMES = {
    "EGOCL": "EGOCL",
    "EGO-CLGNN": "EGOCL",
    "AGCLNDA-adapted": "AGCLNDA",
    "MSMCDA-adapted": "MSMCDA",
    "HybridGNN-adapted": "HybridGNN",
    "HybridGNN-adapted-degree-matched": "HybridGNN",
    "DualVGAE-adapted": "DualVGAE",
    "GCLNSTDA-adapted": "GCLNSTDA",
    "DMFCDA-adapted": "DMFCDA",
    "DMFCDA-adapted-degree-matched": "DMFCDA",
    "iCircDA-MF-adapted": "iCircDA-MF",
}


def display_name(model_name: str) -> str:
    if model_name in DISPLAY_NAMES:
        return DISPLAY_NAMES[model_name]
    return model_name.replace("-degree-matched", "").replace("-adapted", "")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot adapted domain baseline metrics.")
    parser.add_argument("--baseline_dir", default="results/domain_baselines")
    return parser.parse_args()


def plot_metric(rows: list[dict[str, str]], baseline_dir: Path, mean_field: str, std_field: str, ylabel: str, output_name: str) -> None:
    labels = [display_name(row["model"]) for row in rows]
    means = [float(row[mean_field]) for row in rows]
    stds = [float(row[std_field]) for row in rows]
    fig, ax = plt.subplots(figsize=(max(8.0, len(labels) * 1.2), 4.8))
    x = list(range(len(labels)))
    ax.bar(x, means, yerr=stds, capsize=4, color="#4C78A8", edgecolor="#263238", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.25, linewidth=0.6)
    lower = max(0.0, min(means) - max(stds) - 0.03)
    upper = min(1.0, max(means) + max(stds) + 0.03)
    if upper > lower:
        ax.set_ylim(lower, upper)
    fig.tight_layout()
    out_path = baseline_dir / output_name
    fig.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"[plot_domain_baselines] wrote {out_path}", flush=True)


def main() -> None:
    args = parse_args()
    baseline_dir = Path(args.baseline_dir)
    summary_path = baseline_dir / "domain_baseline_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(f"Missing summary file: {summary_path}")
    rows = load_csv(summary_path)
    plot_metric(rows, baseline_dir, "auc_mean", "auc_std", "AUC", "domain_baseline_auc.png")
    plot_metric(rows, baseline_dir, "aupr_mean", "aupr_std", "AUPR", "domain_baseline_aupr.png")
    plot_metric(rows, baseline_dir, "selected_f1_mean", "selected_f1_std", "Selected-threshold F1", "domain_baseline_f1.png")
    plot_metric(rows, baseline_dir, "recall_mean", "recall_std", "Recall", "domain_baseline_recall.png")


if __name__ == "__main__":
    main()
