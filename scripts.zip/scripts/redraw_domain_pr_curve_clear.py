from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["font.size"] = 7
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["legend.frameon"] = False


MODEL_ORDER = [
    "EGOCL",
    "MSMCDA-adapted",
    "DMFCDA-adapted-degree-matched",
    "iCircDA-MF-adapted",
    "DualVGAE-adapted",
    "HybridGNN-adapted-degree-matched",
    "AGCLNDA-adapted",
]

DISPLAY = {
    "EGOCL": "EGOCL",
    "MSMCDA-adapted": "MSMCDA",
    "DMFCDA-adapted-degree-matched": "DMFCDA",
    "iCircDA-MF-adapted": "iCircDA-MF",
    "DualVGAE-adapted": "DualVGAE",
    "HybridGNN-adapted-degree-matched": "HybridGNN",
    "AGCLNDA-adapted": "AGCLNDA",
}

COLORS = {
    "EGOCL": "#0072B2",
    "MSMCDA-adapted": "#009E73",
    "DMFCDA-adapted-degree-matched": "#E69F00",
    "iCircDA-MF-adapted": "#6A3D9A",
    "DualVGAE-adapted": "#F0E442",
    "HybridGNN-adapted-degree-matched": "#7F7F7F",
    "AGCLNDA-adapted": "#D55E00",
}

LINESTYLES = {
    "EGOCL": "-",
    "MSMCDA-adapted": (0, (4, 2)),
    "DMFCDA-adapted-degree-matched": "-",
    "iCircDA-MF-adapted": "-",
    "DualVGAE-adapted": "-",
    "HybridGNN-adapted-degree-matched": "-",
    "AGCLNDA-adapted": "-",
}


def clean_curve(df: pd.DataFrame, model: str) -> pd.DataFrame:
    """Sort source PR data and collapse duplicate recall values for a clean line trace."""
    curve = df[df["model"].astype(str) == model][["recall", "precision"]].copy()
    curve["recall"] = pd.to_numeric(curve["recall"], errors="coerce")
    curve["precision"] = pd.to_numeric(curve["precision"], errors="coerce")
    curve = curve.dropna()
    curve = curve[(curve["recall"] >= 0) & (curve["recall"] <= 1) & (curve["precision"] >= 0) & (curve["precision"] <= 1)]
    # Duplicate recall values create vertical line artifacts. The upper envelope
    # keeps the same threshold evidence while avoiding overplotting artifacts.
    curve = curve.groupby("recall", as_index=False)["precision"].max()
    curve = curve.sort_values("recall")
    if curve.iloc[0]["recall"] > 0:
        curve = pd.concat([pd.DataFrame({"recall": [0.0], "precision": [1.0]}), curve], ignore_index=True)
    if curve.iloc[-1]["recall"] < 1:
        curve = pd.concat([curve, pd.DataFrame({"recall": [1.0], "precision": [0.5]})], ignore_index=True)
    return curve


def main() -> None:
    base_dir = Path("results/domain_baselines")
    source_path = base_dir / "domain_pr_curve_source.csv"
    summary_path = base_dir / "domain_baseline_summary.csv"
    out_dir = base_dir / "clear_pr_curve"
    out_dir.mkdir(parents=True, exist_ok=True)

    source = pd.read_csv(source_path)
    summary = pd.read_csv(summary_path).set_index("model")

    curves = {model: clean_curve(source, model) for model in MODEL_ORDER}
    source_out = []
    for model, curve in curves.items():
        temp = curve.copy()
        temp["model"] = model
        source_out.append(temp)
    pd.concat(source_out, ignore_index=True).to_csv(out_dir / "domain_pr_curve_clear_source.csv", index=False)

    fig = plt.figure(figsize=(7.2, 4.2))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.55, 1.0], wspace=0.08)
    ax = fig.add_subplot(gs[0, 0])
    ax_zoom = fig.add_subplot(gs[0, 1])

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Recall", fontsize=9)
    ax.set_ylabel("Precision", fontsize=9)
    ax.set_title("Full precision-recall curve", fontsize=9.5, pad=5)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.set_yticks(np.linspace(0, 1, 6))
    ax.grid(True, linestyle="--", color="#E6E6E6", linewidth=0.6)
    ax.axhline(0.5, color="#B8B8B8", linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)

    ax_zoom.set_xlim(0.88, 0.995)
    ax_zoom.set_ylim(0.48, 0.86)
    ax_zoom.set_xlabel("Recall", fontsize=9)
    ax_zoom.set_title("High-recall region", fontsize=9.5, pad=5)
    ax_zoom.set_xticks([0.88, 0.92, 0.96, 0.99])
    ax_zoom.set_yticks([0.5, 0.6, 0.7, 0.8])
    ax_zoom.grid(True, linestyle="--", color="#E6E6E6", linewidth=0.6)
    ax_zoom.axhline(0.5, color="#B8B8B8", linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)

    # Draw competing methods first. EGOCL is drawn last with a white stroke.
    for model in MODEL_ORDER[1:]:
        curve = curves[model]
        lw = 1.8 if model == "MSMCDA-adapted" else 1.45
        alpha = 0.82 if model == "MSMCDA-adapted" else 0.72
        ax.plot(
            curve["recall"],
            curve["precision"],
            color=COLORS[model],
            lw=lw,
            alpha=alpha,
            linestyle=LINESTYLES[model],
            label=f"{DISPLAY[model]} (AUPR = {summary.loc[model, 'aupr_mean']:.4f})",
            zorder=2,
        )
        ax_zoom.plot(
            curve["recall"],
            curve["precision"],
            color=COLORS[model],
            lw=1.55 if model == "MSMCDA-adapted" else 1.25,
            alpha=0.70 if model == "MSMCDA-adapted" else 0.58,
            linestyle=LINESTYLES[model],
            zorder=2,
        )

    egocl = curves["EGOCL"]
    ax.plot(
        egocl["recall"],
        egocl["precision"],
        color=COLORS["EGOCL"],
        lw=2.8,
        label=f"EGOCL (AUPR = {summary.loc['EGOCL', 'aupr_mean']:.4f})",
        zorder=6,
        path_effects=[pe.Stroke(linewidth=5.0, foreground="white"), pe.Normal()],
    )
    ax_zoom.plot(
        egocl["recall"],
        egocl["precision"],
        color=COLORS["EGOCL"],
        lw=2.6,
        zorder=6,
        path_effects=[pe.Stroke(linewidth=4.8, foreground="white"), pe.Normal()],
    )
    ax_zoom.text(
        0.895,
        0.825,
        "EGOCL",
        color=COLORS["EGOCL"],
        fontsize=7,
        weight="bold",
        ha="left",
        va="center",
    )
    ax_zoom.text(
        0.895,
        0.755,
        "MSMCDA",
        color=COLORS["MSMCDA-adapted"],
        fontsize=7,
        ha="left",
        va="center",
    )

    handles, labels = ax.get_legend_handles_labels()
    order = [labels.index(label) for label in labels if label.startswith("EGOCL")] + [
        i for i, label in enumerate(labels) if not label.startswith("EGOCL")
    ]
    fig.legend(
        [handles[i] for i in order],
        [labels[i] for i in order],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.035),
        ncol=4,
        fontsize=6.3,
        frameon=True,
        framealpha=0.94,
        facecolor="white",
        edgecolor="#333333",
        borderpad=0.45,
        handlelength=2.0,
    )
    fig.subplots_adjust(left=0.075, right=0.985, top=0.88, bottom=0.29, wspace=0.22)

    base = out_dir / "domain_baseline_pr_curve_clear_twopanel"
    for ext, kwargs in {
        "svg": {},
        "pdf": {},
        "png": {"dpi": 600},
        "tiff": {"dpi": 600},
    }.items():
        fig.savefig(base.with_suffix(f".{ext}"), bbox_inches="tight", **kwargs)
    plt.close(fig)

    (out_dir / "domain_baseline_pr_curve_clear_qa.md").write_text(
        "\n".join(
            [
                "# Clear PR curve QA",
                "",
                "Core conclusion: EGOCL remains visually separable from MSMCDA in the high-recall segment.",
                "Source data: results/domain_baselines/domain_pr_curve_source.csv.",
                "Visual changes: duplicate recall values collapsed by upper envelope, non-EGOCL methods drawn first, EGOCL drawn last with white stroke, and high-recall region shown as a separate right-hand panel without covering the full curve.",
                "Backend: Python matplotlib only.",
                "Exports: SVG, PDF, PNG, TIFF.",
            ]
        ),
        encoding="utf-8",
    )

    print(base.with_suffix(".png"))
    print(base.with_suffix(".svg"))
    print(base.with_suffix(".pdf"))
    print(base.with_suffix(".tiff"))


if __name__ == "__main__":
    main()
