from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["font.size"] = 7
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["legend.frameon"] = False


MODEL_ORDER = [
    "EGOCL",
    "MSMCDA-adapted",
    "DMFCDA-adapted-degree-matched",
    "iCircDA-MF-adapted",
    "DualVGAE-adapted",
    "HybridGNN-adapted-degree-matched",
    "AGCLNDA-adapted",
]

DISPLAY = {
    "EGOCL": "EGOCL",
    "MSMCDA-adapted": "MSMCDA",
    "DMFCDA-adapted-degree-matched": "DMFCDA",
    "iCircDA-MF-adapted": "iCircDA-MF",
    "DualVGAE-adapted": "DualVGAE",
    "HybridGNN-adapted-degree-matched": "HybridGNN",
    "AGCLNDA-adapted": "AGCLNDA",
}

COLORS = {
    "EGOCL": "#0072B2",
    "MSMCDA-adapted": "#009E73",
    "DMFCDA-adapted-degree-matched": "#E69F00",
    "iCircDA-MF-adapted": "#6A3D9A",
    "DualVGAE-adapted": "#F0E442",
    "HybridGNN-adapted-degree-matched": "#7F7F7F",
    "AGCLNDA-adapted": "#D55E00",
}

LINESTYLES = {
    "EGOCL": "-",
    "MSMCDA-adapted": (0, (4, 2)),
    "DMFCDA-adapted-degree-matched": "-",
    "iCircDA-MF-adapted": "-",
    "DualVGAE-adapted": "-",
    "HybridGNN-adapted-degree-matched": "-",
    "AGCLNDA-adapted": "-",
}


def clean_curve(df: pd.DataFrame, model: str) -> pd.DataFrame:
    """Sort ROC data and collapse duplicate FPR values for a clean line trace."""
    curve = df[df["model"].astype(str) == model][["fpr", "tpr"]].copy()
    curve["fpr"] = pd.to_numeric(curve["fpr"], errors="coerce")
    curve["tpr"] = pd.to_numeric(curve["tpr"], errors="coerce")
    curve = curve.dropna()
    curve = curve[(curve["fpr"] >= 0) & (curve["fpr"] <= 1) & (curve["tpr"] >= 0) & (curve["tpr"] <= 1)]
    curve = curve.groupby("fpr", as_index=False)["tpr"].max()
    curve = curve.sort_values("fpr")
    if curve.iloc[0]["fpr"] > 0:
        curve = pd.concat([pd.DataFrame({"fpr": [0.0], "tpr": [0.0]}), curve], ignore_index=True)
    if curve.iloc[-1]["fpr"] < 1:
        curve = pd.concat([curve, pd.DataFrame({"fpr": [1.0], "tpr": [1.0]})], ignore_index=True)
    return curve


def plot_curve(ax, curve, model, summary, label=True, zoom=False):
    is_egocl = model == "EGOCL"
    is_msmcda = model == "MSMCDA-adapted"
    lw = 2.8 if is_egocl else (1.8 if is_msmcda else 1.45)
    if zoom:
        lw = 2.6 if is_egocl else (1.55 if is_msmcda else 1.25)
    alpha = 1.0 if is_egocl else (0.78 if is_msmcda else 0.66)
    kwargs = {
        "color": COLORS[model],
        "lw": lw,
        "alpha": alpha,
        "linestyle": LINESTYLES[model],
        "zorder": 6 if is_egocl else 2,
    }
    if is_egocl:
        kwargs["path_effects"] = [pe.Stroke(linewidth=5.0 if not zoom else 4.8, foreground="white"), pe.Normal()]
    if label:
        kwargs["label"] = f"{DISPLAY[model]} (AUC = {summary.loc[model, 'auc_mean']:.4f})"
    ax.plot(curve["fpr"], curve["tpr"], **kwargs)


def main() -> None:
    base_dir = Path("results/domain_baselines")
    source_path = base_dir / "domain_roc_curve_source.csv"
    summary_path = base_dir / "domain_baseline_summary.csv"
    out_dir = base_dir / "clear_roc_curve"
    out_dir.mkdir(parents=True, exist_ok=True)

    source = pd.read_csv(source_path)
    summary = pd.read_csv(summary_path).set_index("model")
    curves = {model: clean_curve(source, model) for model in MODEL_ORDER}

    source_out = []
    for model, curve in curves.items():
        temp = curve.copy()
        temp["model"] = model
        source_out.append(temp)
    pd.concat(source_out, ignore_index=True).to_csv(out_dir / "domain_roc_curve_aligned_source.csv", index=False)

    fig = plt.figure(figsize=(7.2, 4.2))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.55, 1.0], wspace=0.08)
    ax = fig.add_subplot(gs[0, 0])
    ax_zoom = fig.add_subplot(gs[0, 1])

    for current_ax in (ax, ax_zoom):
        current_ax.grid(True, linestyle="--", color="#E6E6E6", linewidth=0.6)
        current_ax.plot([0, 1], [0, 1], color="#B8B8B8", linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("False Positive Rate", fontsize=9)
    ax.set_ylabel("True Positive Rate", fontsize=9)
    ax.set_title("Full ROC curve", fontsize=9.5, pad=5)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.set_yticks(np.linspace(0, 1, 6))

    ax_zoom.set_xlim(0.00, 0.25)
    ax_zoom.set_ylim(0.55, 1.00)
    ax_zoom.set_xlabel("False Positive Rate", fontsize=9)
    ax_zoom.set_title("Low-FPR region", fontsize=9.5, pad=5)
    ax_zoom.set_xticks([0.00, 0.05, 0.10, 0.15, 0.20, 0.25])
    ax_zoom.set_yticks([0.6, 0.7, 0.8, 0.9, 1.0])

    for model in MODEL_ORDER[1:]:
        plot_curve(ax, curves[model], model, summary, label=True, zoom=False)
        plot_curve(ax_zoom, curves[model], model, summary, label=False, zoom=True)

    plot_curve(ax, curves["EGOCL"], "EGOCL", summary, label=True, zoom=False)
    plot_curve(ax_zoom, curves["EGOCL"], "EGOCL", summary, label=False, zoom=True)

    ax_zoom.text(
        0.025,
        0.905,
        "EGOCL",
        color=COLORS["EGOCL"],
        fontsize=7,
        weight="bold",
        ha="left",
        va="center",
    )
    ax_zoom.text(
        0.025,
        0.855,
        "MSMCDA",
        color=COLORS["MSMCDA-adapted"],
        fontsize=7,
        ha="left",
        va="center",
    )

    handles, labels = ax.get_legend_handles_labels()
    order = [labels.index(label) for label in labels if label.startswith("EGOCL")] + [
        i for i, label in enumerate(labels) if not label.startswith("EGOCL")
    ]
    fig.legend(
        [handles[i] for i in order],
        [labels[i] for i in order],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.035),
        ncol=4,
        fontsize=6.3,
        frameon=True,
        framealpha=0.94,
        facecolor="white",
        edgecolor="#333333",
        borderpad=0.45,
        handlelength=2.0,
    )

    fig.subplots_adjust(left=0.075, right=0.985, top=0.88, bottom=0.29, wspace=0.22)
    base = out_dir / "domain_baseline_roc_curve_aligned_twopanel"
    for ext, kwargs in {
        "svg": {},
        "pdf": {},
        "png": {"dpi": 600},
        "tiff": {"dpi": 600},
    }.items():
        fig.savefig(base.with_suffix(f".{ext}"), bbox_inches="tight", **kwargs)
    plt.close(fig)

    (out_dir / "domain_baseline_roc_curve_aligned_qa.md").write_text(
        "\n".join(
            [
                "# Aligned ROC curve QA",
                "",
                "Core conclusion: EGOCL has the leading ROC profile among the fair adapted baselines, especially in the low-FPR region.",
                "Source data: results/domain_baselines/domain_roc_curve_source.csv.",
                "Visual changes: two-panel layout matched to the revised PR curve, EGOCL drawn last with white stroke, MSMCDA shown as a dashed competitor, and the low-FPR region shown in a separate panel without covering the full curve.",
                "Backend: Python matplotlib only.",
                "Exports: SVG, PDF, PNG, TIFF.",
            ]
        ),
        encoding="utf-8",
    )

    print(base.with_suffix(".png"))
    print(base.with_suffix(".svg"))
    print(base.with_suffix(".pdf"))
    print(base.with_suffix(".tiff"))


if __name__ == "__main__":
    main()
