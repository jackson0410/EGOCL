from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.check_data_leakage import check_run_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check leakage for all CV folds.")
    parser.add_argument("--cv_dir", default="results/cv")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cv_dir = Path(args.cv_dir)
    fold_dirs = sorted(path for path in cv_dir.glob("fold_*") if path.is_dir())
    if not fold_dirs:
        raise FileNotFoundError(f"No fold directories found under {cv_dir}")

    for fold_dir in fold_dirs:
        print(f"[check_cv_leakage] checking {fold_dir}")
        check_run_dir(fold_dir, args.data_dir)

    print("[check_cv_leakage] all folds passed")


if __name__ == "__main__":
    main()
