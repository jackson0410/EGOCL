from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.check_data_leakage import check_run_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check leakage for all ablation folds.")
    parser.add_argument("--ablation_dir", default="results/ablation")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    ablation_dir = Path(args.ablation_dir)
    variant_dirs = sorted(path for path in ablation_dir.iterdir() if path.is_dir())
    if not variant_dirs:
        raise FileNotFoundError(f"No variant directories found under {ablation_dir}")

    checked = 0
    for variant_dir in variant_dirs:
        fold_dirs = sorted(path for path in variant_dir.glob("fold_*") if path.is_dir())
        if not fold_dirs:
            continue
        for fold_dir in fold_dirs:
            print(f"[check_ablation_leakage] checking {variant_dir.name}/{fold_dir.name}")
            check_run_dir(fold_dir, args.data_dir)
            checked += 1

    if checked == 0:
        raise FileNotFoundError(f"No fold directories found under {ablation_dir}")
    print("[check_ablation_leakage] all ablation folds passed")


if __name__ == "__main__":
    main()
