from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import auc, roc_curve


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot cold-start ROC curves from EGOCL fold predictions.")
    parser.add_argument("--result_dir", default="results/egocl_cold_start")
    parser.add_argument("--output_dir", default="results/egocl_cold_start/figures")
    parser.add_argument("--split", default="test")
    parser.add_argument("--prefix", default="egocl_cold_start_roc_curve")
    return parser.parse_args()


def read_predictions(path: Path, split: str) -> tuple[np.ndarray, np.ndarray]:
    labels: list[int] = []
    scores: list[float] = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("split") != split:
                continue
            labels.append(int(float(row["label"])))
            scores.append(float(row["score"]))
    if not labels:
        raise ValueError(f"No predictions for split={split!r} in {path}")
    return np.asarray(labels, dtype=int), np.asarray(scores, dtype=float)


def save_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    result_dir = Path(args.result_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.8,
            "legend.frameon": False,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
        }
    )

    fold_dirs = sorted(path for path in result_dir.glob("fold_*") if (path / "predictions.csv").exists())
    if not fold_dirs:
        raise FileNotFoundError(f"No fold_*/predictions.csv files found under {result_dir}")

    mean_fpr = np.linspace(0.0, 1.0, 301)
    interp_tprs: list[np.ndarray] = []
    fold_auc_values: list[float] = []
    fold_rows: list[dict[str, object]] = []

    fig, ax = plt.subplots(figsize=(3.45, 3.15))
    for fold_dir in fold_dirs:
        labels, scores = read_predictions(fold_dir / "predictions.csv", args.split)
        fpr, tpr, thresholds = roc_curve(labels, scores)
        roc_auc = auc(fpr, tpr)
        fold_auc_values.append(float(roc_auc))
        interp = np.interp(mean_fpr, fpr, tpr)
        interp[0] = 0.0
        interp_tprs.append(interp)
        ax.plot(fpr, tpr, color="#B8C0CC", lw=0.8, alpha=0.55, zorder=1)

        for x, y, threshold in zip(fpr, tpr, thresholds):
            fold_rows.append(
                {
                    "fold": fold_dir.name,
                    "fpr": float(x),
                    "tpr": float(y),
                    "threshold": float(threshold),
                    "auc": float(roc_auc),
                }
            )

    mean_tpr = np.mean(interp_tprs, axis=0)
    std_tpr = np.std(interp_tprs, axis=0, ddof=1) if len(interp_tprs) > 1 else np.zeros_like(mean_tpr)
    mean_tpr[-1] = 1.0
    tpr_lower = np.maximum(mean_tpr - std_tpr, 0.0)
    tpr_upper = np.minimum(mean_tpr + std_tpr, 1.0)
    mean_auc = float(np.mean(fold_auc_values))
    std_auc = float(np.std(fold_auc_values, ddof=1)) if len(fold_auc_values) > 1 else 0.0

    ax.fill_between(mean_fpr, tpr_lower, tpr_upper, color="#4C78A8", alpha=0.16, lw=0, zorder=2)
    ax.plot(
        mean_fpr,
        mean_tpr,
        color="#1F5A99",
        lw=2.0,
        label=f"EGOCL (AUC = {mean_auc:.3f} ± {std_auc:.3f})",
        zorder=3,
    )
    ax.plot([0, 1], [0, 1], color="#8C8C8C", lw=0.8, ls=(0, (3, 3)), zorder=0)

    ax.set_xlim(-0.01, 1.01)
    ax.set_ylim(-0.01, 1.01)
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("tsRNA cold-start ROC", pad=7, fontweight="bold")
    ax.legend(loc="lower left", handlelength=2.2)
    ax.set_aspect("equal", adjustable="box")
    fig.tight_layout(pad=0.6)

    out_base = output_dir / args.prefix
    fig.savefig(f"{out_base}.svg", bbox_inches="tight")
    fig.savefig(f"{out_base}.pdf", bbox_inches="tight")
    fig.savefig(f"{out_base}.png", dpi=600, bbox_inches="tight")
    fig.savefig(f"{out_base}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)

    mean_rows = [
        {
            "fpr": float(x),
            "mean_tpr": float(y),
            "std_tpr": float(s),
            "tpr_lower": float(lo),
            "tpr_upper": float(hi),
            "mean_auc": mean_auc,
            "std_auc": std_auc,
        }
        for x, y, s, lo, hi in zip(mean_fpr, mean_tpr, std_tpr, tpr_lower, tpr_upper)
    ]
    save_csv(output_dir / f"{args.prefix}_mean_source.csv", mean_rows, list(mean_rows[0]))
    save_csv(output_dir / f"{args.prefix}_fold_source.csv", fold_rows, ["fold", "fpr", "tpr", "threshold", "auc"])

    print(f"[plot_cold_start_roc] mean AUC={mean_auc:.4f} +/- {std_auc:.4f}")
    print(f"[plot_cold_start_roc] wrote {out_base}.svg/.pdf/.png/.tiff")


if __name__ == "__main__":
    main()
