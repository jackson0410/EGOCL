from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans", "Liberation Sans"]
plt.rcParams["svg.fonttype"] = "none"
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["font.size"] = 7
plt.rcParams["axes.linewidth"] = 0.65
plt.rcParams["axes.spines.top"] = False
plt.rcParams["axes.spines.right"] = False
plt.rcParams["legend.frameon"] = False


DATA = [
    {"variant": "EGOCL", "label": "EGOCL", "AUC": 0.9213, "AUPR": 0.9182, "F1": 0.8469, "Precision": 0.8449},
    {
        "variant": "EGOCL w/o Mixed Hard Negatives",
        "label": "w/o mixed hard negatives",
        "AUC": 0.8981,
        "AUPR": 0.8962,
        "F1": 0.8192,
        "Precision": 0.7977,
    },
    {
        "variant": "EGOCL w/o Ontology",
        "label": "w/o ontology",
        "AUC": 0.9141,
        "AUPR": 0.9057,
        "F1": 0.8443,
        "Precision": 0.8279,
    },
    {
        "variant": "EGOCL w/o Attribute Gate",
        "label": "w/o attribute gate",
        "AUC": 0.9143,
        "AUPR": 0.9130,
        "F1": 0.8374,
        "Precision": 0.8160,
    },
]

METRICS = ["AUC", "AUPR", "F1", "Precision"]
ORDER = ["EGOCL", "w/o ontology", "w/o attribute gate", "w/o mixed hard negatives"]

COLORS = {
    "EGOCL": "#0F4D92",
    "w/o mixed hard negatives": "#D67A78",
    "w/o ontology": "#70B3BA",
    "w/o attribute gate": "#B680AC",
}


def add_panel_label(ax, label):
    ax.text(
        -0.16,
        1.04,
        label,
        transform=ax.transAxes,
        fontsize=8,
        fontweight="bold",
        ha="left",
        va="bottom",
    )


def main():
    out_dir = Path("results/ablation_bar_figure")
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.DataFrame(DATA)
    df.to_csv(out_dir / "egocl_ablation_bar_figure_source.csv", index=False)

    label_to_row = {row["label"]: row for _, row in df.iterrows()}
    y = np.arange(len(ORDER))[::-1]
    panel_labels = ["a", "b", "c", "d"]

    fig, axes = plt.subplots(2, 2, figsize=(7.2, 3.85), sharex=True)
    axes = axes.ravel()

    for ax, metric, panel_label in zip(axes, METRICS, panel_labels):
        values = np.array([float(label_to_row[label][metric]) for label in ORDER])
        colors = [COLORS[label] for label in ORDER]
        bars = ax.barh(
            y,
            values,
            height=0.62,
            color=colors,
            edgecolor="#272727",
            linewidth=0.35,
            alpha=0.96,
        )

        full_value = values[0]
        ax.axvline(full_value, color="#0F4D92", lw=0.9, ls=(0, (2.2, 2.2)), alpha=0.75)

        for bar, value, label in zip(bars, values, ORDER):
            text_color = "#0F4D92" if label == "EGOCL" else "#4D4D4D"
            ax.text(
                value + 0.002,
                bar.get_y() + bar.get_height() / 2,
                f"{value:.4f}",
                ha="left",
                va="center",
                fontsize=6.2,
                color=text_color,
            )

        ax.set_title(metric, loc="left", fontsize=8, pad=5)
        ax.set_xlim(0.78, 0.94)
        ax.set_xticks([0.80, 0.85, 0.90])
        ax.grid(axis="x", color="#D8D8D8", linewidth=0.45, alpha=0.7)
        ax.set_axisbelow(True)
        ax.tick_params(axis="x", labelsize=6.2, length=2)
        ax.tick_params(axis="y", length=0)
        ax.set_yticks(y)
        ax.set_yticklabels(ORDER, fontsize=6.3)
        add_panel_label(ax, panel_label)

    for ax in axes[1::2]:
        ax.set_yticklabels([])

    handles = [
        plt.Rectangle((0, 0), 1, 1, color=COLORS["EGOCL"], label="Full EGOCL"),
        plt.Rectangle((0, 0), 1, 1, color="#D8A0A0", label="Ablated variants"),
        plt.Line2D([0], [0], color="#0F4D92", lw=0.9, ls=(0, (2.2, 2.2)), label="Full-model reference"),
    ]
    fig.legend(
        handles=handles,
        loc="lower center",
        bbox_to_anchor=(0.53, -0.015),
        ncol=3,
        fontsize=6.5,
        handlelength=1.5,
        columnspacing=1.6,
    )

    fig.suptitle("Ablation analysis of EGOCL", x=0.02, y=1.02, ha="left", fontsize=9, fontweight="bold")
    fig.supxlabel("Performance", x=0.53, y=0.08, fontsize=7)
    fig.subplots_adjust(left=0.20, right=0.985, top=0.88, bottom=0.21, wspace=0.18, hspace=0.42)

    base = out_dir / "egocl_ablation_bar_figure"
    for ext, kwargs in {
        "svg": {},
        "pdf": {},
        "png": {"dpi": 600},
        "tiff": {"dpi": 600},
    }.items():
        fig.savefig(base.with_suffix(f".{ext}"), bbox_inches="tight", **kwargs)
    plt.close(fig)

    (out_dir / "egocl_ablation_bar_figure_qa.md").write_text(
        "\n".join(
            [
                "# EGOCL ablation bar figure QA",
                "",
                "Core conclusion: full EGOCL has the strongest or near-strongest profile across all four reported metrics.",
                "Archetype: quantitative grid, four horizontal bar panels.",
                "Backend: Python matplotlib only.",
                "Variability: not shown, by request.",
                "Exports: SVG, PDF, PNG, TIFF.",
            ]
        ),
        encoding="utf-8",
    )

    print(base.with_suffix(".png"))
    print(base.with_suffix(".svg"))
    print(base.with_suffix(".pdf"))
    print(base.with_suffix(".tiff"))


if __name__ == "__main__":
    main()
