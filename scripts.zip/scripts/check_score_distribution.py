from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.metrics import evaluate_at_threshold, evaluate_binary_classification
from src.utils import ensure_dir, load_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Inspect prediction score distribution for one run/fold.")
    parser.add_argument("--run_dir", default="results/clgnn_cv/fold_0")
    parser.add_argument("--split", default="test", choices=["train", "valid", "test", "all"])
    return parser.parse_args()


def describe_scores(name: str, values: np.ndarray) -> dict[str, float]:
    if values.size == 0:
        raise ValueError(f"No {name} scores found.")
    return {
        "mean": float(values.mean()),
        "std": float(values.std(ddof=1)) if values.size > 1 else 0.0,
        "min": float(values.min()),
        "max": float(values.max()),
    }


def print_stats(name: str, values: np.ndarray) -> None:
    stats = describe_scores(name, values)
    print(
        f"{name} score mean/std/min/max: "
        f"{stats['mean']:.6f} / {stats['std']:.6f} / {stats['min']:.6f} / {stats['max']:.6f}",
        flush=True,
    )


def save_plot(run_dir: Path, positive_scores: np.ndarray, negative_scores: np.ndarray) -> Path:
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise ImportError("matplotlib is required for score distribution plotting.") from exc

    output_path = run_dir / "score_distribution.png"
    plt.figure(figsize=(8, 5))
    bins = np.linspace(0.0, 1.0, 51)
    plt.hist(negative_scores, bins=bins, alpha=0.65, label="negative", color="#4c78a8")
    plt.hist(positive_scores, bins=bins, alpha=0.65, label="positive", color="#f58518")
    plt.xlabel("sigmoid probability score")
    plt.ylabel("count")
    plt.title("Score Distribution")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()
    return output_path


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir)
    prediction_path = run_dir / "predictions.csv"
    if not prediction_path.exists():
        raise FileNotFoundError(f"Missing predictions file: {prediction_path}")

    rows = load_csv(prediction_path)
    if args.split != "all":
        rows = [row for row in rows if row.get("split") == args.split]
    if not rows:
        raise ValueError(f"No prediction rows found for split={args.split} in {prediction_path}")

    labels = np.asarray([int(row["label"]) for row in rows], dtype=int)
    scores = np.asarray([float(row["score"]) for row in rows], dtype=float)
    if np.any(scores < -1e-8) or np.any(scores > 1.0 + 1e-8):
        raise ValueError("predictions.csv score column must contain sigmoid probabilities in [0, 1].")

    positive_scores = scores[labels == 1]
    negative_scores = scores[labels == 0]
    print(f"[check_score_distribution] run_dir: {run_dir}", flush=True)
    print(f"[check_score_distribution] split: {args.split}", flush=True)
    print_stats("positive", positive_scores)
    print_stats("negative", negative_scores)

    quantile_points = [0.0, 0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 0.9, 0.95, 0.99, 1.0]
    quantiles = np.quantile(scores, quantile_points)
    print("[check_score_distribution] score quantiles:", flush=True)
    for point, value in zip(quantile_points, quantiles):
        print(f"  q{point:.2f}: {value:.6f}", flush=True)

    metrics = evaluate_binary_classification(labels, scores)
    best_threshold = metrics["best_threshold"]
    best_at_threshold = evaluate_at_threshold(labels, scores, best_threshold, "best")
    print(f"[check_score_distribution] AUC: {metrics['AUC']:.6f}", flush=True)
    print(f"[check_score_distribution] AUPR: {metrics['AUPR']:.6f}", flush=True)
    print(f"[check_score_distribution] best threshold: {best_threshold:.2f}", flush=True)
    print(f"[check_score_distribution] precision at best threshold: {best_at_threshold['best_precision']:.6f}", flush=True)
    print(f"[check_score_distribution] recall at best threshold: {best_at_threshold['best_recall']:.6f}", flush=True)
    print(f"[check_score_distribution] F1 at best threshold: {best_at_threshold['best_f1']:.6f}", flush=True)

    ensure_dir(run_dir)
    output_path = save_plot(run_dir, positive_scores, negative_scores)
    print(f"[check_score_distribution] plot written to: {output_path}", flush=True)


if __name__ == "__main__":
    main()
