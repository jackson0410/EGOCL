from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot ablation summary metrics.")
    parser.add_argument("--ablation_dir", default="results/ablation")
    return parser.parse_args()


def plot_metric(df: pd.DataFrame, mean_col: str, std_col: str, title: str, ylabel: str, output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(10, 5), constrained_layout=True)
    ax.bar(df["variant"], df[mean_col], yerr=df[std_col], capsize=4, color="tab:blue", alpha=0.85)
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.set_xlabel("Variant")
    ax.grid(True, axis="y", alpha=0.3)
    ax.tick_params(axis="x", rotation=30)
    for label in ax.get_xticklabels():
        label.set_horizontalalignment("right")
    fig.savefig(output_path, dpi=200)
    plt.close(fig)
    print(f"[plot_ablation_results] wrote: {output_path}")


def main() -> None:
    args = parse_args()
    ablation_dir = Path(args.ablation_dir)
    summary_path = ablation_dir / "ablation_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(f"Missing ablation summary: {summary_path}")

    df = pd.read_csv(summary_path)
    plot_metric(df, "test_auc_mean", "test_auc_std", "Ablation Test AUC", "AUC", ablation_dir / "ablation_auc.png")
    plot_metric(df, "test_aupr_mean", "test_aupr_std", "Ablation Test AUPR", "AUPR", ablation_dir / "ablation_aupr.png")
    plot_metric(
        df,
        "test_selected_threshold_f1_mean",
        "test_selected_threshold_f1_std",
        "Ablation Test Selected-Threshold F1",
        "F1",
        ablation_dir / "ablation_f1.png",
    )


if __name__ == "__main__":
    main()
