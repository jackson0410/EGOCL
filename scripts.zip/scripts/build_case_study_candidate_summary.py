﻿from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import save_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a compact case-study candidate table with local evidence summaries.")
    parser.add_argument("--topk_file", default="results/egocl_case_study/topk_by_disease_excluding_all_known.csv")
    parser.add_argument("--processed_dir", default="data/processed")
    parser.add_argument("--output_dir", default="results/egocl_case_study")
    parser.add_argument("--disease_ids", default="2,35,120")
    parser.add_argument("--top_n", type=int, default=5)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def nonempty(value: str) -> bool:
    return bool(value and value.strip() and value.strip().upper() != "N/A")


def split_multi(value: str) -> set[str]:
    if not nonempty(value):
        return set()
    out: set[str] = set()
    for chunk in value.replace(";", "//").split("//"):
        chunk = chunk.strip()
        if chunk and chunk.upper() != "N/A":
            out.add(chunk)
    return out


def overlap(a: str, b: str) -> bool:
    return bool(split_multi(a) & split_multi(b))


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    processed_dir = Path(args.processed_dir)
    target_diseases = [int(x.strip()) for x in args.disease_ids.split(",") if x.strip()]

    top_rows = read_csv(Path(args.topk_file))
    tsrna_rows = {int(row["tsrna_id"]): row for row in read_csv(processed_dir / "tsrna.csv")}
    disease_rows = {int(row["disease_id"]): row for row in read_csv(processed_dir / "disease.csv")}
    assoc_rows = [row for row in read_csv(processed_dir / "associations.csv") if row.get("label") in {"1", "1.0", ""}]
    exp_rows = [row for row in assoc_rows if "Experimental" in row.get("way", "")]

    selected: list[dict[str, str]] = []
    for disease_id in target_diseases:
        disease_candidates = [row for row in top_rows if int(row["disease_id"]) == disease_id]
        selected.extend(disease_candidates[: args.top_n])

    out_rows = []
    for row in selected:
        tsrna_id = int(row["tsrna_id"])
        disease_id = int(row["disease_id"])
        t = tsrna_rows.get(tsrna_id, {})
        same_disease = [r for r in exp_rows if int(r["disease_id"]) == disease_id]
        same_tsrna = [r for r in exp_rows if int(r["tsrna_id"]) == tsrna_id]

        same_anticodon = [
            r
            for r in same_disease
            if overlap(t.get("anticodon", ""), tsrna_rows.get(int(r["tsrna_id"]), {}).get("anticodon", ""))
        ]
        same_amino = [
            r
            for r in same_disease
            if overlap(t.get("aminoacid", ""), tsrna_rows.get(int(r["tsrna_id"]), {}).get("aminoacid", ""))
        ]
        same_type = [
            r
            for r in same_disease
            if nonempty(t.get("tsrna_type", ""))
            and t.get("tsrna_type", "") == tsrna_rows.get(int(r["tsrna_id"]), {}).get("tsrna_type", "")
        ]
        known_disease_names = []
        for r in same_tsrna[:8]:
            known_disease_names.append(disease_rows.get(int(r["disease_id"]), {}).get("disease_name", ""))

        out_rows.append(
            {
                "disease_id": disease_id,
                "disease_name": row["disease_name"],
                "disease_rank": row["disease_rank"],
                "tsrna_id": tsrna_id,
                "tsrna_name": row["tsrna_name"],
                "score": row["score"],
                "mean_logit": row["mean_logit"],
                "tsrna_type": row["tsrna_type"],
                "anticodon": row["anticodon"],
                "aminoacid": row["aminoacid"],
                "same_disease_experimental_count": len(same_disease),
                "same_disease_same_anticodon_count": len(same_anticodon),
                "same_disease_same_amino_count": len(same_amino),
                "same_disease_same_type_count": len(same_type),
                "same_tsrna_experimental_disease_count": len(same_tsrna),
                "same_tsrna_known_diseases": "; ".join(x for x in known_disease_names if x),
            }
        )

    fields = [
        "disease_id",
        "disease_name",
        "disease_rank",
        "tsrna_id",
        "tsrna_name",
        "score",
        "mean_logit",
        "tsrna_type",
        "anticodon",
        "aminoacid",
        "same_disease_experimental_count",
        "same_disease_same_anticodon_count",
        "same_disease_same_amino_count",
        "same_disease_same_type_count",
        "same_tsrna_experimental_disease_count",
        "same_tsrna_known_diseases",
    ]
    save_csv(out_rows, output_dir / "selected_case_study_candidates.csv", fields)

    lines = [
        "# Case Study Writing Notes",
        "",
        "Use the strict candidate table `topk_by_disease_excluding_all_known.csv` as the primary source. This table excludes both experimentally validated associations and weak-evidence or prediction-derived known associations.",
        "",
        "Recommended cases:",
        "- Chronic lymphocytic leukemia (disease_id=2): the strongest overall ranking in the strict Top-K table, suitable as the main high-confidence case.",
        "- Breast neoplasms (disease_id=35): a familiar cancer scenario with relatively rich tsRNA association background.",
        "- Atherosclerosis (disease_id=120): a non-cancer cardiovascular disease case that helps show EGOCL is not only learning cancer-specific patterns.",
        "",
        "Writing logic:",
        "1. State that candidate associations are derived from full tsRNA-disease scoring by the five-fold EGOCL ensemble, after removing all known and weak-evidence records.",
        "2. Rank candidates by `mean_logit`, because sigmoid probabilities for high-confidence candidates can saturate at 1.0, whereas `mean_logit` better separates strong candidates.",
        "3. Interpret candidate plausibility using local evidence columns: whether the same disease already has experimental associations with the same anticodon, amino acid family, or tsRNA type, and whether the same tsRNA has experimental associations with other diseases.",
        "4. In the main text, report 3-5 candidates per disease; place the complete disease-wise Top-K table in the supplementary materials.",
    ]
    (output_dir / "case_study_draft_en.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[case_summary] wrote {output_dir / 'selected_case_study_candidates.csv'}")
    print(f"[case_summary] wrote {output_dir / 'case_study_draft_en.md'}")


if __name__ == "__main__":
    main()
