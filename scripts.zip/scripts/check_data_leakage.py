from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data_utils import build_exclusion_set, load_graph_tensors
from src.utils import load_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check single-run split leakage.")
    parser.add_argument("--run_dir", default="results/single_run")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    return parser.parse_args()


def load_pair_set(path: Path) -> set[tuple[int, int]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing required split file: {path}")
    rows = load_csv(path)
    return {(int(row["tsrna_id"]), int(row["disease_id"])) for row in rows}


def load_message_edge_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing required message graph file: {path}")
    return load_csv(path)


def print_and_assert_zero(name: str, overlap: set[tuple[int, int]]) -> None:
    print(f"[check_data_leakage] {name}: {len(overlap)}")
    if overlap:
        examples = sorted(overlap)[:10]
        raise RuntimeError(f"{name} is non-zero. First examples: {examples}")


def check_run_dir(run_dir: str | Path, data_dir: str | Path = "data/processed/tensors") -> None:
    run_dir = Path(run_dir)
    train_pos = load_pair_set(run_dir / "train_pos_pairs.csv")
    val_pos = load_pair_set(run_dir / "val_pos_pairs.csv")
    test_pos = load_pair_set(run_dir / "test_pos_pairs.csv")
    train_neg = load_pair_set(run_dir / "train_neg_pairs.csv")
    val_neg = load_pair_set(run_dir / "val_neg_pairs.csv")
    test_neg = load_pair_set(run_dir / "test_neg_pairs.csv")
    message_rows = load_message_edge_rows(run_dir / "message_graph_edges.csv")
    message_edges = {(int(row["tsrna_id"]), int(row["disease_id"])) for row in message_rows}
    weak_source_edges = {
        (int(row["tsrna_id"]), int(row["disease_id"]))
        for row in message_rows
        if row.get("source") == "weak_prediction"
    }

    graph_data = load_graph_tensors(data_dir)
    exclusion = build_exclusion_set(graph_data)
    positives = set(zip(graph_data["pos_tsrna_ids"].tolist(), graph_data["pos_disease_ids"].tolist()))
    weak = set(zip(graph_data["weak_tsrna_ids"].tolist(), graph_data["weak_disease_ids"].tolist()))
    negatives = train_neg | val_neg | test_neg

    print_and_assert_zero("train-val overlap", train_pos & val_pos)
    print_and_assert_zero("train-test overlap", train_pos & test_pos)
    print_and_assert_zero("val-test overlap", val_pos & test_pos)
    print_and_assert_zero("negative-positive overlap", negatives & positives)
    print_and_assert_zero("negative-weak overlap", negatives & weak)
    print_and_assert_zero("negative-exclusion overlap", negatives & exclusion)

    unexpected_message_edges = message_edges - train_pos - weak
    print_and_assert_zero("message graph edges outside train positives or weak edges", unexpected_message_edges)

    val_test_in_message = message_edges & (val_pos | test_pos)
    print_and_assert_zero("val/test positives in message graph", val_test_in_message)

    svd_path = run_dir / "svd_reconstructed_edges.csv"
    if svd_path.exists():
        svd_edges = load_pair_set(svd_path)
        print_and_assert_zero("val/test positives in SVD reconstructed graph", svd_edges & (val_pos | test_pos))
        print_and_assert_zero("weak edges in SVD reconstructed graph", svd_edges & weak)

    print(f"[check_data_leakage] weak-source edges in message graph: {len(weak_source_edges)}")
    print("[check_data_leakage] passed")


def main() -> None:
    args = parse_args()
    check_run_dir(args.run_dir, args.data_dir)


if __name__ == "__main__":
    main()
