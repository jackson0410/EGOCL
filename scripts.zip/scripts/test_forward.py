from __future__ import annotations

import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.models.ego_gnn import EgoGNN


TENSOR_DIR = ROOT / "data" / "processed" / "tensors"


def load_tensor(name: str) -> torch.Tensor:
    return torch.load(TENSOR_DIR / name, map_location="cpu")


def main() -> None:
    with (TENSOR_DIR / "node_counts.json").open("r", encoding="utf-8") as f:
        node_counts = json.load(f)
    with (TENSOR_DIR / "edge_feature_names.json").open("r", encoding="utf-8") as f:
        edge_feature_names = json.load(f)

    graph_data = {
        "pos_tsrna_ids": load_tensor("pos_tsrna_ids.pt"),
        "pos_disease_ids": load_tensor("pos_disease_ids.pt"),
        "pos_edge_features": load_tensor("pos_edge_features.pt"),
        "weak_tsrna_ids": load_tensor("weak_tsrna_ids.pt"),
        "weak_disease_ids": load_tensor("weak_disease_ids.pt"),
        "weak_edge_features": load_tensor("weak_edge_features.pt"),
        "doid_up_edges": load_tensor("doid_up_edges.pt"),
        "doid_down_edges": load_tensor("doid_down_edges.pt"),
        "disease_to_doid_idx": load_tensor("disease_to_doid_idx.pt"),
        "disease_path_indices": load_tensor("disease_path_indices.pt"),
        "disease_path_mask": load_tensor("disease_path_mask.pt"),
    }
    graph_data["edge_tsrna"] = graph_data["pos_tsrna_ids"]
    graph_data["edge_disease"] = graph_data["pos_disease_ids"]
    graph_data["edge_features"] = graph_data["pos_edge_features"]

    torch.manual_seed(42)
    perm = torch.randperm(graph_data["pos_tsrna_ids"].shape[0])[:8]
    batch_tsrna_ids = graph_data["pos_tsrna_ids"][perm]
    batch_disease_ids = graph_data["pos_disease_ids"][perm]

    model = EgoGNN(
        num_tsrna=node_counts["num_tsrna"],
        num_disease=node_counts["num_disease"],
        num_doid=node_counts["num_doid"],
        hidden_dim=64,
        num_layers=2,
        edge_feat_dim=len(edge_feature_names),
        dropout=0.1,
        use_evidence_gate=True,
        use_ontology=True,
        use_path_attention=True,
        use_direction=True,
    )
    model.eval()

    with torch.no_grad():
        logits = model(batch_tsrna_ids, batch_disease_ids, graph_data)

    print(f"[test_forward] batch_tsrna_ids shape: {tuple(batch_tsrna_ids.shape)}")
    print(f"[test_forward] batch_disease_ids shape: {tuple(batch_disease_ids.shape)}")
    print(f"[test_forward] disease_path_indices shape: {tuple(graph_data['disease_path_indices'].shape)}")
    print(f"[test_forward] logits shape: {tuple(logits.shape)}")
    print(f"[test_forward] logits: {logits.tolist()}")


if __name__ == "__main__":
    main()
