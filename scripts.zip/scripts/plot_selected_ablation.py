from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot selected EGO-CLGNN ablation results.")
    parser.add_argument("--ablation_dir", default="results/selected_ablation")
    return parser.parse_args()


def plot_metric(rows: list[dict[str, str]], output_dir: Path, mean_col: str, std_col: str, ylabel: str, output_name: str) -> None:
    labels = [row["variant"] for row in rows]
    means = [float(row[mean_col]) for row in rows]
    stds = [float(row[std_col]) for row in rows]
    fig, ax = plt.subplots(figsize=(max(9, 1.3 * len(labels)), 5.2))
    x = range(len(labels))
    ax.bar(x, means, yerr=stds, capsize=4, color="#4C78A8", edgecolor="#2F3A44", linewidth=0.8)
    ax.set_xticks(list(x))
    ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_ylabel(ylabel)
    ax.set_title(f"Selected Ablation {ylabel}")
    ax.grid(axis="y", alpha=0.25, linewidth=0.6)
    lower = max(0.0, min(means) - max(stds) - 0.02)
    upper = min(1.0, max(means) + max(stds) + 0.02)
    if upper > lower:
        ax.set_ylim(lower, upper)
    fig.tight_layout()
    output_path = output_dir / output_name
    fig.savefig(output_path, dpi=300)
    plt.close(fig)
    print(f"[plot_selected_ablation] wrote {output_path}", flush=True)


def main() -> None:
    args = parse_args()
    ablation_dir = Path(args.ablation_dir)
    summary_path = ablation_dir / "selected_ablation_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(f"Missing selected ablation summary: {summary_path}")
    rows = load_csv(summary_path)
    if not rows:
        raise ValueError(f"No rows found in {summary_path}")

    plot_metric(rows, ablation_dir, "auc_mean", "auc_std", "AUC", "selected_ablation_auc.png")
    plot_metric(rows, ablation_dir, "aupr_mean", "aupr_std", "AUPR", "selected_ablation_aupr.png")
    plot_metric(rows, ablation_dir, "selected_f1_mean", "selected_f1_std", "Selected F1", "selected_ablation_f1.png")
    plot_metric(rows, ablation_dir, "recall_mean", "recall_std", "Recall", "selected_ablation_recall.png")


if __name__ == "__main__":
    main()
