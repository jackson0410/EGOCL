from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import auc, average_precision_score, precision_recall_curve, roc_curve


MODEL_SPECS = [
    ("EGOCL", "EGOCL", "#0072B2"),
    ("DMFCDA-adapted-degree-matched", "DMFCDA", "#E69F00"),
    ("iCircDA-MF-adapted", "iCircDA-MF", "#6A3D9A"),
    ("AGCLNDA-adapted", "AGCLNDA", "#D55E00"),
    ("DualVGAE-adapted", "DualVGAE", "#F0E442"),
    ("MSMCDA-adapted", "MSMCDA", "#009E73"),
    ("HybridGNN-adapted-degree-matched", "HybridGNN", "#7F7F7F"),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot domain baseline ROC/PR curves using the cold-start panel style.")
    parser.add_argument("--baseline_dir", default="results/domain_baselines")
    parser.add_argument("--output_dir", default="results/domain_baselines_corrected_5fold/figures")
    parser.add_argument("--split", default="test")
    return parser.parse_args()


def configure_matplotlib() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 8,
            "axes.titlesize": 11,
            "axes.labelsize": 9,
            "axes.linewidth": 0.75,
            "legend.fontsize": 7,
            "legend.frameon": True,
            "legend.framealpha": 0.95,
            "legend.edgecolor": "#333333",
            "legend.facecolor": "white",
            "legend.borderpad": 0.45,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "grid.color": "#E6E6E6",
            "grid.linewidth": 0.55,
            "grid.linestyle": "--",
        }
    )


def read_predictions(path: Path, split: str) -> tuple[np.ndarray, np.ndarray]:
    labels: list[int] = []
    scores: list[float] = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("split") != split:
                continue
            labels.append(int(float(row["label"])))
            scores.append(float(row["score"]))
    if not labels:
        raise ValueError(f"No predictions for split={split!r} in {path}")
    return np.asarray(labels, dtype=int), np.asarray(scores, dtype=float)


def save_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def save_figure(fig: plt.Figure, out_base: Path) -> None:
    fig.savefig(f"{out_base}.svg", bbox_inches="tight")
    fig.savefig(f"{out_base}.pdf", bbox_inches="tight")
    fig.savefig(f"{out_base}.png", dpi=600, bbox_inches="tight")
    fig.savefig(f"{out_base}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)


def plot_base_axis(ax: plt.Axes) -> None:
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.set_yticks(np.linspace(0, 1, 6))
    ax.grid(True, alpha=0.8)
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)


def main() -> None:
    args = parse_args()
    baseline_dir = Path(args.baseline_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    configure_matplotlib()

    mean_fpr = np.linspace(0.0, 1.0, 501)
    mean_recall = np.linspace(0.0, 1.0, 501)
    model_rows: list[dict[str, object]] = []
    mean_rows: list[dict[str, object]] = []
    roc_panel: list[dict[str, object]] = []
    pr_panel: list[dict[str, object]] = []
    prevalences: list[float] = []

    for model_dir_name, display_name, color in MODEL_SPECS:
        model_dir = baseline_dir / model_dir_name
        fold_dirs = sorted(path for path in model_dir.glob("fold_*") if (path / "predictions.csv").exists())
        if not fold_dirs:
            raise FileNotFoundError(f"No fold_*/predictions.csv files found under {model_dir}")

        roc_interp: list[np.ndarray] = []
        pr_interp: list[np.ndarray] = []
        fold_auc_values: list[float] = []
        fold_aupr_values: list[float] = []
        model_labels: list[np.ndarray] = []

        for fold_dir in fold_dirs:
            labels, scores = read_predictions(fold_dir / "predictions.csv", args.split)
            model_labels.append(labels)

            fpr, tpr, roc_thresholds = roc_curve(labels, scores)
            roc_auc = float(auc(fpr, tpr))
            interp_tpr = np.interp(mean_fpr, fpr, tpr)
            interp_tpr[0] = 0.0
            interp_tpr[-1] = 1.0
            roc_interp.append(interp_tpr)
            fold_auc_values.append(roc_auc)

            precision, recall, pr_thresholds = precision_recall_curve(labels, scores)
            aupr = float(average_precision_score(labels, scores))
            order = np.argsort(recall)
            interp_precision = np.interp(mean_recall, recall[order], precision[order])
            pr_interp.append(np.clip(interp_precision, 0.0, 1.0))
            fold_aupr_values.append(aupr)

            max_len = max(len(fpr), len(recall))
            sorted_recall = recall[order]
            sorted_precision = precision[order]
            for i in range(max_len):
                model_rows.append(
                    {
                        "model": display_name,
                        "source_model": model_dir_name,
                        "fold": fold_dir.name,
                        "roc_fpr": float(fpr[i]) if i < len(fpr) else "",
                        "roc_tpr": float(tpr[i]) if i < len(tpr) else "",
                        "roc_threshold": float(roc_thresholds[i]) if i < len(roc_thresholds) else "",
                        "roc_auc": roc_auc,
                        "pr_recall": float(sorted_recall[i]) if i < len(sorted_recall) else "",
                        "pr_precision": float(sorted_precision[i]) if i < len(sorted_precision) else "",
                        "pr_threshold": float(pr_thresholds[i]) if i < len(pr_thresholds) else "",
                        "aupr": aupr,
                    }
                )

        mean_tpr = np.mean(roc_interp, axis=0)
        mean_tpr[0] = 0.0
        mean_tpr[-1] = 1.0
        mean_precision = np.clip(np.mean(pr_interp, axis=0), 0.0, 1.0)
        mean_auc = float(np.mean(fold_auc_values))
        mean_aupr = float(np.mean(fold_aupr_values))
        prevalences.append(float(np.mean(np.concatenate(model_labels))))

        roc_panel.append(
            {
                "model": display_name,
                "color": color,
                "x": mean_fpr,
                "y": mean_tpr,
                "metric": mean_auc,
            }
        )
        pr_panel.append(
            {
                "model": display_name,
                "color": color,
                "x": mean_recall,
                "y": mean_precision,
                "metric": mean_aupr,
            }
        )

        for x_roc, y_roc, x_pr, y_pr in zip(mean_fpr, mean_tpr, mean_recall, mean_precision):
            mean_rows.append(
                {
                    "model": display_name,
                    "source_model": model_dir_name,
                    "fpr": float(x_roc),
                    "mean_tpr": float(y_roc),
                    "recall": float(x_pr),
                    "mean_precision": float(y_pr),
                    "auc": mean_auc,
                    "aupr": mean_aupr,
                }
            )

    fig_roc, ax_roc = plt.subplots(figsize=(5.3, 4.25))
    plot_base_axis(ax_roc)
    for item in roc_panel:
        ax_roc.plot(item["x"], item["y"], color=item["color"], lw=1.25, label=f'{item["model"]} ($AUC$ = {item["metric"]:.4f})')
    ax_roc.plot([0, 1], [0, 1], color="#BFBFBF", lw=0.8, ls="--", zorder=0)
    ax_roc.set_title("Receiver Operating Characteristic Curve", pad=8)
    ax_roc.set_xlabel("False Positive Rate")
    ax_roc.set_ylabel("True Positive Rate")
    ax_roc.legend(loc="lower right", frameon=True)
    fig_roc.tight_layout()
    save_figure(fig_roc, output_dir / "domain_baseline_roc_curve")

    fig_pr, ax_pr = plt.subplots(figsize=(5.3, 4.25))
    plot_base_axis(ax_pr)
    for item in pr_panel:
        ax_pr.plot(item["x"], item["y"], color=item["color"], lw=1.25, label=f'{item["model"]} ($AUPR$ = {item["metric"]:.4f})')
    ax_pr.axhline(float(np.mean(prevalences)), color="#BFBFBF", lw=0.8, ls="--", zorder=0)
    ax_pr.set_title("Precision-Recall Curve", pad=8)
    ax_pr.set_xlabel("Recall")
    ax_pr.set_ylabel("Precision")
    ax_pr.legend(loc="lower right", frameon=True)
    fig_pr.tight_layout()
    save_figure(fig_pr, output_dir / "domain_baseline_pr_curve")

    fig_combo, (ax_combo_roc, ax_combo_pr) = plt.subplots(1, 2, figsize=(10.8, 4.15))
    fig_combo.subplots_adjust(left=0.065, right=0.985, bottom=0.17, top=0.86, wspace=0.13)

    plot_base_axis(ax_combo_roc)
    for item in roc_panel:
        ax_combo_roc.plot(
            item["x"],
            item["y"],
            color=item["color"],
            lw=1.05,
            label=f'{item["model"]} ($AUC$ = {item["metric"]:.4f})',
        )
    ax_combo_roc.plot([0, 1], [0, 1], color="#BFBFBF", lw=0.8, ls="--", zorder=0)
    ax_combo_roc.set_title("Receiver Operating Characteristic Curve", pad=8)
    ax_combo_roc.set_xlabel("False Positive Rate")
    ax_combo_roc.set_ylabel("True Positive Rate")
    ax_combo_roc.legend(loc="lower right", frameon=True, fontsize=6.4)

    plot_base_axis(ax_combo_pr)
    for item in pr_panel:
        ax_combo_pr.plot(
            item["x"],
            item["y"],
            color=item["color"],
            lw=1.05,
            label=f'{item["model"]} ($AUPR$ = {item["metric"]:.4f})',
        )
    ax_combo_pr.axhline(float(np.mean(prevalences)), color="#BFBFBF", lw=0.8, ls="--", zorder=0)
    ax_combo_pr.set_title("Precision-Recall Curve", pad=8)
    ax_combo_pr.set_xlabel("Recall")
    ax_combo_pr.set_ylabel("Precision")
    ax_combo_pr.legend(loc="lower right", frameon=True, fontsize=6.4)

    ax_combo_roc.text(0.5, -0.18, "(a)", transform=ax_combo_roc.transAxes, ha="center", va="center", fontsize=14)
    ax_combo_pr.text(0.5, -0.18, "(b)", transform=ax_combo_pr.transAxes, ha="center", va="center", fontsize=14)
    save_figure(fig_combo, output_dir / "domain_baseline_roc_pr_curves")

    fields = [
        "model",
        "source_model",
        "fold",
        "roc_fpr",
        "roc_tpr",
        "roc_threshold",
        "roc_auc",
        "pr_recall",
        "pr_precision",
        "pr_threshold",
        "aupr",
    ]
    save_csv(output_dir / "domain_baseline_curve_fold_source.csv", model_rows, fields)
    save_csv(output_dir / "domain_baseline_curve_mean_source.csv", mean_rows, list(mean_rows[0]))

    print(f"[plot_domain_baseline_curves_nature_style] wrote {output_dir / 'domain_baseline_roc_curve'}.*")
    print(f"[plot_domain_baseline_curves_nature_style] wrote {output_dir / 'domain_baseline_pr_curve'}.*")
    print(f"[plot_domain_baseline_curves_nature_style] wrote {output_dir / 'domain_baseline_roc_pr_curves'}.*")


if __name__ == "__main__":
    main()
