from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import ensure_dir, load_csv, save_csv


SUMMARY_FIELDS = [
    "fold_id",
    "best_epoch",
    "best_val_aupr",
    "test_auc",
    "test_aupr",
    "test_selected_threshold_f1",
    "test_oracle_best_f1",
    "val_selected_threshold",
]

OPTIONAL_SUMMARY_FIELDS = [
    "test_selected_threshold_precision",
    "test_selected_threshold_recall",
    "test_best_precision",
    "test_best_recall",
    "test_best_f1",
    "test_best_threshold",
    "test_best_threshold_method",
    "test_positive_score_mean",
    "test_negative_score_mean",
    "best_temperature",
    "test_calibrated_auc",
    "test_calibrated_aupr",
    "test_calibrated_selected_f1",
    "test_calibrated_precision",
    "test_calibrated_recall",
    "test_calibrated_threshold",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize CV fold metrics.")
    parser.add_argument("--cv_dir", default="results/cv")
    return parser.parse_args()


def fold_id_from_dir(path: Path) -> int:
    try:
        return int(path.name.split("_")[-1])
    except ValueError as exc:
        raise ValueError(f"Cannot parse fold id from {path}") from exc


def summarize_cv(cv_dir: str | Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    cv_dir = ensure_dir(cv_dir)
    fold_dirs = sorted((path for path in Path(cv_dir).glob("fold_*") if path.is_dir()), key=fold_id_from_dir)
    if not fold_dirs:
        raise FileNotFoundError(f"No fold directories found under {cv_dir}")

    summary_rows = []
    output_fields = SUMMARY_FIELDS.copy()
    for fold_dir in fold_dirs:
        metrics_path = fold_dir / "metrics.csv"
        if not metrics_path.exists():
            raise FileNotFoundError(f"Missing metrics file: {metrics_path}")
        metrics = load_csv(metrics_path)[0]
        row = {
            "fold_id": fold_id_from_dir(fold_dir),
            "best_epoch": int(float(metrics["best_epoch"])),
            "best_val_aupr": float(metrics["best_val_aupr"]),
            "test_auc": float(metrics["test_auc"]),
            "test_aupr": float(metrics["test_aupr"]),
            "test_selected_threshold_f1": float(metrics["test_selected_threshold_f1"]),
            "test_oracle_best_f1": float(metrics["test_oracle_best_f1"]),
            "val_selected_threshold": float(metrics["val_selected_threshold"]),
        }
        for field in OPTIONAL_SUMMARY_FIELDS:
            if field in metrics:
                row[field] = metrics[field] if field.endswith("_method") else float(metrics[field])
                if field not in output_fields:
                    output_fields.append(field)
        summary_rows.append(row)

    mean_std_rows = []
    for field in output_fields:
        if field == "fold_id":
            continue
        if field.endswith("_method"):
            continue
        values = [float(row[field]) for row in summary_rows]
        mean = sum(values) / len(values)
        if len(values) > 1:
            variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
            std = math.sqrt(variance)
        else:
            std = 0.0
        mean_std_rows.append({"metric": field, "mean": mean, "std": std})

    save_csv(summary_rows, Path(cv_dir) / "cv_summary.csv", output_fields)
    save_csv(mean_std_rows, Path(cv_dir) / "cv_mean_std.csv", ["metric", "mean", "std"])
    return summary_rows, mean_std_rows


def main() -> None:
    args = parse_args()
    summary_rows, _ = summarize_cv(args.cv_dir)
    print(f"[summarize_cv] summarized folds: {len(summary_rows)}")
    print(f"[summarize_cv] outputs written to: {Path(args.cv_dir)}")


if __name__ == "__main__":
    main()
