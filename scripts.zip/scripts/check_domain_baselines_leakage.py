from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.check_data_leakage import check_run_dir
from src.data_utils import build_exclusion_set, load_graph_tensors
from src.utils import load_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check leakage for adapted domain baselines.")
    parser.add_argument("--baseline_dir", default="results/domain_baselines")
    parser.add_argument("--data_dir", default="data/processed/tensors")
    return parser.parse_args()


def pairs_from_csv(path: Path) -> set[tuple[int, int]]:
    return {(int(row["tsrna_id"]), int(row["disease_id"])) for row in load_csv(path)}


def check_common_fold(common_fold: Path, fold_dir: Path, exclusion_set: set[tuple[int, int]]) -> None:
    train_matrix_path = common_fold / "train_matrix.npy"
    if not train_matrix_path.exists():
        return
    matrix = np.load(train_matrix_path)
    train_pos = pairs_from_csv(fold_dir / "train_pos_pairs.csv")
    val_pos = pairs_from_csv(fold_dir / "val_pos_pairs.csv")
    test_pos = pairs_from_csv(fold_dir / "test_pos_pairs.csv")
    train_neg = pairs_from_csv(fold_dir / "train_neg_pairs.csv")
    val_neg = pairs_from_csv(fold_dir / "val_neg_pairs.csv")
    test_neg = pairs_from_csv(fold_dir / "test_neg_pairs.csv")
    negatives = train_neg | val_neg | test_neg
    if negatives & exclusion_set:
        raise AssertionError(f"Negatives overlap Experimental positives or weak edges in {fold_dir}")
    for pair in train_pos:
        if matrix[pair[0], pair[1]] != 1:
            raise AssertionError(f"Train positive missing from train_matrix in {fold_dir}: {pair}")
    for pair in val_pos | test_pos:
        if matrix[pair[0], pair[1]] != 0:
            raise AssertionError(f"Val/test positive leaked into train_matrix in {fold_dir}: {pair}")

    for name in ["tsrna_gip_similarity.npy", "disease_gip_similarity.npy", "tsrna_similarity.npy", "disease_similarity.npy"]:
        if not (common_fold / name).exists():
            raise FileNotFoundError(f"Missing common similarity file: {common_fold / name}")


def check_dmfcda_fold(fold_dir: Path, graph_data: dict[str, object]) -> None:
    matrix_path = fold_dir / "train_matrix.npy"
    if not matrix_path.exists():
        raise FileNotFoundError(f"Missing DMFCDA train_matrix: {matrix_path}")
    matrix = np.load(matrix_path)
    val_pos = pairs_from_csv(fold_dir / "val_pos_pairs.csv")
    test_pos = pairs_from_csv(fold_dir / "test_pos_pairs.csv")
    weak_pairs = set(zip(graph_data["weak_tsrna_ids"].long().tolist(), graph_data["weak_disease_ids"].long().tolist()))
    positive_pairs = set(zip(graph_data["pos_tsrna_ids"].long().tolist(), graph_data["pos_disease_ids"].long().tolist()))
    weak_only_pairs = weak_pairs - positive_pairs
    for pair in val_pos | test_pos:
        if matrix[pair[0], pair[1]] != 0:
            raise AssertionError(f"DMFCDA train_matrix contains held-out positive in {fold_dir}: {pair}")
    leaked_weak = [
        pair
        for pair in weak_only_pairs
        if pair[0] < matrix.shape[0] and pair[1] < matrix.shape[1] and matrix[pair[0], pair[1]] != 0
    ]
    if leaked_weak:
        raise AssertionError(f"DMFCDA train_matrix contains weak edge(s) in {fold_dir}: {leaked_weak[:10]}")

    audit_path = fold_dir / "dmfcda_mask_audit.csv"
    if not audit_path.exists():
        raise FileNotFoundError(f"Missing DMFCDA mask audit: {audit_path}")
    for row in load_csv(audit_path):
        if float(row["masked_t_value"]) != 0.0 or float(row["masked_d_value"]) != 0.0:
            raise AssertionError(f"DMFCDA candidate pair was not masked in {audit_path}: {row}")
    print("DMFCDA-adapted leakage check passed", flush=True)


def gip_similarity_no_print(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.sum(matrix * matrix, axis=1)
    mean_norm = float(np.mean(norms[norms > 0])) if np.any(norms > 0) else 1.0
    gamma = 1.0 / max(mean_norm, 1e-8)
    gram = matrix @ matrix.T
    dist2 = norms[:, None] + norms[None, :] - 2.0 * gram
    sim = np.exp(-gamma * np.maximum(dist2, 0.0)).astype(np.float32)
    np.fill_diagonal(sim, 1.0)
    return sim


def check_hybridgnn_fold(common_fold: Path, fold_dir: Path, graph_data: dict[str, object]) -> None:
    required = [
        "train_matrix.npy",
        "tsrna_similarity.npy",
        "disease_similarity.npy",
        "tsrna_gip_similarity.npy",
        "disease_gip_similarity.npy",
        "heterogeneous_adjacency.npy",
    ]
    for name in required:
        if not (fold_dir / name).exists():
            raise FileNotFoundError(f"Missing HybridGNN artifact: {fold_dir / name}")
        if not (common_fold / name).exists():
            raise FileNotFoundError(f"Missing common HybridGNN artifact: {common_fold / name}")

    matrix = np.load(fold_dir / "train_matrix.npy")
    common_matrix = np.load(common_fold / "train_matrix.npy")
    if not np.array_equal(matrix, common_matrix):
        raise AssertionError(f"HybridGNN train_matrix differs from common train-only matrix in {fold_dir}")

    val_pos = pairs_from_csv(fold_dir / "val_pos_pairs.csv")
    test_pos = pairs_from_csv(fold_dir / "test_pos_pairs.csv")
    weak_pairs = set(zip(graph_data["weak_tsrna_ids"].long().tolist(), graph_data["weak_disease_ids"].long().tolist()))
    positive_pairs = set(zip(graph_data["pos_tsrna_ids"].long().tolist(), graph_data["pos_disease_ids"].long().tolist()))
    weak_only_pairs = weak_pairs - positive_pairs
    for pair in val_pos | test_pos:
        if matrix[pair[0], pair[1]] != 0:
            raise AssertionError(f"HybridGNN train_matrix contains held-out positive in {fold_dir}: {pair}")
    leaked_weak = [
        pair
        for pair in weak_only_pairs
        if pair[0] < matrix.shape[0] and pair[1] < matrix.shape[1] and matrix[pair[0], pair[1]] != 0
    ]
    if leaked_weak:
        raise AssertionError(f"HybridGNN train_matrix contains weak-only pair(s) in {fold_dir}: {leaked_weak[:10]}")

    tsrna_gip = np.load(fold_dir / "tsrna_gip_similarity.npy")
    disease_gip = np.load(fold_dir / "disease_gip_similarity.npy")
    if not np.allclose(tsrna_gip, gip_similarity_no_print(matrix), atol=1e-5):
        raise AssertionError(f"HybridGNN tsRNA GIP similarity is not train-matrix-derived in {fold_dir}")
    if not np.allclose(disease_gip, gip_similarity_no_print(matrix.T), atol=1e-5):
        raise AssertionError(f"HybridGNN disease GIP similarity is not train-matrix-derived in {fold_dir}")

    tsrna_similarity = np.load(fold_dir / "tsrna_similarity.npy")
    disease_similarity = np.load(fold_dir / "disease_similarity.npy")
    adjacency = np.load(fold_dir / "heterogeneous_adjacency.npy")
    num_tsrna, num_disease = matrix.shape
    expected_shape = (num_tsrna + num_disease, num_tsrna + num_disease)
    if adjacency.shape != expected_shape:
        raise AssertionError(f"HybridGNN heterogeneous adjacency shape mismatch in {fold_dir}: {adjacency.shape}")
    if not np.allclose(adjacency[:num_tsrna, :num_tsrna], tsrna_similarity, atol=1e-6):
        raise AssertionError(f"HybridGNN adjacency tsRNA block mismatch in {fold_dir}")
    if not np.allclose(adjacency[:num_tsrna, num_tsrna:], matrix, atol=1e-6):
        raise AssertionError(f"HybridGNN adjacency association block contains non-train data in {fold_dir}")
    if not np.allclose(adjacency[num_tsrna:, :num_tsrna], matrix.T, atol=1e-6):
        raise AssertionError(f"HybridGNN adjacency transpose association block contains non-train data in {fold_dir}")
    if not np.allclose(adjacency[num_tsrna:, num_tsrna:], disease_similarity, atol=1e-6):
        raise AssertionError(f"HybridGNN adjacency disease block mismatch in {fold_dir}")

    print("HybridGNN-adapted leakage check passed", flush=True)


def topk_indices_weights(similarity: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray]:
    n = similarity.shape[0]
    k = max(1, min(k, max(1, n - 1)))
    indices = np.zeros((n, k), dtype=np.int64)
    weights = np.zeros((n, k), dtype=np.float32)
    for i in range(n):
        row = similarity[i]
        candidate_count = min(k + 1, n)
        candidates = np.argpartition(-row, candidate_count - 1)[:candidate_count]
        candidates = candidates[candidates != i]
        if candidates.size < k:
            extra = np.argsort(-row)
            candidates = np.asarray([idx for idx in extra if idx != i], dtype=np.int64)
        selected = candidates[np.argsort(-row[candidates])[:k]]
        indices[i, : selected.size] = selected
        weights[i, : selected.size] = row[selected]
    return indices, weights


def reformulate_matrix_for_check(train_matrix: np.ndarray, tsrna_similarity: np.ndarray, disease_similarity: np.ndarray, neighbor_k: int) -> np.ndarray:
    t_idx, t_w = topk_indices_weights(tsrna_similarity, neighbor_k)
    d_idx, d_w = topk_indices_weights(disease_similarity, neighbor_k)
    t_denom = np.maximum(t_w.sum(axis=1), 1e-8)
    a_t = ((t_w[:, :, None] * train_matrix[t_idx]).sum(axis=1) / t_denom[:, None]).astype(np.float32)
    a_d = np.zeros_like(train_matrix, dtype=np.float32)
    for j in range(train_matrix.shape[1]):
        denom = max(float(d_w[j].sum()), 1e-8)
        a_d[:, j] = (train_matrix[:, d_idx[j]] * d_w[j][None, :]).sum(axis=1) / denom
    return np.maximum(train_matrix, (a_t + a_d) / 2.0).astype(np.float32)


def check_icircda_fold(common_fold: Path, fold_dir: Path, graph_data: dict[str, object]) -> None:
    required = [
        "train_matrix.npy",
        "tsrna_similarity.npy",
        "disease_similarity.npy",
        "disease_gip_similarity.npy",
        "disease_semantic_similarity.npy",
        "reformulated_matrix.npy",
        "score_matrix.npy",
    ]
    for name in required:
        if not (fold_dir / name).exists():
            raise FileNotFoundError(f"Missing iCircDA-MF artifact: {fold_dir / name}")

    matrix = np.load(fold_dir / "train_matrix.npy")
    common_matrix = np.load(common_fold / "train_matrix.npy")
    if not np.array_equal(matrix, common_matrix):
        raise AssertionError(f"iCircDA-MF train_matrix differs from common train-only matrix in {fold_dir}")

    val_pos = pairs_from_csv(fold_dir / "val_pos_pairs.csv")
    test_pos = pairs_from_csv(fold_dir / "test_pos_pairs.csv")
    weak_pairs = set(zip(graph_data["weak_tsrna_ids"].long().tolist(), graph_data["weak_disease_ids"].long().tolist()))
    positive_pairs = set(zip(graph_data["pos_tsrna_ids"].long().tolist(), graph_data["pos_disease_ids"].long().tolist()))
    weak_only_pairs = weak_pairs - positive_pairs
    for pair in val_pos | test_pos:
        if matrix[pair[0], pair[1]] != 0:
            raise AssertionError(f"iCircDA-MF train_matrix contains held-out positive in {fold_dir}: {pair}")
    leaked_weak = [
        pair
        for pair in weak_only_pairs
        if pair[0] < matrix.shape[0] and pair[1] < matrix.shape[1] and matrix[pair[0], pair[1]] != 0
    ]
    if leaked_weak:
        raise AssertionError(f"iCircDA-MF train_matrix contains weak-only pair(s) in {fold_dir}: {leaked_weak[:10]}")

    tsrna_similarity = np.load(fold_dir / "tsrna_similarity.npy")
    disease_gip = np.load(fold_dir / "disease_gip_similarity.npy")
    disease_similarity = np.load(fold_dir / "disease_similarity.npy")
    if not np.allclose(tsrna_similarity, gip_similarity_no_print(matrix), atol=1e-5):
        raise AssertionError(f"iCircDA-MF tsRNA similarity is not train-matrix-derived in {fold_dir}")
    if not np.allclose(disease_gip, gip_similarity_no_print(matrix.T), atol=1e-5):
        raise AssertionError(f"iCircDA-MF disease GIP similarity is not train-matrix-derived in {fold_dir}")
    if not np.allclose(disease_similarity, np.load(common_fold / "disease_similarity.npy"), atol=1e-6):
        raise AssertionError(f"iCircDA-MF disease similarity differs from common train-only similarity in {fold_dir}")

    config_path = fold_dir / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"Missing iCircDA-MF config: {config_path}")
    import json

    neighbor_k = int(json.loads(config_path.read_text(encoding="utf-8")).get("neighbor_k", 2))
    expected_reformulated = reformulate_matrix_for_check(matrix, tsrna_similarity, disease_similarity, neighbor_k)
    observed_reformulated = np.load(fold_dir / "reformulated_matrix.npy")
    if not np.allclose(observed_reformulated, expected_reformulated, atol=1e-6):
        raise AssertionError(f"iCircDA-MF reformulated_matrix is not derived from train-only matrix/similarity in {fold_dir}")
    score_matrix = np.load(fold_dir / "score_matrix.npy")
    if score_matrix.shape != matrix.shape:
        raise AssertionError(f"iCircDA-MF score_matrix shape mismatch in {fold_dir}: {score_matrix.shape}")
    print("iCircDA-MF-adapted leakage check passed", flush=True)


def main() -> None:
    args = parse_args()
    baseline_dir = Path(args.baseline_dir)
    if not baseline_dir.exists():
        raise FileNotFoundError(f"Missing baseline dir: {baseline_dir}")
    graph_data = load_graph_tensors(args.data_dir)
    exclusion_set = build_exclusion_set(graph_data)
    common_data = baseline_dir / "common_data"
    checked = 0
    for model_dir in sorted(path for path in baseline_dir.iterdir() if path.is_dir() and path.name != "common_data"):
        for fold_dir in sorted(path for path in model_dir.glob("fold_*") if path.is_dir()):
            required_split = fold_dir / "train_pos_pairs.csv"
            if not required_split.exists():
                print(
                    f"[check_domain_baselines_leakage] skipping incomplete {model_dir.name}/{fold_dir.name}: "
                    f"missing {required_split.name}",
                    flush=True,
                )
                continue
            print(f"[check_domain_baselines_leakage] checking {model_dir.name}/{fold_dir.name}", flush=True)
            check_run_dir(fold_dir, args.data_dir)
            check_common_fold(common_data / fold_dir.name, fold_dir, exclusion_set)
            if model_dir.name.startswith("DMFCDA-adapted"):
                check_dmfcda_fold(fold_dir, graph_data)
            if model_dir.name.startswith("HybridGNN-adapted"):
                check_hybridgnn_fold(common_data / fold_dir.name, fold_dir, graph_data)
            if model_dir.name == "iCircDA-MF-adapted":
                check_icircda_fold(common_data / fold_dir.name, fold_dir, graph_data)
            checked += 1
    if checked == 0:
        raise FileNotFoundError(f"No model fold directories found under {baseline_dir}")
    print("all domain baseline folds passed leakage check", flush=True)


if __name__ == "__main__":
    main()
