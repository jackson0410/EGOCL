from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
from scipy.stats import ttest_rel, wilcoxon

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv, save_csv


METRICS = [
    "test_auc",
    "test_aupr",
    "test_selected_threshold_f1",
    "test_selected_threshold_recall",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run paired significance tests for selected ablations.")
    parser.add_argument("--ablation_dir", default="results/selected_ablation")
    parser.add_argument("--comparison_dir", default=None)
    parser.add_argument("--full_model_name", default=None)
    return parser.parse_args()


def load_fold_metrics(variant_dir: Path) -> dict[int, dict[str, float]]:
    summary_path = variant_dir / "cv_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(f"Missing CV summary: {summary_path}")
    rows = load_csv(summary_path)
    return {
        int(row["fold_id"]): {
            metric: float(row[metric])
            for metric in METRICS
            if metric in row and row[metric] != ""
        }
        for row in rows
    }


def safe_paired_ttest(full_values: np.ndarray, ablated_values: np.ndarray) -> float:
    if full_values.size < 2:
        return float("nan")
    result = ttest_rel(full_values, ablated_values, nan_policy="omit")
    return float(result.pvalue) if not math.isnan(float(result.pvalue)) else float("nan")


def safe_wilcoxon(full_values: np.ndarray, ablated_values: np.ndarray) -> float:
    if full_values.size < 2:
        return float("nan")
    try:
        result = wilcoxon(full_values, ablated_values, zero_method="wilcox", alternative="two-sided")
        return float(result.pvalue)
    except ValueError:
        return 1.0


def resolve_full_model_name(comparison_dir: Path, requested: str | None) -> str:
    if requested:
        return requested
    if (comparison_dir / "Full_EGO_CLGNN").exists():
        return "Full_EGO_CLGNN"
    if (comparison_dir / "EGO-CLGNN").exists():
        return "EGO-CLGNN"
    raise FileNotFoundError(f"Cannot find full model directory under {comparison_dir}")


def run_tests(ablation_dir: Path, full_model_name: str | None = None) -> list[dict[str, object]]:
    full_name = resolve_full_model_name(ablation_dir, full_model_name)
    full_dir = ablation_dir / full_name
    if not full_dir.exists():
        raise FileNotFoundError(f"Missing full model directory: {full_dir}")
    full = load_fold_metrics(full_dir)
    variant_dirs = sorted(path for path in ablation_dir.iterdir() if path.is_dir() and path.name not in {full_name, "common_data"})
    rows = []

    for variant_dir in variant_dirs:
        ablated = load_fold_metrics(variant_dir)
        common_folds = sorted(set(full) & set(ablated))
        if not common_folds:
            raise ValueError(f"No common folds between Full_EGO_CLGNN and {variant_dir.name}")
        for metric in METRICS:
            full_values = np.asarray([full[fold][metric] for fold in common_folds], dtype=float)
            ablated_values = np.asarray([ablated[fold][metric] for fold in common_folds], dtype=float)
            delta = full_values - ablated_values
            t_p = safe_paired_ttest(full_values, ablated_values)
            w_p = safe_wilcoxon(full_values, ablated_values)
            rows.append(
                {
                    "comparison": f"{full_name}_vs_{variant_dir.name}",
                    "metric": metric,
                    "full_mean": float(full_values.mean()),
                    "ablated_mean": float(ablated_values.mean()),
                    "delta_mean": float(delta.mean()),
                    "paired_t_pvalue": t_p,
                    "wilcoxon_pvalue": w_p,
                    "significant_0_05_ttest": bool(t_p < 0.05) if not math.isnan(t_p) else False,
                    "significant_0_05_wilcoxon": bool(w_p < 0.05) if not math.isnan(w_p) else False,
                }
            )
    return rows


def write_markdown(rows: list[dict[str, object]], output_path: Path) -> None:
    lines = [
        "# Paired significance tests",
        "",
        "Paired tests compare the full/reference model against each comparison model across matched folds.",
        "",
        "| comparison | metric | full mean | ablated mean | delta | paired t p | Wilcoxon p |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {comparison} | {metric} | {full_mean:.6f} | {ablated_mean:.6f} | {delta_mean:.6f} | {paired_t_pvalue:.6g} | {wilcoxon_pvalue:.6g} |".format(
                **row
            )
        )
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    ablation_dir = Path(args.comparison_dir or args.ablation_dir)
    if not ablation_dir.exists():
        raise FileNotFoundError(f"Missing ablation directory: {ablation_dir}")
    rows = run_tests(ablation_dir, args.full_model_name)
    fields = [
        "comparison",
        "metric",
        "full_mean",
        "ablated_mean",
        "delta_mean",
        "paired_t_pvalue",
        "wilcoxon_pvalue",
        "significant_0_05_ttest",
        "significant_0_05_wilcoxon",
    ]
    save_csv(rows, ablation_dir / "significance_tests.csv", fields)
    write_markdown(rows, ablation_dir / "significance_summary.md")
    print(f"[significance_tests] wrote {ablation_dir / 'significance_tests.csv'}", flush=True)
    print(f"[significance_tests] wrote {ablation_dir / 'significance_summary.md'}", flush=True)


if __name__ == "__main__":
    main()
