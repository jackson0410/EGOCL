from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset
from sklearn.metrics import auc, average_precision_score, precision_recall_curve, roc_curve


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Split cold-start ROC and PR into two independent Nature-style figures.")
    parser.add_argument("--result_dir", default="results/egocl_cold_start")
    parser.add_argument("--output_dir", default="results/egocl_cold_start/figures")
    parser.add_argument("--split", default="test")
    parser.add_argument("--roc_prefix", default="egocl_cold_start_roc_curve")
    parser.add_argument("--pr_prefix", default="egocl_cold_start_pr_curve")
    return parser.parse_args()


def read_predictions(path: Path, split: str) -> tuple[np.ndarray, np.ndarray]:
    labels: list[int] = []
    scores: list[float] = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("split") != split:
                continue
            labels.append(int(float(row["label"])))
            scores.append(float(row["score"]))
    if not labels:
        raise ValueError(f"No predictions for split={split!r} in {path}")
    return np.asarray(labels, dtype=int), np.asarray(scores, dtype=float)


def configure_matplotlib() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "font.size": 8,
            "axes.titlesize": 11,
            "axes.labelsize": 9,
            "axes.linewidth": 0.75,
            "legend.fontsize": 7,
            "legend.frameon": True,
            "legend.framealpha": 0.95,
            "legend.edgecolor": "#333333",
            "legend.facecolor": "white",
            "legend.borderpad": 0.45,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "xtick.major.width": 0.7,
            "ytick.major.width": 0.7,
            "grid.color": "#E6E6E6",
            "grid.linewidth": 0.55,
            "grid.linestyle": "--",
        }
    )


def style_axis(ax: plt.Axes) -> None:
    ax.grid(True, alpha=0.8)
    ax.set_xlim(0.0, 1.0)
    ax.set_ylim(0.0, 1.0)
    ax.set_xticks(np.linspace(0, 1, 6))
    ax.set_yticks(np.linspace(0, 1, 6))
    for spine in ax.spines.values():
        spine.set_linewidth(0.75)


def add_inset_style(ax: plt.Axes) -> None:
    ax.grid(True, alpha=0.75)
    for spine in ax.spines.values():
        spine.set_linestyle(":")
        spine.set_linewidth(0.7)
        spine.set_edgecolor("black")
    ax.tick_params(labelleft=False, labelbottom=False, length=0)


def mark_zoom(parent: plt.Axes, inset: plt.Axes, loc1: int, loc2: int) -> None:
    patch, conn1, conn2 = mark_inset(parent, inset, loc1=loc1, loc2=loc2, fc="none", ec="black", lw=0.7)
    patch.set_linestyle(":")
    patch.set_zorder(2)
    for connector in (conn1, conn2):
        connector.set_color("#BFBFBF")
        connector.set_linestyle("--")
        connector.set_linewidth(0.75)
        connector.set_zorder(0.5)


def save_figure(fig: plt.Figure, out_base: Path) -> None:
    fig.savefig(f"{out_base}.svg", bbox_inches="tight")
    fig.savefig(f"{out_base}.pdf", bbox_inches="tight")
    fig.savefig(f"{out_base}.png", dpi=600, bbox_inches="tight")
    fig.savefig(f"{out_base}.tiff", dpi=600, bbox_inches="tight")
    plt.close(fig)


def save_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    result_dir = Path(args.result_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    configure_matplotlib()

    fold_dirs = sorted(path for path in result_dir.glob("fold_*") if (path / "predictions.csv").exists())
    if not fold_dirs:
        raise FileNotFoundError(f"No fold_*/predictions.csv files found under {result_dir}")

    colors = ["#66C2A5", "#FC8D62", "#8DA0CB", "#E78AC3", "#A6D854"]
    mean_fpr = np.linspace(0.0, 1.0, 401)
    mean_recall = np.linspace(0.0, 1.0, 401)

    roc_curves: list[tuple[np.ndarray, np.ndarray, float]] = []
    pr_curves: list[tuple[np.ndarray, np.ndarray, float]] = []
    roc_interp: list[np.ndarray] = []
    pr_interp: list[np.ndarray] = []
    fold_rows: list[dict[str, object]] = []

    for fold_dir in fold_dirs:
        labels, scores = read_predictions(fold_dir / "predictions.csv", args.split)

        fpr, tpr, roc_thresholds = roc_curve(labels, scores)
        roc_auc = float(auc(fpr, tpr))
        roc_curves.append((fpr, tpr, roc_auc))
        interp_tpr = np.interp(mean_fpr, fpr, tpr)
        interp_tpr[0] = 0.0
        interp_tpr[-1] = 1.0
        roc_interp.append(interp_tpr)

        precision, recall, pr_thresholds = precision_recall_curve(labels, scores)
        aupr = float(average_precision_score(labels, scores))
        pr_curves.append((recall, precision, aupr))
        order = np.argsort(recall)
        interp_precision = np.interp(mean_recall, recall[order], precision[order])
        pr_interp.append(np.clip(interp_precision, 0.0, 1.0))

        max_len = max(len(fpr), len(recall))
        for i in range(max_len):
            fold_rows.append(
                {
                    "fold": fold_dir.name,
                    "roc_fpr": float(fpr[i]) if i < len(fpr) else "",
                    "roc_tpr": float(tpr[i]) if i < len(tpr) else "",
                    "roc_threshold": float(roc_thresholds[i]) if i < len(roc_thresholds) else "",
                    "roc_auc": roc_auc,
                    "pr_recall": float(recall[i]) if i < len(recall) else "",
                    "pr_precision": float(precision[i]) if i < len(precision) else "",
                    "pr_threshold": float(pr_thresholds[i]) if i < len(pr_thresholds) else "",
                    "aupr": aupr,
                }
            )

    mean_tpr = np.mean(roc_interp, axis=0)
    mean_tpr[0] = 0.0
    mean_tpr[-1] = 1.0
    mean_auc = float(np.mean([curve[2] for curve in roc_curves]))
    std_auc = float(np.std([curve[2] for curve in roc_curves], ddof=1))

    mean_precision = np.clip(np.mean(pr_interp, axis=0), 0.0, 1.0)
    mean_aupr = float(np.mean([curve[2] for curve in pr_curves]))
    std_aupr = float(np.std([curve[2] for curve in pr_curves], ddof=1))

    fig_roc, ax_roc = plt.subplots(figsize=(5.3, 4.25))
    style_axis(ax_roc)
    for i, (fpr, tpr, roc_auc) in enumerate(roc_curves):
        ax_roc.plot(fpr, tpr, color=colors[i % len(colors)], lw=1.0, label=f"ROC fold {i + 1} (AUC = {roc_auc:.4f})")
    ax_roc.plot(
        mean_fpr,
        mean_tpr,
        color="black",
        lw=1.5,
        label=rf"Mean ROC (AUC = {mean_auc:.4f}$\pm${std_auc:.4f})",
        zorder=5,
    )
    ax_roc.plot([0, 1], [0, 1], color="#BFBFBF", lw=0.8, ls="--", zorder=0)
    ax_roc.set_title("Receiver Operating Characteristic Curve", pad=8)
    ax_roc.set_xlabel("False Positive Rate")
    ax_roc.set_ylabel("True Positive Rate")
    ax_roc.legend(loc="upper center", bbox_to_anchor=(0.53, 0.82), frameon=True)

    roc_in = inset_axes(ax_roc, width="45%", height="42%", loc="lower right", borderpad=1.25)
    for i, (fpr, tpr, _) in enumerate(roc_curves):
        roc_in.plot(fpr, tpr, color=colors[i % len(colors)], lw=0.9)
    roc_in.plot(mean_fpr, mean_tpr, color="black", lw=1.2)
    roc_in.set_xlim(0.0, 0.30)
    roc_in.set_ylim(0.62, 0.94)
    add_inset_style(roc_in)
    mark_zoom(ax_roc, roc_in, loc1=2, loc2=4)
    fig_roc.tight_layout()
    save_figure(fig_roc, output_dir / args.roc_prefix)

    fig_pr, ax_pr = plt.subplots(figsize=(5.3, 4.25))
    style_axis(ax_pr)
    for i, (recall, precision, aupr) in enumerate(pr_curves):
        ax_pr.plot(recall, precision, color=colors[i % len(colors)], lw=1.0, label=f"P-R fold {i + 1} ($AUPR$ = {aupr:.4f})")
    ax_pr.plot(
        mean_recall,
        mean_precision,
        color="black",
        lw=1.5,
        label=rf"Mean P-R ($AUPR$ = {mean_aupr:.4f}$\pm${std_aupr:.4f})",
        zorder=5,
    )
    ax_pr.set_title("Precision-Recall Curve", pad=8)
    ax_pr.set_xlabel("Recall")
    ax_pr.set_ylabel("Precision")
    ax_pr.legend(loc="upper center", bbox_to_anchor=(0.43, 0.77), frameon=True)

    pr_in = inset_axes(ax_pr, width="46%", height="43%", loc="lower left", borderpad=1.25)
    for i, (recall, precision, _) in enumerate(pr_curves):
        pr_in.plot(recall, precision, color=colors[i % len(colors)], lw=0.9)
    pr_in.plot(mean_recall, mean_precision, color="black", lw=1.2)
    pr_in.set_xlim(0.55, 0.98)
    pr_in.set_ylim(0.74, 1.00)
    add_inset_style(pr_in)
    mark_zoom(ax_pr, pr_in, loc1=1, loc2=3)
    fig_pr.tight_layout()
    save_figure(fig_pr, output_dir / args.pr_prefix)

    mean_rows = [
        {
            "fpr": float(fpr),
            "mean_tpr": float(tpr),
            "recall": float(recall),
            "mean_precision": float(precision),
            "mean_auc": mean_auc,
            "std_auc": std_auc,
            "mean_aupr": mean_aupr,
            "std_aupr": std_aupr,
        }
        for fpr, tpr, recall, precision in zip(mean_fpr, mean_tpr, mean_recall, mean_precision)
    ]
    save_csv(output_dir / f"{args.roc_prefix}_and_{args.pr_prefix}_mean_source.csv", mean_rows, list(mean_rows[0]))
    save_csv(
        output_dir / f"{args.roc_prefix}_and_{args.pr_prefix}_fold_source.csv",
        fold_rows,
        ["fold", "roc_fpr", "roc_tpr", "roc_threshold", "roc_auc", "pr_recall", "pr_precision", "pr_threshold", "aupr"],
    )

    print(f"[plot_cold_start_split_nature_style] mean AUC={mean_auc:.4f} +/- {std_auc:.4f}")
    print(f"[plot_cold_start_split_nature_style] mean AUPR={mean_aupr:.4f} +/- {std_aupr:.4f}")
    print(f"[plot_cold_start_split_nature_style] wrote {output_dir / args.roc_prefix}.*")
    print(f"[plot_cold_start_split_nature_style] wrote {output_dir / args.pr_prefix}.*")


if __name__ == "__main__":
    main()
