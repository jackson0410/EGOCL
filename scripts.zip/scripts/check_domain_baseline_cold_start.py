from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.utils import load_csv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check strict tsRNA cold-start splits for domain baselines.")
    parser.add_argument("--baseline_dir", default="results/domain_baselines_cold_start")
    return parser.parse_args()


def read_ids(path: Path) -> set[int]:
    if not path.exists():
        raise FileNotFoundError(f"Missing cold-start entity file: {path}")
    ids: set[int] = set()
    for row in load_csv(path):
        if "tsrna_id" in row:
            ids.add(int(row["tsrna_id"]))
        elif "id" in row:
            ids.add(int(row["id"]))
    return ids


def read_pairs(path: Path) -> set[tuple[int, int]]:
    if not path.exists():
        raise FileNotFoundError(f"Missing pair file: {path}")
    return {(int(row["tsrna_id"]), int(row["disease_id"])) for row in load_csv(path)}


def assert_pairs_in_entities(pairs: set[tuple[int, int]], allowed_ids: set[int], path: Path) -> None:
    bad = [pair for pair in pairs if pair[0] not in allowed_ids]
    if bad:
        raise AssertionError(f"{path} contains pair(s) outside its cold-start tsRNA split: {bad[:10]}")


def cold_id_path(fold_dir: Path, common_fold_dir: Path, file_name: str) -> Path:
    local_path = fold_dir / file_name
    if local_path.exists():
        return local_path
    common_path = common_fold_dir / file_name
    if common_path.exists():
        return common_path
    return local_path


def check_fold(fold_dir: Path, common_fold_dir: Path) -> None:
    train_ids = read_ids(cold_id_path(fold_dir, common_fold_dir, "train_cold_tsrna_ids.csv"))
    val_ids = read_ids(cold_id_path(fold_dir, common_fold_dir, "val_cold_tsrna_ids.csv"))
    test_ids = read_ids(cold_id_path(fold_dir, common_fold_dir, "test_cold_tsrna_ids.csv"))
    if train_ids & val_ids or train_ids & test_ids or val_ids & test_ids:
        raise AssertionError(f"Cold-start tsRNA id splits overlap in {fold_dir}")

    split_specs = [
        ("train", train_ids),
        ("val", val_ids),
        ("test", test_ids),
    ]
    for split_name, allowed_ids in split_specs:
        for label_name in ("pos", "neg"):
            path = fold_dir / f"{split_name}_{label_name}_pairs.csv"
            assert_pairs_in_entities(read_pairs(path), allowed_ids, path)

    message_graph = fold_dir / "message_graph_edges.csv"
    if message_graph.exists():
        assert_pairs_in_entities(read_pairs(message_graph), train_ids, message_graph)

    train_matrix = fold_dir / "train_matrix.npy"
    if train_matrix.exists():
        matrix = np.load(train_matrix)
        held_out_ids = sorted(val_ids | test_ids)
        if held_out_ids and np.any(matrix[held_out_ids, :] != 0):
            nonzero_rows = np.where(matrix[held_out_ids, :].sum(axis=1) != 0)[0][:10]
            leaked = [held_out_ids[int(idx)] for idx in nonzero_rows]
            raise AssertionError(f"train_matrix has nonzero rows for held-out cold tsRNAs in {fold_dir}: {leaked}")


def main() -> None:
    args = parse_args()
    baseline_dir = Path(args.baseline_dir)
    if not baseline_dir.exists():
        raise FileNotFoundError(f"Missing baseline dir: {baseline_dir}")
    checked = 0
    for model_dir in sorted(path for path in baseline_dir.iterdir() if path.is_dir() and path.name != "common_data"):
        for fold_dir in sorted(path for path in model_dir.glob("fold_*") if path.is_dir()):
            if not (fold_dir / "train_pos_pairs.csv").exists():
                continue
            print(f"[cold-start-check] checking {model_dir.name}/{fold_dir.name}", flush=True)
            check_fold(fold_dir, baseline_dir / "common_data" / fold_dir.name)
            checked += 1
    if checked == 0:
        raise FileNotFoundError(f"No completed fold directories found under {baseline_dir}")
    print("all domain baseline cold-start folds passed", flush=True)


if __name__ == "__main__":
    main()
